# MMD Studio

原生 iOS 的 PMX 模型浏览、编辑与 MMD 动作播放器。使用 SwiftUI + Metal，自研渲染管线，不依赖 SceneKit、第三方运行库或 Swift Package。

> 目标系统：iOS 17.0 及以上，可直接在 iOS 27 上运行。使用 iOS 27 SDK 的 Xcode 打开即可；部署目标保持 17.0，以兼容更多设备。

## 构建与运行

1. 解压 `MMDStudio-iOS27.zip`。
2. 用 Xcode 打开 `MMDStudio.xcodeproj`。
3. 在 target **MMDStudio** 的 *Signing & Capabilities* 中选择你的 Apple Developer Team；如需上架，把 Bundle Identifier 从 `com.mmdstudio.app` 改成自己的。
4. Scheme 选择 **MMDStudio**，设备选择 iPhone 或 iPad，点击 Run。

工程没有 CocoaPods / SwiftPM 依赖，也不内置示例模型或动作。首次启动模型库为空，请从「文件」App 导入自己的 PMX 文件夹。

如果 Xcode 提示签名失败，先选择 Team；模拟器通常不需要签名。若要在 iOS 27 真机验证，请在 Xcode 中选择带 iOS 27 SDK 的版本，并确认设备已信任开发者证书。

## 功能

- **导入**：从「文件」App 选择整个 PMX 模型文件夹，或选择单个 `.pmx`。文件夹方式最稳，能保留贴图子目录；单文件方式会尝试复制同目录图片。
- **浏览**：轨道相机（单指旋转、双指平移、捏合缩放、双击重置），自动按模型包围盒取景；地面网格、地面阴影、骨骼线框叠加。
- **PMX 渲染**：PMX 2.0 / 2.1；UTF-16LE / UTF-8 文本；BDEF1 / BDEF2 / BDEF4 / QDEF 权重（SDEF 近似为 BDEF2）；GPU 蒙皮；卡通渐变；球面贴图（乘法 / 加法）；基础贴图；透明混合；反壳描边；Alpha 裁切；双面材质。
- **材质编辑**：漫反射颜色、不透明度、显示开关、双面、地面阴影、基础贴图开关、卡通渐变开关、球面模式、描边颜色/宽度/开关、恢复单个或全部材质默认值。
- **顶点变形**：顶点 Morph 与组 Morph 的滑杆；可与 VMD 的 Morph 关键帧叠加。
- **骨骼编辑**：搜索骨骼；手动 X/Y/Z 旋转（角度）；单根或全部归零；选中骨骼在视图中高亮，并显示 IK 目标连线。
- **VMD 动作**：骨骼关键帧（位置/四元数/贝塞尔补间）、Morph 关键帧、相机关键帧；30 FPS 播放、拖动进度、循环、0.5x–2x 速度、VMD 相机开关、替换/移除动作。
- **模型信息**：版本、顶点/三角面/材质/骨骼/变形/贴图数量、尺寸、解析警告。

## 操作

- 单指拖动：旋转视角
- 双指拖动：平移目标点
- 捏合：缩放
- 双击：重置相机
- 顶部画风条：MMD 标准 / 原神 / 星穹铁道 / 绝区零 / 写实一键切换
- 底部命令栏：材质、表情、骨骼、灯光、相机、设置、重置、骨架、拍照、录制
- 底部播放栏：播放/暂停、进度、循环、速度、相机动作、更换 VMD

## 目录结构

```
MMDStudio/
├── MMDStudio.xcodeproj
├── MMDStudio/
│   ├── App/                 # App 入口、文档状态、模型库
│   ├── Core/                # PMX/VMD 解析、数学、动画、贴图
│   ├── Render/              # Metal 渲染器、网格构建、着色器
│   ├── UI/                  # SwiftUI 页面与 Inspector
│   ├── Assets.xcassets
│   └── Info.plist
└── README.md
```

主要类型：

- `MMDStore`：模型库、文件夹/单文件导入。
- `MMDModelDocument`：当前模型、材质/Morph/骨骼编辑状态、VMD 播放。
- `PMXParser` / `VMDParser`：二进制解析与坐标转换。
- `MMDSkeleton` / `MMDMorphController`：骨骼世界矩阵、蒙皮 palette、Morph 顶点位移。
- `MMDMeshBuilder` / `MMDRenderer` / `Shaders.metal`：Metal 资源、渲染通道与着色。

## 坐标与格式约定

- PMX 为左手坐标系；加载时顶点位置、法线、Morph 偏移的 Z 取负，转为右手系。模型正面朝 +Z，默认相机在 +Z。
- VMD 四元数 `(x,y,z,w)` 转为 `(-x,-y,z,w)`，位移 Z 取负。
- 三角形绕序不信任导出器：按面法线与顶点法线的一致性自动翻转，并按整体得分设置 `MTLWinding`。
- 渲染顺序：网格 → 地面阴影 → 不透明材质 → 反壳描边 → 透明材质（按材质中心到相机距离排序）→ 骨骼线框。

## 示例资产

本版本不内置示例模型或动作，避免安装包携带占位资产。请导入自己的 PMX 文件夹与 VMD/视频动作。

## 当前限制

- 不计算 PMX 刚体与柔软体物理（无重力、碰撞、布料）。
- 不求解 IK；IK 信息会解析并在 UI 中提示，但姿态由 VMD 骨骼旋转直接驱动。
- 不支持 PMD；不支持 VMD 音频、表情音轨、VPV。
- SDEF 按 BDEF2 近似；材质 Morph、UV Morph、骨骼 Morph 会解析但暂不参与渲染。
- VMD 相机姿态为近似实现，忽略 roll；未与 MMD 原版逐帧比对。
- 不提供模型导出、动作编辑保存或视频导出。

## 构建状态与验证

本工程在 Linux 环境中生成，**没有在 macOS/Xcode 中实际编译过**，因此不承诺“解压即可零报错构建”。已完成以下离线验证：

- 示例 PMX/VMD 通过 `mmd-parser` 解析校验。
- Xcode `project.pbxproj` 通过 Python `pbxproj` 解析，target `MMDStudio` 与 Build Phases 可识别。
- 全部 Swift 文件通过 tree-sitter Swift 语法解析，无语法错误。
- 所有资源、源码引用路径均已检查存在。

首次在 Xcode 构建时，如遇 SDK 版本导致的 API 差异（尤其是 SwiftUI/Metal 的新旧 SDK 差异），按 Xcode 报错逐条修正即可；核心解析与渲染结构不依赖已废弃 API。

## 故障排除

- **启动后模型库为空**：这是正常行为，本版本不再附带示例模型；请从「文件」App 导入 PMX 文件夹。
- **模型黑屏 / 无画面**：检查 `Shaders.metal` 是否在 target 的 Compile Sources；查看 Xcode 控制台是否有 Metal pipeline 创建失败日志。
- **贴图丢失**：优先导入整个模型文件夹；PMX 内的 Windows 绝对路径会回退到文件名匹配，并做大小写不敏感查找。
- **真机无法安装**：设置 Team 与唯一 Bundle Identifier；确认设备系统版本 ≥ iOS 17。
