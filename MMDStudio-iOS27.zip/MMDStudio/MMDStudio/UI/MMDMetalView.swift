import SwiftUI
import MetalKit
import UIKit

struct MMDMetalView: UIViewRepresentable {

    @ObservedObject var document: MMDModelDocument

    func makeCoordinator() -> Coordinator {
        Coordinator()
    }

    func makeUIView(context: Context) -> MMDGestureView {
        let container = MMDGestureView(frame: .zero)
        container.backgroundColor = .black

        guard let renderer = MMDRenderer(view: container.renderView) else {
            return container
        }
        context.coordinator.renderer = renderer
        renderer.document = document
        renderer.onRenderScaleChange = { [weak container] scale in
            container?.renderScale = scale
        }

        container.onOrbit = { [weak renderer] deltaX, deltaY in
            renderer?.orbitCamera(deltaX: deltaX, deltaY: deltaY)
        }
        container.onPan = { [weak renderer] deltaX, deltaY in
            renderer?.panCamera(deltaX: deltaX, deltaY: deltaY)
        }
        container.onZoom = { [weak renderer] scale in
            renderer?.zoomCamera(scale: scale)
        }
        container.onReset = { [weak renderer] in
            renderer?.resetCamera()
        }

        context.coordinator.observer = NotificationCenter.default.addObserver(
            forName: .mmdResetCamera, object: nil, queue: .main
        ) { [weak renderer] _ in
            renderer?.resetCamera()
        }
        return container
    }

    func updateUIView(_ uiView: MMDGestureView, context: Context) {
        context.coordinator.renderer?.document = document
    }

    static func dismantleUIView(_ uiView: MMDGestureView, coordinator: Coordinator) {
        uiView.renderView.delegate = nil
        if let observer = coordinator.observer {
            NotificationCenter.default.removeObserver(observer)
        }
    }

    final class Coordinator {
        var renderer: MMDRenderer?
        var observer: NSObjectProtocol?

        deinit {
            if let observer {
                NotificationCenter.default.removeObserver(observer)
            }
        }
    }
}

/// A UIKit container that hosts an MTKView and owns the camera gestures.
final class MMDGestureView: UIView, UIGestureRecognizerDelegate {

    let renderView: MTKView
    var onOrbit: ((Float, Float) -> Void)?
    var onPan: ((Float, Float) -> Void)?
    var onZoom: ((Float) -> Void)?
    var onReset: (() -> Void)?

    /// A value of 1.0 renders at native resolution. The renderer lowers this
    /// when the GPU budget is exceeded, without changing the UI layout.
    var renderScale: CGFloat = 1.0 {
        didSet {
            guard abs(oldValue - renderScale) > 0.001 else { return }
            updateDrawableSize()
        }
    }

    override init(frame: CGRect) {
        renderView = MTKView(frame: .zero, device: MTLCreateSystemDefaultDevice())
        super.init(frame: frame)
        clipsToBounds = true
        isMultipleTouchEnabled = true
        isUserInteractionEnabled = true
        renderView.translatesAutoresizingMaskIntoConstraints = true
        renderView.autoResizeDrawable = false
        renderView.framebufferOnly = true
        renderView.isOpaque = true
        addSubview(renderView)
        setupGestures()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        renderView.frame = bounds
        updateDrawableSize()
    }

    private func updateDrawableSize() {
        guard bounds.width > 0, bounds.height > 0 else { return }
        let nativeScale = UIScreen.main.scale
        let width = max(1, Int(bounds.width * nativeScale * renderScale))
        let height = max(1, Int(bounds.height * nativeScale * renderScale))
        let size = CGSize(width: width, height: height)
        if renderView.drawableSize != size {
            renderView.drawableSize = size
        }
    }

    private func setupGestures() {
        let orbit = UIPanGestureRecognizer(target: self, action: #selector(handleOrbit(_:)))
        orbit.minimumNumberOfTouches = 1
        orbit.maximumNumberOfTouches = 1
        addGestureRecognizer(orbit)

        let pan = UIPanGestureRecognizer(target: self, action: #selector(handlePan(_:)))
        pan.minimumNumberOfTouches = 2
        pan.maximumNumberOfTouches = 2
        addGestureRecognizer(pan)

        let pinch = UIPinchGestureRecognizer(target: self, action: #selector(handlePinch(_:)))
        addGestureRecognizer(pinch)

        for recognizer in gestureRecognizers ?? [] {
            recognizer.delegate = self
        }

        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(handleDoubleTap(_:)))
        doubleTap.numberOfTapsRequired = 2
        addGestureRecognizer(doubleTap)
    }

    @objc private func handleOrbit(_ gesture: UIPanGestureRecognizer) {
        let translation = gesture.translation(in: self)
        gesture.setTranslation(.zero, in: self)
        // The renderer converts points to radians using the viewport size.
        onOrbit?(Float(translation.x), Float(translation.y))
    }

    @objc private func handlePan(_ gesture: UIPanGestureRecognizer) {
        let translation = gesture.translation(in: self)
        gesture.setTranslation(.zero, in: self)
        onPan?(Float(translation.x), Float(translation.y))
    }

    @objc private func handlePinch(_ gesture: UIPinchGestureRecognizer) {
        guard gesture.state == .began || gesture.state == .changed else { return }
        onZoom?(Float(gesture.scale))
        gesture.scale = 1
    }

    @objc private func handleDoubleTap(_ gesture: UITapGestureRecognizer) {
        onReset?()
    }

    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,
                           shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        true
    }
}
