import Foundation
import SwiftUI
import UniformTypeIdentifiers

struct MMDModelEntry: Identifiable, Hashable {
    let folderName: String
    let displayName: String
    let pmxPath: String
    let folderURL: URL

    var id: String { folderName }
}

struct MMDImportResult {
    let entries: [MMDModelEntry]
    let warnings: [String]
}

final class MMDStore: ObservableObject {

    @Published var entries: [MMDModelEntry] = []
    @Published var errorMessage: String?

    let libraryURL: URL

    init() {
        let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSTemporaryDirectory())
        libraryURL = documents.appendingPathComponent("MMDModels", isDirectory: true)
        try? FileManager.default.createDirectory(at: libraryURL, withIntermediateDirectories: true)
        installSampleIfNeeded()
        refresh()
    }

    // MARK: - Library

    func refresh() {
        let fileManager = FileManager.default
        guard let contents = try? fileManager.contentsOfDirectory(at: libraryURL,
                                                                  includingPropertiesForKeys: [.isDirectoryKey],
                                                                  options: [.skipsHiddenFiles]) else {
            entries = []
            return
        }
        var result: [MMDModelEntry] = []
        for folder in contents {
            let values = try? folder.resourceValues(forKeys: [.isDirectoryKey])
            guard values?.isDirectory == true else { continue }
            guard let pmx = findPMX(in: folder) else { continue }
            let folderName = folder.lastPathComponent
            let displayName = folderName == "SampleModel" ? "示例模型 · 舞" : folderName
            result.append(MMDModelEntry(folderName: folderName, displayName: displayName,
                                        pmxPath: pmx.path, folderURL: folder))
        }
        result.sort { lhs, rhs in
            if lhs.folderName == "SampleModel" { return true }
            if rhs.folderName == "SampleModel" { return false }
            return lhs.displayName.localizedStandardCompare(rhs.displayName) == .orderedAscending
        }
        entries = result
    }

    func open(_ entry: MMDModelEntry) throws -> MMDModelDocument {
        let pmxURL = URL(fileURLWithPath: entry.pmxPath)
        let data = try Data(contentsOf: pmxURL)
        let model = try PMXParser(data: data).parse()
        // Textures are usually relative to the PMX file, which can live in a subfolder.
        let baseDirectory = pmxURL.deletingLastPathComponent()
        let document = MMDModelDocument(model: model, baseDirectory: baseDirectory, displayName: model.displayName)
        if let vmd = findFile(withExtension: "vmd", in: baseDirectory)
            ?? findFile(withExtension: "vmd", in: entry.folderURL) {
            try? document.loadMotion(url: vmd)
        }
        return document
    }

    func delete(_ entry: MMDModelEntry) {
        do {
            try FileManager.default.removeItem(at: entry.folderURL)
            refresh()
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    // MARK: - Import

    /// Import one folder, PMX file, or ZIP archive. ZIPs are extracted first so
    /// texture subfolders and duplicate filenames keep their original layout.
    func importModel(from source: URL) throws -> MMDModelEntry {
        let result = try importModels(from: [source])
        guard let first = result.entries.first else {
            throw MMDLoadError.invalidData("没有找到可导入的模型")
        }
        return first
    }

    func importModels(from sources: [URL]) throws -> MMDImportResult {
        var entries = [MMDModelEntry]()
        var warnings = [String]()
        for source in sources {
            let accessed = source.startAccessingSecurityScopedResource()
            defer { if accessed { source.stopAccessingSecurityScopedResource() } }
            let fileManager = FileManager.default
            let isDirectory = (try? source.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
            let extensionName = source.pathExtension.lowercased()
            let stem = source.deletingPathExtension().lastPathComponent
            let baseName = stem.isEmpty ? "导入模型" : stem
            let destination = uniqueFolder(named: baseName)
            try fileManager.createDirectory(at: destination, withIntermediateDirectories: true)

            do {
                if isDirectory {
                    let contents = try fileManager.contentsOfDirectory(at: source,
                                                                       includingPropertiesForKeys: nil,
                                                                       options: [.skipsHiddenFiles])
                    for item in contents {
                        let target = destination.appendingPathComponent(item.lastPathComponent)
                        if !fileManager.fileExists(atPath: target.path) {
                            try fileManager.copyItem(at: item, to: target)
                        }
                    }
                } else if extensionName == "zip" {
                    try MMDZipArchive.extract(url: source, to: destination)
                } else if extensionName == "pmx" {
                    try fileManager.copyItem(at: source,
                                             to: destination.appendingPathComponent(source.lastPathComponent))
                    // Best effort for a single PMX. If the picker only exposed
                    // the file itself these copies are unavailable, hence the
                    // warning below. A folder or ZIP is the reliable route.
                    if !copySiblingResources(from: source.deletingLastPathComponent(), to: destination) {
                        warnings.append("单个 PMX 可能缺少同目录贴图；如贴图缺失，请改选模型文件夹或 ZIP。")
                    }
                } else {
                    throw MMDLoadError.unsupported("不支持的文件类型 .\(extensionName)")
                }
            } catch {
                try? fileManager.removeItem(at: destination)
                throw error
            }

            guard let pmx = findPMX(in: destination) else {
                try? fileManager.removeItem(at: destination)
                throw MMDLoadError.invalidData("导入内容中没有找到 .pmx 模型文件")
            }
            let folderName = destination.lastPathComponent
            entries.append(MMDModelEntry(folderName: folderName, displayName: folderName,
                                         pmxPath: pmx.path, folderURL: destination))
        }
        refresh()
        return MMDImportResult(entries: entries, warnings: warnings)
    }

    /// Copy images and nested texture folders next to a single PMX. Returns
    /// false when the source directory cannot be read at all.
    @discardableResult
    private func copySiblingResources(from parent: URL, to destination: URL) -> Bool {
        let fileManager = FileManager.default
        guard let contents = try? fileManager.contentsOfDirectory(at: parent,
                                                                  includingPropertiesForKeys: [.isDirectoryKey],
                                                                  options: [.skipsHiddenFiles]) else {
            return false
        }
        let imageExtensions: Set<String> = ["png", "jpg", "jpeg", "bmp", "tga", "gif", "webp"]
        for item in contents {
            let isDirectory = (try? item.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
            let target = destination.appendingPathComponent(item.lastPathComponent)
            if fileManager.fileExists(atPath: target.path) { continue }
            if isDirectory {
                // Keep texture subfolders such as tex/ or toon/ intact.
                try? fileManager.copyItem(at: item, to: target)
            } else if imageExtensions.contains(item.pathExtension.lowercased()) {
                try? fileManager.copyItem(at: item, to: target)
            }
        }
        return true
    }

    private func uniqueFolder(named rawName: String) -> URL {
        let sanitized = rawName.replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "\\", with: "_")
            .replacingOccurrences(of: ":", with: "_")
            .replacingOccurrences(of: "..", with: "_")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let name = sanitized.isEmpty ? "导入模型" : sanitized
        var candidate = libraryURL.appendingPathComponent(name, isDirectory: true)
        var index = 2
        while FileManager.default.fileExists(atPath: candidate.path) {
            candidate = libraryURL.appendingPathComponent("\(name) \(index)", isDirectory: true)
            index += 1
        }
        return candidate
    }

    // MARK: - Sample

    private func installSampleIfNeeded() {
        let fileManager = FileManager.default
        let destination = libraryURL.appendingPathComponent("SampleModel", isDirectory: true)
        if fileManager.fileExists(atPath: destination.path) { return }
        guard let source = Bundle.main.url(forResource: "SampleModel", withExtension: nil) else { return }
        do {
            try fileManager.createDirectory(at: destination, withIntermediateDirectories: true)
            let contents = try fileManager.contentsOfDirectory(at: source,
                                                               includingPropertiesForKeys: nil,
                                                               options: [.skipsHiddenFiles])
            for item in contents {
                try? fileManager.copyItem(at: item, to: destination.appendingPathComponent(item.lastPathComponent))
            }
        } catch {
            errorMessage = "示例模型安装失败：\(error.localizedDescription)"
        }
    }

    // MARK: - Helpers

    private func findPMX(in folder: URL) -> URL? {
        findFile(withExtension: "pmx", in: folder)
    }

    private func findFile(withExtension ext: String, in folder: URL) -> URL? {
        guard let enumerator = FileManager.default.enumerator(at: folder,
                                                              includingPropertiesForKeys: [.isRegularFileKey],
                                                              options: [.skipsHiddenFiles]) else { return nil }
        for case let url as URL in enumerator {
            if url.pathExtension.lowercased() == ext { return url }
        }
        return nil
    }
}
