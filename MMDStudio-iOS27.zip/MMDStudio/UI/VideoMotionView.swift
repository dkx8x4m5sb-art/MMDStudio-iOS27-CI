import SwiftUI
import UniformTypeIdentifiers

struct VideoMotionView: View {
    @ObservedObject var document: MMDModelDocument
    @Environment(\.dismiss) private var dismiss

    @State private var showPicker = false
    @State private var videoURL: URL?
    @State private var isProcessing = false
    @State private var progress: Double = 0
    @State private var status: String?
    @State private var errorText: String?
    @ObservedObject private var poseStore = MMDPoseModelStore.shared
    @State private var selectedModel: MMDPoseModelKind = .lite

    private let extractor = MMDVideoMotionExtractor()

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Text("从一段正面、全身的舞蹈视频中提取关节点，生成实验性 VMD 动作。建议固定机位、人物完整入镜、光线充足。")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }

                Section("视频") {
                    Button {
                        showPicker = true
                    } label: {
                        Label(videoURL == nil ? "选择舞蹈视频" : "重新选择视频",
                              systemImage: "video.badge.plus")
                    }
                    if let videoURL {
                        LabeledContent("文件", value: videoURL.lastPathComponent)
                    }
                }

                Section("姿态模型（开源）") {
                    Picker("使用模型", selection: $selectedModel) {
                        ForEach(MMDPoseModelKind.allCases) { kind in
                            Text(kind.title).tag(kind)
                        }
                    }
                    ForEach(MMDPoseModelKind.allCases) { kind in
                        HStack(spacing: 10) {
                            Image(systemName: kind == .lite ? "iphone" : "arrow.down.circle")
                                .foregroundStyle(poseStore.isAvailable(kind) ? Color.cyan : Color.gray)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(kind.title)
                                    .font(.subheadline.weight(kind == selectedModel ? .semibold : .regular))
                                Text(kind.detail)
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            if kind.isBundled {
                                Text("内置")
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                            } else if poseStore.isAvailable(kind) {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundStyle(.green)
                                    .onTapGesture { poseStore.remove(kind) }
                            } else if poseStore.downloading == kind {
                                ProgressView()
                                    .scaleEffect(0.8)
                            } else {
                                Button("下载") { poseStore.download(kind) }
                                    .buttonStyle(.bordered)
                                    .font(.caption)
                            }
                        }
                        .contentShape(Rectangle())
                        .onTapGesture {
                            if poseStore.isAvailable(kind) { selectedModel = kind }
                        }
                    }
                    if let error = poseStore.lastError {
                        Text(error)
                            .font(.caption2)
                            .foregroundStyle(.red)
                    }
                    Text("Full/Heavy 从 Google 官方模型库下载到 Documents/MMDStudio/Models，不占安装包；下载后可离线推理。")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }

                Section("更多开源方案（外部链接）") {
                    ForEach(mmdExternalMotionSchemes) { scheme in
                        Link(destination: scheme.url) {
                            VStack(alignment: .leading, spacing: 3) {
                                HStack {
                                    Text(scheme.title)
                                        .font(.subheadline.weight(.semibold))
                                    Spacer()
                                    Image(systemName: "arrow.up.right.square")
                                        .font(.caption)
                                }
                                Text(scheme.detail)
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                                    .multilineTextAlignment(.leading)
                            }
                        }
                    }
                }

                if isProcessing {
                    Section("提取进度") {
                        ProgressView(value: progress)
                        Text("\(Int(progress * 100))% · 正在逐帧估计人体姿态")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }

                if let status {
                    Section {
                        Label(status, systemImage: "checkmark.circle.fill")
                            .foregroundStyle(.green)
                        if !document.motionMappingNote.isEmpty {
                            Text(document.motionMappingNote)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                }

                if let errorText {
                    Section {
                        Text(errorText)
                            .font(.caption)
                            .foregroundStyle(.red)
                    }
                }

                Section("实现说明") {
                    Text("App 内使用 MediaPipe BlazePose（Apache-2.0，33 关键点）做姿态估计：逐帧 20 Hz 采样，保留上半身、手臂、腿部与头部旋转，并对轨迹做四元数平滑。仓库另附 tools/video_to_vmd.py，可在桌面用 MediaPipe Holistic 生成更稳定的离线 VMD。单目视频缺少真实深度，快速旋转和遮挡仍可能产生误差。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section {
                    Button {
                        startExtraction()
                    } label: {
                        HStack {
                            Spacer()
                            Label("生成并载入 VMD", systemImage: "figure.dance")
                                .font(.headline)
                            Spacer()
                        }
                    }
                    .disabled(videoURL == nil || isProcessing || !poseStore.isAvailable(selectedModel))
                }
            }
            .navigationTitle("视频转动作")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("完成") { dismiss() }
                }
            }
            .sheet(isPresented: $showPicker) {
                MMDDocumentPicker(contentTypes: [.movie],
                                  allowsMultipleSelection: false,
                                  onPick: { urls in
                                      showPicker = false
                                      videoURL = urls.first
                                      status = nil
                                      errorText = nil
                                  },
                                  onCancel: { showPicker = false })
            }
        }
    }

    private func startExtraction() {
        guard let videoURL, !isProcessing else { return }
        isProcessing = true
        progress = 0
        status = nil
        errorText = nil
        MMDLog.shared.info("Video motion extraction requested: \(videoURL.lastPathComponent)")
        let modelURL = poseStore.localURL(for: selectedModel)
        extractor.extract(from: videoURL, modelURL: modelURL, progress: { value in
            DispatchQueue.main.async { self.progress = value }
        }, completion: { result in
            DispatchQueue.main.async {
                isProcessing = false
                switch result {
                case .success(let output):
                    do {
                        try document.loadMotion(url: output.url)
                        status = "已生成并载入动作：\(output.url.lastPathComponent)（采样 \(output.detectedFrames)/\(output.sampledFrames) 帧）"
                        MMDLog.shared.info("Video VMD loaded: \(output.url.lastPathComponent)")
                    } catch {
                        errorText = "VMD 已生成，但载入失败：\(error.localizedDescription)"
                    }
                case .failure(let error):
                    errorText = error.localizedDescription
                }
            }
        })
    }
}
