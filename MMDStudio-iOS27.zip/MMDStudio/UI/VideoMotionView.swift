import SwiftUI
import UniformTypeIdentifiers

struct VideoMotionView: View {
    @ObservedObject var document: MMDModelDocument
    @Environment(\.dismiss) private var dismiss

    @State private var showPicker = false
    @State private var videoURL: URL?
    @State private var isProcessing = false
    @State private var progress: Double = 0
    @State private var status: String?
    @State private var errorText: String?

    private let extractor = MMDVideoMotionExtractor()

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Text("从一段正面、全身的舞蹈视频中提取关节点，生成实验性 VMD 动作。建议固定机位、人物完整入镜、光线充足。")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }

                Section("视频") {
                    Button {
                        showPicker = true
                    } label: {
                        Label(videoURL == nil ? "选择舞蹈视频" : "重新选择视频",
                              systemImage: "video.badge.plus")
                    }
                    if let videoURL {
                        LabeledContent("文件", value: videoURL.lastPathComponent)
                    }
                }

                if isProcessing {
                    Section("提取进度") {
                        ProgressView(value: progress)
                        Text("\(Int(progress * 100))% · 正在逐帧估计人体姿态")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }

                if let status {
                    Section {
                        Label(status, systemImage: "checkmark.circle.fill")
                            .foregroundStyle(.green)
                    }
                }

                if let errorText {
                    Section {
                        Text(errorText)
                            .font(.caption)
                            .foregroundStyle(.red)
                    }
                }

                Section("实现说明") {
                    Text("App 内使用 MediaPipe BlazePose（Apache-2.0，33 关键点）做姿态估计：逐帧 20 Hz 采样，保留上半身、手臂、腿部与头部旋转，并对轨迹做四元数平滑。仓库另附 tools/video_to_vmd.py，可在桌面用 MediaPipe Holistic 生成更稳定的离线 VMD。单目视频缺少真实深度，快速旋转和遮挡仍可能产生误差。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section {
                    Button {
                        startExtraction()
                    } label: {
                        HStack {
                            Spacer()
                            Label("生成并载入 VMD", systemImage: "figure.dance")
                                .font(.headline)
                            Spacer()
                        }
                    }
                    .disabled(videoURL == nil || isProcessing)
                }
            }
            .navigationTitle("视频转动作")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("完成") { dismiss() }
                }
            }
            .sheet(isPresented: $showPicker) {
                MMDDocumentPicker(contentTypes: [.movie],
                                  allowsMultipleSelection: false,
                                  onPick: { urls in
                                      showPicker = false
                                      videoURL = urls.first
                                      status = nil
                                      errorText = nil
                                  },
                                  onCancel: { showPicker = false })
            }
        }
    }

    private func startExtraction() {
        guard let videoURL, !isProcessing else { return }
        isProcessing = true
        progress = 0
        status = nil
        errorText = nil
        MMDLog.shared.info("Video motion extraction requested: \(videoURL.lastPathComponent)")
        extractor.extract(from: videoURL, progress: { value in
            DispatchQueue.main.async { self.progress = value }
        }, completion: { result in
            DispatchQueue.main.async {
                isProcessing = false
                switch result {
                case .success(let output):
                    do {
                        try document.loadMotion(url: output.url)
                        status = "已生成并载入动作：\(output.url.lastPathComponent)（采样 \(output.detectedFrames)/\(output.sampledFrames) 帧）"
                        MMDLog.shared.info("Video VMD loaded: \(output.url.lastPathComponent)")
                    } catch {
                        errorText = "VMD 已生成，但载入失败：\(error.localizedDescription)"
                    }
                case .failure(let error):
                    errorText = error.localizedDescription
                }
            }
        })
    }
}
