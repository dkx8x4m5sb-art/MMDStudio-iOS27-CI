import SwiftUI
import simd

struct SettingsInspectorView: View {

    @ObservedObject var document: MMDModelDocument
    @Environment(\.dismiss) private var dismiss
    @State private var showLog = false

    var body: some View {
        NavigationStack {
            Form {
                Section("渲染方式") {
                    Picker("模式", selection: $document.renderSettings.renderMode) {
                        ForEach(MMDRenderMode.allCases) { mode in
                            Text(mode.rawValue).tag(mode)
                        }
                    }
                    Text(document.renderSettings.renderMode == .wireframe
                         ? "线框模式会关闭描边和贴图着色，仅显示三角网格。"
                         : "标准卡通为 MMD 渐变；写实光照使用常规明暗；法线/UV/线框用于检查网格与贴图。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section("视图") {
                    Toggle("显示地面网格", isOn: $document.renderSettings.showGrid)
                    Toggle("显示地面阴影", isOn: $document.renderSettings.showGroundShadow)
                    Toggle("显示骨骼", isOn: $document.renderSettings.showBones)
                    Toggle("启用描边", isOn: $document.renderSettings.edgesEnabled)
                    Toggle("卡通渐变着色", isOn: $document.renderSettings.toonEnabled)
                    Toggle("贴图 V 翻转（MMD 默认开启）", isOn: $document.renderSettings.uvFlipV)
                }

                Section("性能") {
                    Picker("渲染质量", selection: $document.renderSettings.qualityMode) {
                        ForEach(MMDQualityMode.allCases) { mode in
                            Text(mode.rawValue).tag(mode)
                        }
                    }
                    Toggle("显示性能监控", isOn: $document.renderSettings.showPerformanceHUD)
                    LabeledContent("实时帧率", value: String(format: "%.0f FPS", document.renderStats.fps))
                    LabeledContent("CPU / GPU", value: String(format: "%.2f / %.2f ms", document.renderStats.cpuMilliseconds, document.renderStats.gpuMilliseconds))
                    LabeledContent("渲染分辨率", value: document.renderStats.resolution)
                    LabeledContent("三角面 / Draw", value: "\(document.renderStats.triangles) / \(document.renderStats.drawCalls)")
                    if document.renderStats.missingTextures > 0 {
                        LabeledContent("缺失贴图", value: "\(document.renderStats.missingTextures) 张")
                            .foregroundStyle(.orange)
                    }
                }

                Section("光照系统") {
                    NavigationLink {
                        LightingInspectorView(document: document)
                    } label: {
                        Label("光源编辑器（太阳光 / 点光 / 环境光）", systemImage: "lightbulb")
                    }
                    HStack {
                        Text("环境光")
                        Slider(value: ambientBinding, in: 0.05...0.8)
                        Text(String(format: "%.2f", document.renderSettings.lightAmbient))
                            .captionValue()
                    }
                    HStack {
                        Text("补光")
                        Slider(value: fillBinding, in: 0...1)
                        Text(String(format: "%.2f", document.renderSettings.lightFill))
                            .captionValue()
                    }
                    HStack {
                        Text("轮廓光")
                        Slider(value: rimBinding, in: 0...1)
                        Text(String(format: "%.2f", document.renderSettings.lightRim))
                            .captionValue()
                    }
                    HStack {
                        Text("曝光")
                        Slider(value: exposureBinding, in: 0.7...1.8)
                        Text(String(format: "%.2f", document.renderSettings.exposure))
                            .captionValue()
                    }
                    Text("光源编辑器可添加、删除和编辑最多 4 盏光；太阳光提供主方向，点光源可调位置/范围，环境光补充暗部。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section("物理系统") {
                    Toggle("启用弹簧次级物理", isOn: $document.physicsSettings.enabled)
                    HStack {
                        Text("重力")
                        Slider(value: physicsGravityBinding, in: 0...1.5)
                        Text(String(format: "%.2f", document.physicsSettings.gravity))
                            .captionValue()
                    }
                    HStack {
                        Text("刚度")
                        Slider(value: physicsStiffnessBinding, in: 0.05...1.5)
                        Text(String(format: "%.2f", document.physicsSettings.stiffness))
                            .captionValue()
                    }
                    HStack {
                        Text("阻尼")
                        Slider(value: physicsDampingBinding, in: 0.1...1.5)
                        Text(String(format: "%.2f", document.physicsSettings.damping))
                            .captionValue()
                    }
                    HStack {
                        Text("风力")
                        Slider(value: physicsWindBinding, in: 0...0.8)
                        Text(String(format: "%.2f", document.physicsSettings.wind))
                            .captionValue()
                    }
                    Text("对名称含髪/裙/尾/袖/丝带等关键词的次级骨骼做弹簧阻尼模拟，不是 PMX 刚体碰撞。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section("线条") {
                    HStack {
                        Text("描边倍率")
                        Slider(value: edgeBinding, in: 0...3)
                        Text(String(format: "%.2f", document.renderSettings.edgeScale))
                            .font(.caption.monospacedDigit())
                            .foregroundStyle(.secondary)
                            .frame(width: 42, alignment: .trailing)
                    }
                    ColorPicker("背景颜色", selection: backgroundBinding, supportsOpacity: false)
                    Button("重置相机") {
                        NotificationCenter.default.post(name: .mmdResetCamera, object: nil)
                    }
                }

                Section("动作") {
                    if document.hasMotion {
                        LabeledContent("名称", value: document.motionName)
                        LabeledContent("总帧数", value: "\(document.motion?.maxFrame ?? 0)")
                        LabeledContent("相机关键帧", value: "\(document.motion?.cameraKeys.count ?? 0)")
                        Toggle("使用 VMD 相机动作", isOn: $document.useCameraMotion)
                            .disabled(document.motion?.cameraKeys.isEmpty ?? true)
                        Button("移除动作", role: .destructive) {
                            document.removeMotion()
                        }
                    } else {
                        Text("尚未加载 VMD 动作。可在播放栏点「导入 VMD 动作」。")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }

                Section("模型信息") {
                    LabeledContent("PMX 版本", value: String(format: "%.1f", document.model.version))
                    LabeledContent("顶点", value: "\(document.model.vertices.count)")
                    LabeledContent("三角面", value: "\(document.model.indices.count / 3)")
                    LabeledContent("材质", value: "\(document.model.materials.count)")
                    LabeledContent("骨骼", value: "\(document.model.bones.count)")
                    LabeledContent("变形", value: "\(document.model.morphs.count)")
                    LabeledContent("贴图引用", value: "\(document.model.textures.count)")
                    LabeledContent("尺寸", value: String(format: "%.1f × %.1f × %.1f",
                                                        document.model.bounds.size.x,
                                                        document.model.bounds.size.y,
                                                        document.model.bounds.size.z))
                }

                if !document.missingTextureNames.isEmpty {
                    Section("缺失贴图") {
                        ForEach(document.missingTextureNames, id: \.self) { name in
                            Text(name)
                                .font(.caption.monospaced())
                                .foregroundStyle(.orange)
                                .textSelection(.enabled)
                        }
                    }
                }

                Section("诊断") {
                    Button {
                        showLog = true
                    } label: {
                        Label("查看运行日志", systemImage: "doc.text.magnifyingglass")
                    }
                }

                if !document.model.warnings.isEmpty {
                    Section("解析提示") {
                        ForEach(document.model.warnings.indices, id: \.self) { index in
                            Text("• \(document.model.warnings[index])")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }
                }

                Section("说明") {
                    Text("支持导入模型文件夹、PMX 或 ZIP（自动解压并保留贴图子目录）。当前物理为弹簧次级运动，PMX 刚体/柔软体尚未完整解析；SDEF 权重按 BDEF2 近似；不支持 PMD。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("设置")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("完成") { dismiss() }
                }
            }
            .sheet(isPresented: $showLog) {
                LogViewer()
            }
        }
    }

    private var lightBinding: Binding<Double> {
        Binding(
            get: { Double(document.renderSettings.lightIntensity) },
            set: { document.renderSettings.lightIntensity = Float($0) }
        )
    }

    private var ambientBinding: Binding<Double> {
        Binding(get: { Double(document.renderSettings.lightAmbient) },
                set: { document.renderSettings.lightAmbient = Float($0) })
    }

    private var fillBinding: Binding<Double> {
        Binding(get: { Double(document.renderSettings.lightFill) },
                set: { document.renderSettings.lightFill = Float($0) })
    }

    private var rimBinding: Binding<Double> {
        Binding(get: { Double(document.renderSettings.lightRim) },
                set: { document.renderSettings.lightRim = Float($0) })
    }

    private var exposureBinding: Binding<Double> {
        Binding(get: { Double(document.renderSettings.exposure) },
                set: { document.renderSettings.exposure = Float($0) })
    }

    private var physicsGravityBinding: Binding<Double> {
        Binding(get: { Double(document.physicsSettings.gravity) },
                set: { document.physicsSettings.gravity = Float($0) })
    }

    private var physicsStiffnessBinding: Binding<Double> {
        Binding(get: { Double(document.physicsSettings.stiffness) },
                set: { document.physicsSettings.stiffness = Float($0) })
    }

    private var physicsDampingBinding: Binding<Double> {
        Binding(get: { Double(document.physicsSettings.damping) },
                set: { document.physicsSettings.damping = Float($0) })
    }

    private var physicsWindBinding: Binding<Double> {
        Binding(get: { Double(document.physicsSettings.wind) },
                set: { document.physicsSettings.wind = Float($0) })
    }

    private var edgeBinding: Binding<Double> {
        Binding(
            get: { Double(document.renderSettings.edgeScale) },
            set: { document.renderSettings.edgeScale = Float($0) }
        )
    }

    private var backgroundBinding: Binding<Color> {
        Binding(
            get: { Color(simd4: document.renderSettings.backgroundColor) },
            set: { document.renderSettings.backgroundColor = $0.simd4 }
        )
    }
}

private extension View {
    func captionValue() -> some View {
        self.font(.caption.monospacedDigit())
            .foregroundStyle(.secondary)
            .frame(width: 42, alignment: .trailing)
    }
}

struct LightingInspectorView: View {

    @ObservedObject var document: MMDModelDocument
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        Form {
            Section {
                Text("最多 4 盏光。太阳光是方向光；点光源按世界坐标和范围衰减；环境光直接抬亮暗部。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                ForEach(document.renderSettings.lights.indices, id: \.self) { index in
                    NavigationLink {
                        LightDetailView(light: Binding(
                            get: {
                                guard document.renderSettings.lights.indices.contains(index) else {
                                    return MMDLightSetting.sun()
                                }
                                return document.renderSettings.lights[index]
                            },
                            set: { value in
                                guard document.renderSettings.lights.indices.contains(index) else { return }
                                document.renderSettings.lights[index] = value
                            }
                        ))
                    } label: {
                        let light = document.renderSettings.lights[index]
                        HStack(spacing: 10) {
                            Image(systemName: light.kind.symbolName)
                                .foregroundStyle(Color(simd4: light.color))
                                .frame(width: 22)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(light.name)
                                Text("\(light.kind.rawValue) · 强度 \(String(format: "%.2f", light.intensity))")
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            if !light.enabled {
                                Text("关闭")
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                }
                .onDelete { offsets in
                    document.renderSettings.lights.remove(atOffsets: offsets)
                }
            } header: {
                Text("光源列表")
            } footer: {
                Text("左滑删除光源；点进单个光源可编辑颜色、强度和方向/位置。")
            }

            if document.renderSettings.lights.count < 4 {
                Section("添加光源") {
                    Button {
                        add(.sun)
                    } label: {
                        Label("太阳光", systemImage: "sun.max.fill")
                    }
                    Button {
                        add(.point)
                    } label: {
                        Label("点光源", systemImage: "lightbulb.fill")
                    }
                    Button {
                        add(.ambient)
                    } label: {
                        Label("环境光", systemImage: "circle.leeward.half.fill")
                    }
                }
            }
        }
        .navigationTitle("光源编辑")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("完成") { dismiss() }
            }
        }
    }

    private func add(_ kind: MMDLightKind) {
        guard document.renderSettings.lights.count < 4 else { return }
        let light: MMDLightSetting
        switch kind {
        case .sun:
            light = .sun(name: "太阳光 \(document.renderSettings.lights.count + 1)")
        case .point:
            light = .fill(name: "点光源 \(document.renderSettings.lights.count + 1)")
        case .ambient:
            light = .ambient(name: "环境光 \(document.renderSettings.lights.count + 1)")
        }
        document.renderSettings.lights.append(light)
    }
}

private struct LightDetailView: View {

    @Binding var light: MMDLightSetting

    var body: some View {
        Form {
            Section("光源") {
                TextField("名称", text: $light.name)
                Picker("类型", selection: $light.kind) {
                    ForEach(MMDLightKind.allCases) { kind in
                        Text(kind.rawValue).tag(kind)
                    }
                }
                Toggle("启用", isOn: $light.enabled)
                ColorPicker("颜色", selection: colorBinding, supportsOpacity: false)
                HStack {
                    Text("强度")
                    Slider(value: floatBinding(\.intensity), in: 0...3)
                    Text(String(format: "%.2f", light.intensity))
                        .captionValue()
                }
            }

            if light.kind == .sun {
                Section("方向（从表面指向光源）") {
                    vectorSlider("X", axis: 0, keyPath: \.direction)
                    vectorSlider("Y", axis: 1, keyPath: \.direction)
                    vectorSlider("Z", axis: 2, keyPath: \.direction)
                    Text("例如 (0.4, 0.8, 0.5) 表示光从左上前方照来。")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
            } else if light.kind == .point {
                Section("世界坐标与范围") {
                    vectorSlider("X", axis: 0, keyPath: \.position, range: -30...30)
                    vectorSlider("Y", axis: 1, keyPath: \.position, range: -10...40)
                    vectorSlider("Z", axis: 2, keyPath: \.position, range: -30...30)
                    HStack {
                        Text("范围")
                        Slider(value: floatBinding(\.range), in: 1...80)
                        Text(String(format: "%.0f", light.range))
                            .captionValue()
                    }
                }
            } else {
                Section {
                    Text("环境光没有方向，颜色 × 强度会加到所有材质的暗部。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
        }
        .navigationTitle(light.name.isEmpty ? "光源" : light.name)
        .navigationBarTitleDisplayMode(.inline)
    }

    private var colorBinding: Binding<Color> {
        Binding(get: { Color(simd4: light.color) }, set: { light.color = $0.simd4 })
    }

    private func floatBinding(_ keyPath: WritableKeyPath<MMDLightSetting, Float>) -> Binding<Double> {
        Binding(get: { Double(light[keyPath: keyPath]) },
                set: { light[keyPath: keyPath] = Float($0) })
    }

    private func vectorSlider(_ title: String, axis: Int,
                              keyPath: WritableKeyPath<MMDLightSetting, SIMD3<Float>>,
                              range: ClosedRange<Double> = -1...1) -> some View {
        HStack {
            Text(title)
            Slider(value: Binding(
                get: { Double(light[keyPath: keyPath][axis]) },
                set: { value in
                    var vector = light[keyPath: keyPath]
                    vector[axis] = Float(value)
                    light[keyPath: keyPath] = vector
                }
            ), in: range)
            Text(String(format: "%.2f", light[keyPath: keyPath][axis]))
                .captionValue()
        }
    }
}
