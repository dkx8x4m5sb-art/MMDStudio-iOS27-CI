import SwiftUI

struct SettingsInspectorView: View {

    @ObservedObject var document: MMDModelDocument
    @Environment(\.dismiss) private var dismiss
    @State private var showLog = false

    var body: some View {
        NavigationStack {
            Form {
                Section("渲染方式") {
                    Picker("模式", selection: $document.renderSettings.renderMode) {
                        ForEach(MMDRenderMode.allCases) { mode in
                            Text(mode.rawValue).tag(mode)
                        }
                    }
                    Text(document.renderSettings.renderMode == .wireframe
                         ? "线框模式会关闭描边和贴图着色，仅显示三角网格。"
                         : "标准卡通为 MMD 渐变；写实光照使用常规明暗；法线/UV/线框用于检查网格与贴图。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section("视图") {
                    Toggle("显示地面网格", isOn: $document.renderSettings.showGrid)
                    Toggle("显示地面阴影", isOn: $document.renderSettings.showGroundShadow)
                    Toggle("显示骨骼", isOn: $document.renderSettings.showBones)
                    Toggle("启用描边", isOn: $document.renderSettings.edgesEnabled)
                    Toggle("卡通渐变着色", isOn: $document.renderSettings.toonEnabled)
                    Toggle("贴图 V 翻转（仅用于非标准模型）", isOn: $document.renderSettings.uvFlipV)
                }

                Section("性能") {
                    Picker("渲染质量", selection: $document.renderSettings.qualityMode) {
                        ForEach(MMDQualityMode.allCases) { mode in
                            Text(mode.rawValue).tag(mode)
                        }
                    }
                    Toggle("显示性能监控", isOn: $document.renderSettings.showPerformanceHUD)
                    LabeledContent("实时帧率", value: String(format: "%.0f FPS", document.renderStats.fps))
                    LabeledContent("CPU / GPU", value: String(format: "%.2f / %.2f ms", document.renderStats.cpuMilliseconds, document.renderStats.gpuMilliseconds))
                    LabeledContent("渲染分辨率", value: document.renderStats.resolution)
                    LabeledContent("三角面 / Draw", value: "\(document.renderStats.triangles) / \(document.renderStats.drawCalls)")
                    if document.renderStats.missingTextures > 0 {
                        LabeledContent("缺失贴图", value: "\(document.renderStats.missingTextures) 张")
                            .foregroundStyle(.orange)
                    }
                }

                Section("光照与线条") {
                    HStack {
                        Text("光照强度")
                        Slider(value: lightBinding, in: 0.2...2.0)
                        Text(String(format: "%.2f", document.renderSettings.lightIntensity))
                            .font(.caption.monospacedDigit())
                            .foregroundStyle(.secondary)
                            .frame(width: 42, alignment: .trailing)
                    }
                    HStack {
                        Text("描边倍率")
                        Slider(value: edgeBinding, in: 0...3)
                        Text(String(format: "%.2f", document.renderSettings.edgeScale))
                            .font(.caption.monospacedDigit())
                            .foregroundStyle(.secondary)
                            .frame(width: 42, alignment: .trailing)
                    }
                    ColorPicker("背景颜色", selection: backgroundBinding, supportsOpacity: false)
                    Button("重置相机") {
                        NotificationCenter.default.post(name: .mmdResetCamera, object: nil)
                    }
                }

                Section("动作") {
                    if document.hasMotion {
                        LabeledContent("名称", value: document.motionName)
                        LabeledContent("总帧数", value: "\(document.motion?.maxFrame ?? 0)")
                        LabeledContent("相机关键帧", value: "\(document.motion?.cameraKeys.count ?? 0)")
                        Toggle("使用 VMD 相机动作", isOn: $document.useCameraMotion)
                            .disabled(document.motion?.cameraKeys.isEmpty ?? true)
                        Button("移除动作", role: .destructive) {
                            document.removeMotion()
                        }
                    } else {
                        Text("尚未加载 VMD 动作。可在播放栏点「导入 VMD 动作」。")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }

                Section("模型信息") {
                    LabeledContent("PMX 版本", value: String(format: "%.1f", document.model.version))
                    LabeledContent("顶点", value: "\(document.model.vertices.count)")
                    LabeledContent("三角面", value: "\(document.model.indices.count / 3)")
                    LabeledContent("材质", value: "\(document.model.materials.count)")
                    LabeledContent("骨骼", value: "\(document.model.bones.count)")
                    LabeledContent("变形", value: "\(document.model.morphs.count)")
                    LabeledContent("贴图引用", value: "\(document.model.textures.count)")
                    LabeledContent("尺寸", value: String(format: "%.1f × %.1f × %.1f",
                                                        document.model.bounds.size.x,
                                                        document.model.bounds.size.y,
                                                        document.model.bounds.size.z))
                }

                if !document.missingTextureNames.isEmpty {
                    Section("缺失贴图") {
                        ForEach(document.missingTextureNames, id: \.self) { name in
                            Text(name)
                                .font(.caption.monospaced())
                                .foregroundStyle(.orange)
                                .textSelection(.enabled)
                        }
                    }
                }

                Section("诊断") {
                    Button {
                        showLog = true
                    } label: {
                        Label("查看运行日志", systemImage: "doc.text.magnifyingglass")
                    }
                }

                if !document.model.warnings.isEmpty {
                    Section("解析提示") {
                        ForEach(document.model.warnings.indices, id: \.self) { index in
                            Text("• \(document.model.warnings[index])")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }
                }

                Section("说明") {
                    Text("支持导入模型文件夹、PMX 或 ZIP（自动解压并保留贴图子目录）。刚体与柔软体物理暂未实现；SDEF 顶点权重按 BDEF2 近似；不支持 PMD。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("设置")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("完成") { dismiss() }
                }
            }
            .sheet(isPresented: $showLog) {
                LogViewer()
            }
        }
    }

    private var lightBinding: Binding<Double> {
        Binding(
            get: { Double(document.renderSettings.lightIntensity) },
            set: { document.renderSettings.lightIntensity = Float($0) }
        )
    }

    private var edgeBinding: Binding<Double> {
        Binding(
            get: { Double(document.renderSettings.edgeScale) },
            set: { document.renderSettings.edgeScale = Float($0) }
        )
    }

    private var backgroundBinding: Binding<Color> {
        Binding(
            get: { Color(simd4: document.renderSettings.backgroundColor) },
            set: { document.renderSettings.backgroundColor = $0.simd4 }
        )
    }
}
