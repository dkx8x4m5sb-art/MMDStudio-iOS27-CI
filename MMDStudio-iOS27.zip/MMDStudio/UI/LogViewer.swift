import SwiftUI
import UIKit

struct LogViewer: View {
    @Environment(\.dismiss) private var dismiss
    @State private var text: String = ""
    @State private var shareURL: URL?
    @State private var showShare = false
    @State private var showClearConfirm = false

    var body: some View {
        NavigationStack {
            ScrollView([.vertical, .horizontal]) {
                Text(text)
                    .font(.system(size: 11, design: .monospaced))
                    .foregroundStyle(.white.opacity(0.9))
                    .textSelection(.enabled)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(12)
            }
            .background(Color(red: 0.06, green: 0.07, blue: 0.09))
            .navigationTitle("运行日志")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("完成") { dismiss() }
                }
                ToolbarItemGroup(placement: .topBarTrailing) {
                    Button {
                        text = MMDLog.shared.readRecent()
                    } label: {
                        Image(systemName: "arrow.clockwise")
                    }
                    Button {
                        shareURL = MMDLog.shared.exportURL()
                        showShare = shareURL != nil
                    } label: {
                        Image(systemName: "square.and.arrow.up")
                    }
                    Button(role: .destructive) {
                        showClearConfirm = true
                    } label: {
                        Image(systemName: "trash")
                    }
                }
            }
            .onAppear { text = MMDLog.shared.readRecent() }
            .sheet(isPresented: $showShare, onDismiss: { shareURL = nil }) {
                if let shareURL {
                    ActivityView(items: [shareURL])
                }
            }
            .alert("清空日志？", isPresented: $showClearConfirm) {
                Button("清空", role: .destructive) {
                    MMDLog.shared.clear()
                    text = "日志已清空。"
                }
                Button("取消", role: .cancel) {}
            }
        }
    }
}

struct ActivityView: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
