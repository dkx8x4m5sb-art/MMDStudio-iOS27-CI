import SwiftUI
import UniformTypeIdentifiers

struct LibraryView: View {

    @EnvironmentObject private var store: MMDStore
    @State private var showImporter = false
    @State private var showAbout = false
    @State private var showLog = false
    @State private var isImporting = false
    @State private var importNotice: String?

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.05, green: 0.07, blue: 0.11),
                                    Color(red: 0.08, green: 0.10, blue: 0.15)],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    header
                    if store.entries.isEmpty {
                        emptyState
                    } else {
                        LazyVStack(spacing: 12) {
                            ForEach(store.entries) { entry in
                                NavigationLink {
                                    ModelScreen(entry: entry)
                                } label: {
                                    ModelCard(entry: entry)
                                }
                                .buttonStyle(.plain)
                                .contextMenu {
                                    Button(role: .destructive) {
                                        store.delete(entry)
                                    } label: {
                                        Label("删除模型", systemImage: "trash")
                                    }
                                }
                            }
                        }
                    }
                    footer
                }
                .padding(20)
            }

            if isImporting {
                ProgressView("正在导入并解压…")
                    .padding(.horizontal, 22)
                    .padding(.vertical, 16)
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
            }
        }
        .navigationTitle("MMD Studio")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    showImporter = true
                } label: {
                    Image(systemName: "plus")
                        .font(.system(size: 17, weight: .semibold))
                }
                .accessibilityLabel("导入模型或 ZIP")
            }
            ToolbarItem(placement: .topBarLeading) {
                HStack(spacing: 12) {
                    Button {
                        showLog = true
                    } label: {
                        Image(systemName: "doc.text.magnifyingglass")
                    }
                    .accessibilityLabel("运行日志")
                    Button {
                        showAbout = true
                    } label: {
                        Image(systemName: "info.circle")
                    }
                }
            }
        }
        .sheet(isPresented: $showImporter) {
            MMDDocumentPicker(contentTypes: MMDImportTypes.modelImport,
                              allowsMultipleSelection: true,
                              onPick: { urls in
                                  showImporter = false
                                  importURLs(urls)
                              },
                              onCancel: { showImporter = false })
        }
        .sheet(isPresented: $showAbout) {
            AboutView()
        }
        .sheet(isPresented: $showLog) {
            LogViewer()
        }
        .alert("导入失败", isPresented: Binding(get: { store.errorMessage != nil },
                                               set: { if !$0 { store.errorMessage = nil } })) {
            Button("好", role: .cancel) {}
        } message: {
            Text(store.errorMessage ?? "")
        }
        .alert("导入完成", isPresented: Binding(get: { importNotice != nil },
                                               set: { if !$0 { importNotice = nil } })) {
            Button("好", role: .cancel) {}
        } message: {
            Text(importNotice ?? "")
        }
        .task { store.refresh() }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .firstTextBaseline) {
                Text("MMD")
                    .font(.system(size: 42, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("STUDIO")
                    .font(.system(size: 20, weight: .heavy, design: .rounded))
                    .foregroundStyle(Color(red: 0.25, green: 0.82, blue: 0.9))
            }
            Text("在 iPhone 上导入、编辑与渲染 PMX 模型，播放与生成 VMD 动作。")
                .font(.subheadline)
                .foregroundStyle(.white.opacity(0.65))
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.top, 6)
    }

    private var emptyState: some View {
        VStack(alignment: .leading, spacing: 14) {
            Image(systemName: "cube.transparent")
                .font(.system(size: 44, weight: .light))
                .foregroundStyle(Color(red: 0.25, green: 0.82, blue: 0.9))
            Text("还没有模型")
                .font(.title3.weight(.semibold))
                .foregroundStyle(.white)
            Text("点右上角「+」选择模型文件夹、PMX 或 ZIP。ZIP 会自动解压并保留贴图子目录，最适合分享包里带多张贴图的模型。")
                .font(.subheadline)
                .foregroundStyle(.white.opacity(0.62))
                .fixedSize(horizontal: false, vertical: true)
            Button {
                showImporter = true
            } label: {
                Label("导入模型 / ZIP", systemImage: "square.and.arrow.down")
                    .font(.subheadline.weight(.semibold))
                    .padding(.horizontal, 16)
                    .padding(.vertical, 10)
                    .background(Color(red: 0.25, green: 0.82, blue: 0.9).opacity(0.18))
                    .clipShape(Capsule())
            }
        }
        .padding(24)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
    }

    private var footer: some View {
        Text("支持 PMX 2.0 / 2.1 · 多模型 ZIP 包 · VMD 动作 · DDS/BC7 贴图 · 多种渲染模式 · 截图与录屏\n暂不支持物理刚体与 PMD")
            .font(.caption)
            .foregroundStyle(.white.opacity(0.4))
            .padding(.top, 8)
    }

    private func importURLs(_ urls: [URL]) {
        guard !urls.isEmpty else { return }
        isImporting = true
        DispatchQueue.main.async {
            defer { isImporting = false }
            do {
                let result = try store.importModels(from: urls)
                if !result.warnings.isEmpty {
                    importNotice = result.warnings.joined(separator: "\n")
                } else if result.entries.count > 1 {
                    importNotice = "已导入 \(result.entries.count) 个模型。"
                }
            } catch {
                store.errorMessage = error.localizedDescription
            }
        }
    }
}

private struct ModelCard: View {
    let entry: MMDModelEntry

    var body: some View {
        HStack(spacing: 16) {
            ZStack {
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(LinearGradient(colors: [Color(red: 0.25, green: 0.82, blue: 0.9).opacity(0.35),
                                                  Color(red: 0.55, green: 0.45, blue: 0.95).opacity(0.18)],
                                         startPoint: .topLeading, endPoint: .bottomTrailing))
                Image(systemName: "figure.walk")
                    .font(.system(size: 26, weight: .semibold))
                    .foregroundStyle(.white)
            }
            .frame(width: 64, height: 64)

            VStack(alignment: .leading, spacing: 5) {
                Text(entry.displayName)
                    .font(.headline)
                    .foregroundStyle(.white)
                    .lineLimit(1)
                Text("PMX 模型")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.45))
            }
            Spacer()
            Image(systemName: "chevron.right")
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(.white.opacity(0.35))
        }
        .padding(14)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(Color.white.opacity(0.08), lineWidth: 1)
        )
    }
}

private struct AboutView: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Text("MMD Studio")
                        .font(.largeTitle.weight(.black))
                    Text("原生 SwiftUI + Metal 的 MMD 播放与模型工具。")
                        .foregroundStyle(.secondary)

                    Group {
                        aboutRow("PMX 2.0 / 2.1", "顶点、材质、骨骼、变形、IK 信息解析；支持一个 ZIP/文件夹内的多个 PMX。")
                        aboutRow("VMD 动作", "骨骼与变形关键帧、贝塞尔补间、相机动作；支持视频姿态提取生成实验性 VMD。")
                        aboutRow("贴图", "PNG/JPG/BMP/TGA/DDS，含 DXT1/3/5 与 BC7 解码；保留 PMX 相对路径并支持子目录、大小写和文件名匹配。")
                        aboutRow("渲染", "GPU 蒙皮、卡通/写实/无光照/法线/UV/线框模式、球面贴图、描边、地面阴影、骨骼叠加。")
                        aboutRow("捕获", "画布截图保存到相册；引擎帧录制直接输出 30fps H.264 视频，不包含工具栏和系统状态栏。")
                    }

                    Text("限制")
                        .font(.headline)
                        .padding(.top, 6)
                    Text("当前版本不计算刚体物理与柔软体，不支持 PMD；SDEF 权重按 BDEF2 近似；VMD 相机动作使用简化姿态，忽略 roll；视频转动作是单目估算，不等同于专业动作捕捉。")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                .padding(22)
            }
            .navigationTitle("关于")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("完成") { dismiss() }
                }
            }
        }
    }

    private func aboutRow(_ title: String, _ detail: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title).font(.subheadline.weight(.semibold))
            Text(detail)
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }
}
