import SwiftUI
import UniformTypeIdentifiers

struct ModelScreen: View {

    let entry: MMDModelEntry
    @EnvironmentObject private var store: MMDStore
    @State private var document: MMDModelDocument?
    @State private var loadError: String?

    var body: some View {
        Group {
            if let document {
                ModelViewerView(document: document)
            } else if let loadError {
                VStack(spacing: 14) {
                    Image(systemName: "exclamationmark.triangle")
                        .font(.system(size: 34))
                        .foregroundStyle(.orange)
                    Text("模型加载失败")
                        .font(.headline)
                    Text(loadError)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 30)
                }
            } else {
                ProgressView("正在解析 PMX…")
                    .tint(.cyan)
            }
        }
        .navigationTitle(entry.displayName)
        .navigationBarTitleDisplayMode(.inline)
        .task {
            guard document == nil, loadError == nil else { return }
            do {
                document = try store.open(entry)
            } catch {
                loadError = error.localizedDescription
            }
        }
        .onDisappear { document?.pause() }
    }
}

struct ModelViewerView: View {

    @ObservedObject var document: MMDModelDocument

    @State private var showMaterials = false
    @State private var showMorphs = false
    @State private var showBones = false
    @State private var showSettings = false
    @State private var showLights = false
    @State private var showCamera = false
    @State private var showMotionImporter = false
    @State private var showVideoMotion = false
    @State private var motionError: String?
    @State private var showModelDetails = false
    @State private var toast: String?
    @StateObject private var recorder = MMDScreenRecorder.shared

    var body: some View {
        ZStack {
            MMDMetalView(document: document)
                .ignoresSafeArea(edges: .top)

            VStack {
                HStack(alignment: .top, spacing: 8) {
                    StylePresetStrip(selection: $document.renderSettings.style,
                                     renderMode: $document.renderSettings.renderMode)
                    Spacer(minLength: 8)
                    if document.renderSettings.showPerformanceHUD {
                        performanceBadge
                    }
                }
                .padding(.horizontal, 10)
                .padding(.top, 8)
                Spacer()
            }
            if let toast {
                VStack {
                    Spacer()
                    Text(toast)
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 8)
                        .background(.black.opacity(0.72), in: Capsule())
                        .padding(.bottom, 86)
                }
                .transition(.opacity.combined(with: .move(edge: .bottom)))
                .allowsHitTesting(false)
            }
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            VStack(spacing: 6) {
                StudioCommandBar(
                    showMaterials: $showMaterials,
                    showMorphs: $showMorphs,
                    showBones: $showBones,
                    showLights: $showLights,
                    showCamera: $showCamera,
                    showSettings: $showSettings,
                    showBonesOverlay: document.renderSettings.showBones,
                    isRecording: recorder.isRecording,
                    onResetCamera: {
                        NotificationCenter.default.post(name: .mmdResetCamera, object: nil)
                    },
                    onToggleBones: {
                        document.renderSettings.showBones.toggle()
                    },
                    onPhoto: {
                        NotificationCenter.default.post(name: .mmdCapturePhoto,
                                                        object: NSNumber(value: document.renderSettings.photoScale))
                    },
                    onRecord: {
                        if recorder.isRecording {
                            recorder.stop()
                            toast = "正在保存引擎录制…"
                        } else {
                            recorder.start()
                            toast = "开始引擎录制（不含界面控件）"
                        }
                    }
                )
                compactPlaybackBar
            }
            .padding(.top, 5)
            .background(.black.opacity(0.18))
        }
        .onReceive(NotificationCenter.default.publisher(for: .mmdPhotoCaptured)) { note in
            showToast(note.object as? Bool == true ? "截图已保存到相册" : "截图失败，请查看日志")
        }
        .onReceive(recorder.$lastError.compactMap { $0 }) { error in
            showToast("录制失败：\(error)")
        }
        .onReceive(NotificationCenter.default.publisher(for: .mmdRecordingSaved)) { note in
            showToast(note.object as? Bool == true ? "引擎录制已保存到相册" : "录制保存失败，请查看日志")
        }
        .sheet(isPresented: $showMaterials) {
            MaterialInspectorView(document: document)
        }
        .sheet(isPresented: $showMorphs) {
            MorphInspectorView(document: document)
        }
        .sheet(isPresented: $showBones) {
            BoneInspectorView(document: document)
        }
        .sheet(isPresented: $showLights) {
            NavigationStack { LightingInspectorView(document: document) }
        }
        .sheet(isPresented: $showCamera) {
            CameraStudioView(document: document)
                .presentationDetents([.height(430), .large])
                .presentationDragIndicator(.visible)
        }
        .sheet(isPresented: $showSettings) {
            SettingsInspectorView(document: document)
        }
        .sheet(isPresented: $showVideoMotion) {
            VideoMotionView(document: document)
        }
        .sheet(isPresented: $showMotionImporter) {
            MMDDocumentPicker(contentTypes: MMDImportTypes.motionImport,
                              allowsMultipleSelection: false,
                              onPick: { urls in
                                  showMotionImporter = false
                                  guard let url = urls.first else { return }
                                  loadMotion(url: url)
                              },
                              onCancel: { showMotionImporter = false })
        }
        .alert("动作加载失败", isPresented: Binding(get: { motionError != nil },
                                                   set: { if !$0 { motionError = nil } })) {
            Button("好", role: .cancel) {}
        } message: {
            Text(motionError ?? "")
        }
        .alert("渲染错误", isPresented: Binding(get: { document.errorMessage != nil },
                                               set: { if !$0 { document.errorMessage = nil } })) {
            Button("好", role: .cancel) {}
        } message: {
            Text(document.errorMessage ?? "")
        }
    }

    private var performanceBadge: some View {
        VStack(alignment: .trailing, spacing: 3) {
            HStack(spacing: 8) {
                Text("\(Int(document.renderStats.fps.rounded())) FPS")
                Text(String(format: "%.1f/%.1f ms", document.renderStats.cpuMilliseconds, document.renderStats.gpuMilliseconds))
                if document.renderStats.missingTextures > 0 {
                    Label("\(document.renderStats.missingTextures)", systemImage: "photo.badge.exclamationmark")
                        .foregroundStyle(.orange)
                }
            }
            .font(.caption2.monospacedDigit().weight(.semibold))
            Text("\(document.renderStats.resolution) · \(document.renderStats.qualityLabel)")
                .font(.system(size: 9, weight: .medium, design: .monospaced))
                .foregroundStyle(.white.opacity(0.6))
            if showModelDetails {
                Text("\(document.renderStats.triangles) tris · \(document.renderStats.drawCalls) calls")
                    .font(.system(size: 9, design: .monospaced))
                    .foregroundStyle(.white.opacity(0.55))
            }
        }
        .foregroundStyle(.white.opacity(0.9))
        .padding(.horizontal, 10)
        .padding(.vertical, 7)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
        .onTapGesture {
            withAnimation(.easeOut(duration: 0.2)) { showModelDetails.toggle() }
        }
        .accessibilityLabel("实时渲染性能")
    }

    private var compactPlaybackBar: some View {
        HStack(spacing: 8) {
            if document.hasMotion {
                Button {
                    document.togglePlayback()
                } label: {
                    Image(systemName: document.isPlaying ? "pause.fill" : "play.fill")
                        .font(.system(size: 17, weight: .bold))
                        .frame(width: 32, height: 32)
                        .background(Color(red: 0.25, green: 0.82, blue: 0.9).opacity(0.24), in: Circle())
                }
                .foregroundStyle(.white)
                .accessibilityLabel(document.isPlaying ? "暂停" : "播放")

                Text(document.timeText)
                    .font(.caption2.monospacedDigit())
                    .foregroundStyle(.white.opacity(0.8))
                    .frame(minWidth: 44, alignment: .leading)

                Slider(value: Binding(get: { Double(min(document.currentFrame, document.duration)) },
                                      set: { document.seek(to: Float($0)) }),
                       in: 0...Double(max(document.duration, 0.1)))
                    .tint(Color(red: 0.25, green: 0.82, blue: 0.9))
                    .frame(minWidth: 80)

                Text(document.durationText)
                    .font(.caption2.monospacedDigit())
                    .foregroundStyle(.white.opacity(0.55))
                    .frame(minWidth: 36, alignment: .trailing)

                Menu {
                    Toggle("循环播放", isOn: Binding(get: { document.loopPlayback },
                                                    set: { document.loopPlayback = $0 }))
                    Menu("播放速度") {
                        ForEach([0.5, 1.0, 1.5, 2.0], id: \.self) { speed in
                            Button(String(format: "%.1fx", speed)) {
                                document.playbackSpeed = Float(speed)
                            }
                        }
                    }
                    if !(document.motion?.cameraKeys.isEmpty ?? true) {
                        Toggle("使用 VMD 相机", isOn: Binding(get: { document.useCameraMotion },
                                                            set: { document.useCameraMotion = $0 }))
                    }
                    Button { showMotionImporter = true } label: {
                        Label("更换动作", systemImage: "arrow.triangle.2.circlepath")
                    }
                    Button { showVideoMotion = true } label: {
                        Label("从视频生成动作（实验）", systemImage: "video.badge.waveform")
                    }
                    Button { document.removeMotion() } label: {
                        Label("移除动作", systemImage: "trash")
                    }
                } label: {
                    Image(systemName: "ellipsis.circle")
                        .font(.system(size: 18))
                        .frame(width: 30, height: 30)
                }
                .foregroundStyle(.white.opacity(0.85))
            } else {
                Button {
                    showMotionImporter = true
                } label: {
                    Label("导入 VMD", systemImage: "square.and.arrow.down")
                        .font(.caption.weight(.semibold))
                }
                .foregroundStyle(.white)
                Button {
                    showVideoMotion = true
                } label: {
                    Label("视频转动作", systemImage: "video.badge.waveform")
                        .font(.caption.weight(.semibold))
                }
                .foregroundStyle(Color(red: 0.35, green: 0.85, blue: 0.95))
                Spacer(minLength: 2)
                Text("30 FPS")
                    .font(.system(size: 9, design: .monospaced))
                    .foregroundStyle(.white.opacity(0.45))
            }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(.ultraThinMaterial, in: Capsule())
        .overlay(Capsule().stroke(Color.white.opacity(0.08), lineWidth: 1))
        .padding(.horizontal, 12)
        .padding(.bottom, 4)
    }

    private func showToast(_ text: String) {
        withAnimation(.easeOut(duration: 0.2)) { toast = text }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.2) {
            withAnimation(.easeIn(duration: 0.25)) { toast = nil }
        }
    }

    private func loadMotion(url: URL) {
        let accessed = url.startAccessingSecurityScopedResource()
        defer { if accessed { url.stopAccessingSecurityScopedResource() } }
        do {
            try document.loadMotion(url: url)
        } catch {
            motionError = error.localizedDescription
        }
    }
}

extension Notification.Name {
    static let mmdResetCamera = Notification.Name("mmdResetCameraNotification")
    static let mmdCapturePhoto = Notification.Name("mmdCapturePhotoNotification")
    static let mmdPhotoCaptured = Notification.Name("mmdPhotoCapturedNotification")
    static let mmdCameraPreset = Notification.Name("mmdCameraPresetNotification")
    static let mmdCameraFOV = Notification.Name("mmdCameraFOVNotification")
    static let mmdCameraDistance = Notification.Name("mmdCameraDistanceNotification")
    static let mmdCameraAutoOrbit = Notification.Name("mmdCameraAutoOrbitNotification")
}

/// Persistent style chips. The four game looks live on the canvas so the
/// common render-style switch is one tap, not a nested settings menu.
private struct StylePresetStrip: View {
    @Binding var selection: MMDRenderStyle
    @Binding var renderMode: MMDRenderMode

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 5) {
                ForEach(MMDRenderStyle.allCases) { style in
                    let active = renderMode == .toon && selection == style
                    Button {
                        selection = style
                        renderMode = .toon
                    } label: {
                        Text(style.rawValue)
                            .font(.system(size: 10, weight: .bold, design: .rounded))
                            .foregroundStyle(active ? .black : .white.opacity(0.82))
                            .padding(.horizontal, 9)
                            .padding(.vertical, 6)
                            .background(active ? Color(red: 0.42, green: 0.91, blue: 0.98) : Color.black.opacity(0.40),
                                        in: Capsule())
                            .overlay(Capsule().stroke(Color.white.opacity(active ? 0.0 : 0.10), lineWidth: 1))
                    }
                    .buttonStyle(.plain)
                }
                Button {
                    renderMode = .realistic
                } label: {
                    Text("写实")
                        .font(.system(size: 10, weight: .bold, design: .rounded))
                        .foregroundStyle(renderMode == .realistic ? .black : .white.opacity(0.82))
                        .padding(.horizontal, 9)
                        .padding(.vertical, 6)
                        .background(renderMode == .realistic
                                    ? Color(red: 0.98, green: 0.78, blue: 0.42)
                                    : Color.black.opacity(0.40), in: Capsule())
                        .overlay(Capsule().stroke(Color.white.opacity(renderMode == .realistic ? 0.0 : 0.10), lineWidth: 1))
                }
                .buttonStyle(.plain)
            }
        }
        .frame(maxWidth: 286, alignment: .leading)
        .padding(4)
        .background(.ultraThinMaterial, in: Capsule())
        .overlay(Capsule().stroke(Color.white.opacity(0.08), lineWidth: 1))
    }
}

/// Bottom command bar modelled on a DCC application: direct access to the
/// inspectors used most often. It scrolls horizontally on narrow iPhones.
private struct StudioCommandBar: View {
    @Binding var showMaterials: Bool
    @Binding var showMorphs: Bool
    @Binding var showBones: Bool
    @Binding var showLights: Bool
    @Binding var showCamera: Bool
    @Binding var showSettings: Bool
    let showBonesOverlay: Bool
    let isRecording: Bool
    let onResetCamera: () -> Void
    let onToggleBones: () -> Void
    let onPhoto: () -> Void
    let onRecord: () -> Void

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 2) {
                tool("paintpalette", label: "材质") { showMaterials = true }
                tool("face.smiling", label: "表情") { showMorphs = true }
                tool("figure.walk", label: "骨骼") { showBones = true }
                tool("lightbulb", label: "灯光") { showLights = true }
                tool("camera.aperture", label: "相机") { showCamera = true }
                tool("slider.horizontal.3", label: "设置") { showSettings = true }
                divider
                tool("arrow.counterclockwise", label: "重置") { onResetCamera() }
                tool(showBonesOverlay ? "eye.fill" : "eye", label: "骨架",
                     active: showBonesOverlay) { onToggleBones() }
                divider
                tool("camera.fill", label: "拍照") { onPhoto() }
                tool(isRecording ? "record.circle.fill" : "record.circle",
                     label: isRecording ? "停止" : "录制", active: isRecording) { onRecord() }
            }
            .padding(.horizontal, 6)
        }
        .frame(height: 48)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous)
            .stroke(Color.white.opacity(0.08), lineWidth: 1))
        .padding(.horizontal, 8)
    }

    private var divider: some View {
        Rectangle().fill(Color.white.opacity(0.12)).frame(width: 1, height: 24).padding(.horizontal, 3)
    }

    private func tool(_ systemName: String, label: String, active: Bool = false,
                      action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 3) {
                Image(systemName: systemName)
                    .font(.system(size: 14, weight: .semibold))
                Text(label)
                    .font(.system(size: 9, weight: .medium))
            }
            .frame(width: 46, height: 42)
            .foregroundStyle(active ? Color(red: 0.38, green: 0.90, blue: 0.98) : .white.opacity(0.84))
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(label)
    }
}
