#include <metal_stdlib>
using namespace metal;

struct SceneUniforms {
    float4x4 viewProjection;
    float4x4 view;
    float4x4 model;
    float4x4 normalMatrix;
    float4 lightDirection;
    float4 lightColor;
    float4 ambientColor;
    float4 cameraPosition;
    float4 params;          // x: groundY, y: gridSpacing, z: edgeScale, w: unused
    float4 lightParams;     // x: ambient, y: fill, z: rim, w: exposure
};

struct MaterialUniforms {
    float4 diffuse;
    float4 specular;        // rgb: color, w: power
    float4 ambient;
    float4 edgeColor;
    float4 textureTint;
    float4 sphereTint;
    float4 toonTint;
    float edgeSize;
    float alphaTest;
    int sphereMode;
    uint flags;
    int renderMode;
};

constant uint kFlagHasTexture = 1;
constant uint kFlagHasSphere = 2;
constant uint kFlagHasToon = 4;
constant uint kFlagDoubleSided = 8;
constant uint kFlagOpaque = 16;

struct MeshVertexOut {
    float4 position [[position]];
    float3 worldPosition;
    float3 normal;
    float3 viewNormal;
    float2 uv;
    float edgeScale;
};

// MARK: - Mesh

vertex MeshVertexOut mmd_mesh_vertex(uint vid [[vertex_id]],
                                     device const float3 *positions [[buffer(0)]],
                                     device const float3 *normals [[buffer(1)]],
                                     device const float2 *uvs [[buffer(2)]],
                                     device const uint4 *boneIndices [[buffer(3)]],
                                     device const float4 *weights [[buffer(4)]],
                                     device const float *edgeScales [[buffer(5)]],
                                     constant SceneUniforms &scene [[buffer(6)]],
                                     device const float4x4 *palette [[buffer(7)]]) {
    uint4 bi = boneIndices[vid];
    float4 w = weights[vid];
    float3 position = positions[vid];
    float3 normal = normals[vid];

    float4 skinned = w.x * (palette[bi.x] * float4(position, 1.0))
                   + w.y * (palette[bi.y] * float4(position, 1.0))
                   + w.z * (palette[bi.z] * float4(position, 1.0))
                   + w.w * (palette[bi.w] * float4(position, 1.0));
    float3 skinnedNormal = w.x * (palette[bi.x] * float4(normal, 0.0)).xyz
                         + w.y * (palette[bi.y] * float4(normal, 0.0)).xyz
                         + w.z * (palette[bi.z] * float4(normal, 0.0)).xyz
                         + w.w * (palette[bi.w] * float4(normal, 0.0)).xyz;

    float4 world = scene.model * float4(skinned.xyz, 1.0);
    float3 worldNormal = normalize((scene.normalMatrix * float4(skinnedNormal, 0.0)).xyz);

    MeshVertexOut out;
    out.position = scene.viewProjection * world;
    out.worldPosition = world.xyz;
    out.normal = worldNormal;
    out.viewNormal = normalize((scene.view * float4(worldNormal, 0.0)).xyz);
    out.uv = uvs[vid];
    out.edgeScale = edgeScales[vid];
    return out;
}

fragment float4 mmd_mesh_fragment(MeshVertexOut in [[stage_in]],
                                  bool frontFacing [[front_facing]],
                                  constant SceneUniforms &scene [[buffer(0)]],
                                  constant MaterialUniforms &mat [[buffer(1)]],
                                  texture2d<float> baseMap [[texture(0)]],
                                  texture2d<float> sphereMap [[texture(1)]],
                                  texture2d<float> toonMap [[texture(2)]]) {
    constexpr sampler repeatSampler(address::repeat, filter::linear, mip_filter::linear);
    constexpr sampler clampSampler(address::clamp_to_edge, filter::linear, mip_filter::linear);

    float4 base = mat.diffuse;
    if ((mat.flags & kFlagHasTexture) != 0) {
        float4 texel = baseMap.sample(repeatSampler, in.uv);
        base *= texel;
    }
    base.rgb *= mat.textureTint.rgb;

    float3 N = normalize(in.normal);
    if ((mat.flags & kFlagDoubleSided) != 0 && !frontFacing) {
        N = -N;
    }
    float3 L = normalize(scene.lightDirection.xyz);
    float3 V = normalize(scene.cameraPosition.xyz - in.worldPosition);
    float3 fillDirection = normalize(float3(-L.x, 0.30, -L.z));
    float3 rimDirection = normalize(float3(-V.x, 0.25, -V.z));

    float ambientStrength = clamp(scene.lightParams.x, 0.05, 1.0);
    float fillStrength = clamp(scene.lightParams.y, 0.0, 1.0);
    float rimStrength = clamp(scene.lightParams.z, 0.0, 1.0);
    float exposure = clamp(scene.lightParams.w, 0.5, 2.0);

    float ndl = dot(N, L);
    float litRaw = clamp(ndl * 0.5 + 0.5, 0.0, 1.0);
    float toonValue = litRaw;
    if ((mat.flags & kFlagHasToon) != 0) {
        toonValue = toonMap.sample(clampSampler, float2(litRaw, 0.5)).r * mat.toonTint.r;
    }
    float fill = max(dot(N, fillDirection), 0.0);
    float rim = pow(1.0 - max(dot(N, V), 0.0), 2.0);

    float3 ambientLight = scene.ambientColor.rgb * ambientStrength;
    float3 keyLight = scene.lightColor.rgb * max(ndl, 0.0);
    float3 fillLight = scene.lightColor.rgb * fill * fillStrength;
    float3 rimLight = scene.lightColor.rgb * rim * rimStrength;

    // Keep MMD's toon ramp, but add a soft key/fill/rim model so materials
    // do not collapse into the same flat gray under the old constant ambient.
    float3 color = base.rgb * (ambientLight + keyLight * (0.55 + 0.45 * toonValue)
                               + fillLight * 0.45 + rimLight * 0.65);
    color += mat.specular.rgb * pow(max(dot(N, normalize(L + V)), 0.0),
                                    max(mat.specular.w, 1.0)) * 0.35;
    color += base.rgb * mat.ambient.rgb * 0.12;
    color *= exposure;

    if ((mat.flags & kFlagHasSphere) != 0) {
        float2 sphereUV = in.viewNormal.xy;
        sphereUV = sphereUV * 0.5 + 0.5;
        sphereUV.y = 1.0 - sphereUV.y;
        float4 sphere = sphereMap.sample(clampSampler, sphereUV);
        sphere.rgb *= mat.sphereTint.rgb;
        if (mat.sphereMode == 1) {
            color *= sphere.rgb;
        } else if (mat.sphereMode == 2 || mat.sphereMode == 3) {
            color += sphere.rgb;
        }
    }

    // Alternate inspection modes. They deliberately ignore toon/sphere
    // shading so the geometry and texture mapping can be checked directly.
    if (mat.renderMode == 2) {
        color = base.rgb;
    } else if (mat.renderMode == 3) {
        color = N * 0.5 + 0.5;
    } else if (mat.renderMode == 4) {
        float2 grid = floor(in.uv * 12.0);
        float checker = fmod(grid.x + grid.y, 2.0);
        color = base.rgb * (0.35 + checker * 0.45) + float3(0.08, 0.18, 0.24);
    } else if (mat.renderMode == 5) {
        color = float3(0.20, 0.80, 1.0);
    } else if (mat.renderMode == 1) {
        float3 realistic = ambientLight * 0.85
                         + scene.lightColor.rgb * max(ndl, 0.0) * 0.85
                         + fillLight * 0.50 + rimLight * 0.55;
        color = base.rgb * realistic
              + mat.specular.rgb * pow(max(dot(N, normalize(L + V)), 0.0),
                                       max(mat.specular.w, 1.0)) * 0.45;
        color *= exposure;
    }

    float alpha = base.a;
    if (mat.renderMode >= 2) { alpha = 1.0; }
    if (alpha < mat.alphaTest) { discard_fragment(); }
    return float4(color, alpha);
}

// MARK: - Edge (inverted hull, front faces culled)

struct EdgeVertexOut {
    float4 position [[position]];
};

vertex EdgeVertexOut mmd_edge_vertex(uint vid [[vertex_id]],
                                     device const float3 *positions [[buffer(0)]],
                                     device const float3 *normals [[buffer(1)]],
                                     device const uint4 *boneIndices [[buffer(3)]],
                                     device const float4 *weights [[buffer(4)]],
                                     device const float *edgeScales [[buffer(5)]],
                                     constant SceneUniforms &scene [[buffer(6)]],
                                     constant MaterialUniforms &mat [[buffer(7)]],
                                     device const float4x4 *palette [[buffer(8)]]) {
    uint4 bi = boneIndices[vid];
    float4 w = weights[vid];
    float4 skinned = w.x * (palette[bi.x] * float4(positions[vid], 1.0))
                   + w.y * (palette[bi.y] * float4(positions[vid], 1.0))
                   + w.z * (palette[bi.z] * float4(positions[vid], 1.0))
                   + w.w * (palette[bi.w] * float4(positions[vid], 1.0));
    float3 skinnedNormal = normalize(w.x * (palette[bi.x] * float4(normals[vid], 0.0)).xyz
                         + w.y * (palette[bi.y] * float4(normals[vid], 0.0)).xyz
                         + w.z * (palette[bi.z] * float4(normals[vid], 0.0)).xyz
                         + w.w * (palette[bi.w] * float4(normals[vid], 0.0)).xyz);

    float width = mat.edgeSize * max(edgeScales[vid], 0.0) * 0.025 * scene.params.z;
    float3 pushed = skinned.xyz + skinnedNormal * width;
    EdgeVertexOut out;
    out.position = scene.viewProjection * (scene.model * float4(pushed, 1.0));
    return out;
}

fragment float4 mmd_edge_fragment(constant MaterialUniforms &mat [[buffer(0)]]) {
    return float4(mat.edgeColor.rgb, 1.0);
}

// MARK: - Ground shadow

struct ShadowOut {
    float4 position [[position]];
};

vertex ShadowOut mmd_shadow_vertex(uint vid [[vertex_id]],
                                       device const float3 *positions [[buffer(0)]],
                                       device const uint4 *boneIndices [[buffer(3)]],
                                       device const float4 *weights [[buffer(4)]],
                                       constant SceneUniforms &scene [[buffer(6)]],
                                       device const float4x4 *palette [[buffer(7)]]) {
    uint4 bi = boneIndices[vid];
    float4 w = weights[vid];
    float4 skinned = w.x * (palette[bi.x] * float4(positions[vid], 1.0))
                   + w.y * (palette[bi.y] * float4(positions[vid], 1.0))
                   + w.z * (palette[bi.z] * float4(positions[vid], 1.0))
                   + w.w * (palette[bi.w] * float4(positions[vid], 1.0));
    float4 world = scene.model * float4(skinned.xyz, 1.0);
    world.y = scene.params.x;
    ShadowOut out;
    out.position = scene.viewProjection * world;
    return out;
}

fragment float4 mmd_shadow_fragment() {
    return float4(0.0, 0.0, 0.0, 0.55);
}

// MARK: - Grid

struct OverlayVertex {
    float3 position;
    float4 color;
};

struct OverlayOut {
    float4 position [[position]];
    float4 color;
    float3 worldPosition;
};

vertex OverlayOut mmd_grid_vertex(uint vid [[vertex_id]],
                                  device const OverlayVertex *vertices [[buffer(0)]],
                                  constant SceneUniforms &scene [[buffer(1)]]) {
    OverlayVertex v = vertices[vid];
    OverlayOut out;
    out.position = scene.viewProjection * float4(v.position, 1.0);
    out.color = v.color;
    out.worldPosition = v.position;
    return out;
}

fragment float4 mmd_grid_fragment(OverlayOut in [[stage_in]],
                                  constant SceneUniforms &scene [[buffer(0)]]) {
    float spacing = max(scene.params.y, 0.05);
    float2 coord = in.worldPosition.xz / spacing;
    float2 derivative = fwidth(coord);
    float2 grid = abs(fract(coord - 0.5) - 0.5) / max(derivative, float2(0.0001));
    float line = min(grid.x, grid.y);
    float alpha = (1.0 - min(line, 1.0)) * 0.45;

    float2 majorCoord = in.worldPosition.xz / (spacing * 10.0);
    float2 majorDerivative = fwidth(majorCoord);
    float2 majorGrid = abs(fract(majorCoord - 0.5) - 0.5) / max(majorDerivative, float2(0.0001));
    float majorLine = min(majorGrid.x, majorGrid.y);
    float majorAlpha = (1.0 - min(majorLine, 1.0)) * 0.55;

    float3 color = float3(0.42, 0.45, 0.5);
    color = mix(color, float3(0.6, 0.65, 0.7), float3(majorAlpha / 0.55));

    float distanceToCamera = distance(in.worldPosition, scene.cameraPosition.xyz);
    float fade = clamp(1.0 - distanceToCamera / (spacing * 90.0), 0.0, 1.0);
    alpha = max(alpha, majorAlpha) * fade;
    return float4(color, alpha);
}

// MARK: - Bone overlay

vertex OverlayOut mmd_overlay_vertex(uint vid [[vertex_id]],
                                     device const OverlayVertex *vertices [[buffer(0)]],
                                     constant SceneUniforms &scene [[buffer(1)]]) {
    OverlayVertex v = vertices[vid];
    OverlayOut out;
    out.position = scene.viewProjection * float4(v.position, 1.0);
    out.color = v.color;
    out.worldPosition = v.position;
    return out;
}

fragment float4 mmd_overlay_fragment(OverlayOut in [[stage_in]]) {
    return in.color;
}
