import Foundation
import simd

struct MMDSceneUniforms {
    var viewProjection: simd_float4x4 = matrix_identity_float4x4
    var view: simd_float4x4 = matrix_identity_float4x4
    var model: simd_float4x4 = matrix_identity_float4x4
    var normalMatrix: simd_float4x4 = matrix_identity_float4x4
    var lightDirection: SIMD4<Float> = SIMD4<Float>(0.4, 0.8, 0.5, 0)
    var lightColor: SIMD4<Float> = SIMD4<Float>(1, 1, 1, 1)
    var ambientColor: SIMD4<Float> = SIMD4<Float>(0.35, 0.35, 0.4, 1)
    var cameraPosition: SIMD4<Float> = SIMD4<Float>(0, 2, 30, 1)
    var params: SIMD4<Float> = SIMD4<Float>(0, 1, 1, 0)
    /// x: ambient strength, y: fill strength, z: rim strength, w: exposure
    var lightParams: SIMD4<Float> = SIMD4<Float>(0.28, 0.35, 0.30, 1.0)
}

struct MMDMaterialUniforms {
    var diffuse: SIMD4<Float> = SIMD4<Float>(1, 1, 1, 1)
    var specular: SIMD4<Float> = SIMD4<Float>(0, 0, 0, 1)
    var ambient: SIMD4<Float> = SIMD4<Float>(0, 0, 0, 1)
    var edgeColor: SIMD4<Float> = SIMD4<Float>(0, 0, 0, 1)
    var textureTint: SIMD4<Float> = SIMD4<Float>(1, 1, 1, 1)
    var sphereTint: SIMD4<Float> = SIMD4<Float>(0, 0, 0, 1)
    var toonTint: SIMD4<Float> = SIMD4<Float>(1, 1, 1, 1)
    var edgeSize: Float = 1
    var alphaTest: Float = 0.03
    var sphereMode: Int32 = 0
    var flags: UInt32 = 0
    var renderMode: Int32 = 0
}

enum MMDRenderMode: String, CaseIterable, Identifiable {
    case toon = "标准卡通"
    case realistic = "写实光照"
    case unlit = "无光照"
    case normals = "法线"
    case uv = "UV 检查"
    case wireframe = "线框"

    var id: String { rawValue }
    var index: Int32 {
        switch self {
        case .toon: return 0
        case .realistic: return 1
        case .unlit: return 2
        case .normals: return 3
        case .uv: return 4
        case .wireframe: return 5
        }
    }
    var usesEdges: Bool { self == .toon || self == .realistic }
}

struct MMDOrbitCamera {
    var target: SIMD3<Float> = .zero
    var distance: Float = 30
    var yaw: Float = 0
    var pitch: Float = 0.15
    var fovDegrees: Float = 30

    var eye: SIMD3<Float> {
        let cp = cosf(pitch)
        return SIMD3<Float>(
            target.x + distance * cp * sinf(yaw),
            target.y + distance * sinf(pitch),
            target.z + distance * cp * cosf(yaw)
        )
    }

    mutating func fit(bounds: MMDBox) {
        target = bounds.center
        distance = max(bounds.radius * 4.2, 4)
        pitch = 0.1
        yaw = 0
        fovDegrees = 30
    }

    /// Orbit is normalized by the viewport size instead of using a fixed
    /// radians-per-point value, so a swipe feels the same on every device.
    mutating func orbit(deltaX: Float, deltaY: Float, viewportWidth: Float, viewportHeight: Float) {
        let width = max(160, viewportWidth)
        let height = max(160, viewportHeight)
        yaw -= deltaX / width * 2.6
        pitch = max(-1.35, min(1.35, pitch + deltaY / height * 1.8))
    }

    /// Pan uses the actual perspective footprint at the target depth, which
    /// makes one finger-width of movement match one finger-width on screen.
    mutating func pan(deltaX: Float, deltaY: Float, viewportWidth: Float, viewportHeight: Float) {
        let width = max(160, viewportWidth)
        let height = max(160, viewportHeight)
        let worldPerPoint = 2 * distance * tanf(mmdRadians(fovDegrees) * 0.5) / height
        let right = SIMD3<Float>(cosf(yaw), 0, -sinf(yaw))
        let up = SIMD3<Float>(0, 1, 0)
        target -= right * (deltaX / width * height) * worldPerPoint
        target += up * deltaY * worldPerPoint
    }

    mutating func zoom(scale: Float) {
        distance = max(0.25, min(2000, distance / max(scale, 0.05)))
    }
}

enum MMDQualityMode: String, CaseIterable, Identifiable {
    case auto = "自动"
    case high = "高质量"
    case balanced = "均衡"
    case performance = "性能优先"

    var id: String { rawValue }

    var baseScale: Double {
        switch self {
        case .auto, .high: return 1.0
        case .balanced: return 0.85
        case .performance: return 0.7
        }
    }

    var allowsAdaptiveScale: Bool {
        self == .auto || self == .balanced
    }

    var targetFPS: Int {
        switch self {
        case .auto, .high: return 120
        case .balanced: return 60
        case .performance: return 60
        }
    }
}

struct MMDRenderStats: Equatable {
    var fps: Double = 0
    var frameMilliseconds: Double = 0
    var cpuMilliseconds: Double = 0
    var gpuMilliseconds: Double = 0
    var drawCalls: Int = 0
    var triangles: Int = 0
    var renderScale: Double = 1.0
    var resolution: String = "—"
    var qualityLabel: String = "自动"
    var missingTextures: Int = 0
}

struct MMDRenderSettings {
    var showGrid: Bool = true
    var showBones: Bool = false
    var showGroundShadow: Bool = true
    var edgesEnabled: Bool = true
    var edgeScale: Float = 1.0
    var lightIntensity: Float = 1.0
    var lightAmbient: Float = 0.28
    var lightFill: Float = 0.35
    var lightRim: Float = 0.30
    var exposure: Float = 1.0
    var backgroundColor: SIMD4<Float> = SIMD4<Float>(0.10, 0.11, 0.14, 1.0)
    var toonEnabled: Bool = true
    var renderMode: MMDRenderMode = .toon
    var qualityMode: MMDQualityMode = .auto
    var showPerformanceHUD: Bool = true
    /// Some non-standard PMX exports use the opposite V direction. Metal and
    /// standard PMX both use a top-left texture origin, so this stays off.
    var uvFlipV: Bool = false
}

struct MMDMaterialSettings: Identifiable {
    var id: Int
    var diffuse: SIMD4<Float>
    var edgeColor: SIMD4<Float>
    var edgeSize: Float
    var doubleSided: Bool
    var castsShadow: Bool
    var hasEdge: Bool
    var visible: Bool
    var sphereMode: UInt8
    var useTexture: Bool
    var useToon: Bool

    init(material: PMXMaterial, index: Int) {
        id = index
        diffuse = material.diffuse
        edgeColor = material.edgeColor
        edgeSize = material.edgeSize
        doubleSided = material.isDoubleSided
        castsShadow = material.castsGroundShadow
        hasEdge = material.hasEdge
        visible = true
        sphereMode = material.sphereMode
        useTexture = material.textureIndex >= 0
        useToon = true
    }
}
