import Foundation
import simd

struct MMDSceneUniforms {
    var viewProjection: simd_float4x4 = matrix_identity_float4x4
    var view: simd_float4x4 = matrix_identity_float4x4
    var model: simd_float4x4 = matrix_identity_float4x4
    var normalMatrix: simd_float4x4 = matrix_identity_float4x4
    var lightDirection: SIMD4<Float> = SIMD4<Float>(0.4, 0.8, 0.5, 0)
    var lightColor: SIMD4<Float> = SIMD4<Float>(1, 1, 1, 1)
    var ambientColor: SIMD4<Float> = SIMD4<Float>(0.35, 0.35, 0.4, 1)
    var cameraPosition: SIMD4<Float> = SIMD4<Float>(0, 2, 30, 1)
    var params: SIMD4<Float> = SIMD4<Float>(0, 1, 1, 0)
    /// x: ambient strength, y: fill strength, z: rim strength, w: exposure
    var lightParams: SIMD4<Float> = SIMD4<Float>(0.42, 0.45, 0.35, 1.0)
    /// x: active light count; y: ambient strength; z: exposure
    var lightCount: SIMD4<Float> = SIMD4<Float>(0, 0.42, 1.0, 0)
    var lights: (MMDLightUniform, MMDLightUniform, MMDLightUniform, MMDLightUniform) = MMDLightUniform.defaultTuple
}

/// GPU-side layout. Keep this in sync with `Light` in Shaders.metal.
struct MMDLightUniform {
    var positionOrDirection: SIMD4<Float> = .zero
    var color: SIMD4<Float> = SIMD4<Float>(1, 1, 1, 1)
    /// x: type (0 sun, 1 point, 2 ambient), y: intensity, z: range, w: enabled
    var params: SIMD4<Float> = .zero

    static let zero = MMDLightUniform()
    static let defaultTuple: (MMDLightUniform, MMDLightUniform, MMDLightUniform, MMDLightUniform) =
        (MMDLightUniform(positionOrDirection: SIMD4<Float>(0.4, 0.8, 0.5, 0),
                         color: SIMD4<Float>(1, 1, 1, 1),
                         params: SIMD4<Float>(0, 1, 100, 1)),
         MMDLightUniform(positionOrDirection: SIMD4<Float>(-4, 7, 8, 0),
                         color: SIMD4<Float>(0.55, 0.7, 1.0, 1),
                         params: SIMD4<Float>(1, 0.35, 22, 1)),
         MMDLightUniform(positionOrDirection: SIMD4<Float>(0, 0, 0, 0),
                         color: SIMD4<Float>(0.62, 0.62, 0.68, 1),
                         params: SIMD4<Float>(2, 0.42, 0, 1)),
         MMDLightUniform.zero)
}

struct MMDMaterialUniforms {
    var diffuse: SIMD4<Float> = SIMD4<Float>(1, 1, 1, 1)
    var specular: SIMD4<Float> = SIMD4<Float>(0, 0, 0, 1)
    var ambient: SIMD4<Float> = SIMD4<Float>(0, 0, 0, 1)
    var edgeColor: SIMD4<Float> = SIMD4<Float>(0, 0, 0, 1)
    var textureTint: SIMD4<Float> = SIMD4<Float>(1, 1, 1, 1)
    var sphereTint: SIMD4<Float> = SIMD4<Float>(0, 0, 0, 1)
    var toonTint: SIMD4<Float> = SIMD4<Float>(1, 1, 1, 1)
    var edgeSize: Float = 1
    var alphaTest: Float = 0.03
    var sphereMode: Int32 = 0
    var flags: UInt32 = 0
    var renderMode: Int32 = 0
}

enum MMDRenderMode: String, CaseIterable, Identifiable {
    case toon = "标准卡通"
    case realistic = "写实光照"
    case unlit = "无光照"
    case normals = "法线"
    case uv = "UV 检查"
    case wireframe = "线框"

    var id: String { rawValue }
    var index: Int32 {
        switch self {
        case .toon: return 0
        case .realistic: return 1
        case .unlit: return 2
        case .normals: return 3
        case .uv: return 4
        case .wireframe: return 5
        }
    }
    var usesEdges: Bool { self == .toon || self == .realistic }
}

struct MMDOrbitCamera {
    var target: SIMD3<Float> = .zero
    var distance: Float = 30
    var yaw: Float = 0
    var pitch: Float = 0.15
    var fovDegrees: Float = 30

    var eye: SIMD3<Float> {
        let cp = cosf(pitch)
        return SIMD3<Float>(
            target.x + distance * cp * sinf(yaw),
            target.y + distance * sinf(pitch),
            target.z + distance * cp * cosf(yaw)
        )
    }

    mutating func fit(bounds: MMDBox) {
        target = bounds.center
        distance = max(bounds.radius * 4.2, 4)
        pitch = 0.1
        yaw = 0
        fovDegrees = 30
    }

    /// Orbit is normalized by the viewport size instead of using a fixed
    /// radians-per-point value, so a swipe feels the same on every device.
    mutating func orbit(deltaX: Float, deltaY: Float, viewportWidth: Float, viewportHeight: Float) {
        let width = max(160, viewportWidth)
        let height = max(160, viewportHeight)
        yaw -= deltaX / width * 2.6
        pitch = max(-1.35, min(1.35, pitch + deltaY / height * 1.8))
    }

    /// Pan uses the actual perspective footprint at the target depth, which
    /// makes one finger-width of movement match one finger-width on screen.
    mutating func pan(deltaX: Float, deltaY: Float, viewportWidth: Float, viewportHeight: Float) {
        let width = max(160, viewportWidth)
        let height = max(160, viewportHeight)
        let worldPerPoint = 2 * distance * tanf(mmdRadians(fovDegrees) * 0.5) / height
        let right = SIMD3<Float>(cosf(yaw), 0, -sinf(yaw))
        let up = SIMD3<Float>(0, 1, 0)
        target -= right * (deltaX / width * height) * worldPerPoint
        target += up * deltaY * worldPerPoint
    }

    mutating func zoom(scale: Float) {
        distance = max(0.25, min(2000, distance / max(scale, 0.05)))
    }
}

enum MMDQualityMode: String, CaseIterable, Identifiable {
    case auto = "自动"
    case high = "高质量"
    case balanced = "均衡"
    case performance = "性能优先"

    var id: String { rawValue }

    var baseScale: Double {
        switch self {
        case .auto, .high: return 1.0
        case .balanced: return 0.85
        case .performance: return 0.7
        }
    }

    var allowsAdaptiveScale: Bool {
        self == .auto || self == .balanced
    }

    var targetFPS: Int {
        switch self {
        case .auto, .high: return 120
        case .balanced: return 60
        case .performance: return 60
        }
    }
}

struct MMDRenderStats: Equatable {
    var fps: Double = 0
    var frameMilliseconds: Double = 0
    var cpuMilliseconds: Double = 0
    var gpuMilliseconds: Double = 0
    var drawCalls: Int = 0
    var triangles: Int = 0
    var renderScale: Double = 1.0
    var resolution: String = "—"
    var qualityLabel: String = "自动"
    var missingTextures: Int = 0
}

enum MMDLightKind: String, CaseIterable, Identifiable, Codable {
    case sun = "太阳光"
    case point = "点光源"
    case ambient = "环境光"

    var id: String { rawValue }
    var symbolName: String {
        switch self {
        case .sun: return "sun.max.fill"
        case .point: return "lightbulb.fill"
        case .ambient: return "circle.leeward.half.fill"
        }
    }
}

struct MMDLightSetting: Identifiable, Equatable {
    var id = UUID()
    var name: String
    var kind: MMDLightKind
    var color: SIMD4<Float>
    var intensity: Float
    /// Sun direction (direction from the surface toward the light), normalized.
    var direction: SIMD3<Float>
    /// Point-light world position.
    var position: SIMD3<Float>
    var range: Float
    var enabled: Bool

    static func sun(name: String = "主太阳光") -> MMDLightSetting {
        MMDLightSetting(name: name, kind: .sun,
                        color: SIMD4<Float>(1, 1, 1, 1), intensity: 1.0,
                        direction: SIMD3<Float>(0.4, 0.8, 0.5),
                        position: .zero, range: 100, enabled: true)
    }

    static func fill(name: String = "冷色补光") -> MMDLightSetting {
        MMDLightSetting(name: name, kind: .point,
                        color: SIMD4<Float>(0.55, 0.7, 1.0, 1), intensity: 0.35,
                        direction: SIMD3<Float>(0, 1, 0),
                        position: SIMD3<Float>(-4, 7, 8), range: 22, enabled: true)
    }

    static func ambient(name: String = "环境光") -> MMDLightSetting {
        MMDLightSetting(name: name, kind: .ambient,
                        color: SIMD4<Float>(0.62, 0.62, 0.68, 1), intensity: 0.42,
                        direction: SIMD3<Float>(0, 1, 0),
                        position: .zero, range: 0, enabled: true)
    }

    var uniform: MMDLightUniform {
        let normalizedDirection = simd_length(direction) > 0.0001
            ? simd_normalize(direction)
            : SIMD3<Float>(0.4, 0.8, 0.5)
        let position = kind == .sun
            ? SIMD4<Float>(normalizedDirection.x, normalizedDirection.y, normalizedDirection.z, 0)
            : SIMD4<Float>(self.position.x, self.position.y, self.position.z, 0)
        let type: Float = kind == .sun ? 0 : (kind == .point ? 1 : 2)
        return MMDLightUniform(positionOrDirection: position,
                               color: color,
                               params: SIMD4<Float>(type,
                                                    max(0, intensity),
                                                    max(0.01, range),
                                                    enabled ? 1 : 0))
    }
}

struct MMDRenderSettings {
    var showGrid: Bool = true
    var showBones: Bool = false
    var showGroundShadow: Bool = true
    var edgesEnabled: Bool = true
    var edgeScale: Float = 1.0
    var lightIntensity: Float = 1.0
    var lightAmbient: Float = 0.42
    var lightFill: Float = 0.45
    var lightRim: Float = 0.35
    var exposure: Float = 1.0
    var lights: [MMDLightSetting] = [.sun(), .fill(), .ambient()]
    var backgroundColor: SIMD4<Float> = SIMD4<Float>(0.10, 0.11, 0.14, 1.0)
    var toonEnabled: Bool = true
    var renderMode: MMDRenderMode = .toon
    var qualityMode: MMDQualityMode = .auto
    var showPerformanceHUD: Bool = true
    /// PMX/MMD UVs and Metal's texture origin use opposite V directions for
    /// most exports. Keep this on by default; the toggle remains available
    /// for the occasional model that was authored with flipped UVs.
    var uvFlipV: Bool = true
}

struct MMDMaterialSettings: Identifiable {
    var id: Int
    var diffuse: SIMD4<Float>
    var edgeColor: SIMD4<Float>
    var edgeSize: Float
    var doubleSided: Bool
    var castsShadow: Bool
    var hasEdge: Bool
    var visible: Bool
    var sphereMode: UInt8
    var useTexture: Bool
    var useToon: Bool

    init(material: PMXMaterial, index: Int) {
        id = index
        diffuse = material.diffuse
        edgeColor = material.edgeColor
        edgeSize = material.edgeSize
        doubleSided = material.isDoubleSided
        castsShadow = material.castsGroundShadow
        hasEdge = material.hasEdge
        visible = true
        sphereMode = material.sphereMode
        useTexture = material.textureIndex >= 0
        useToon = true
    }
}
