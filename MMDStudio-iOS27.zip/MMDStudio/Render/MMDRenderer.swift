import Foundation
import Metal
import MetalKit
import QuartzCore
import UIKit
import simd

struct MMDDrawVertex {
    var position: SIMD3<Float>
    var color: SIMD4<Float>
}

final class MMDRenderer: NSObject, MTKViewDelegate {

    private let device: MTLDevice
    private let commandQueue: MTLCommandQueue
    private weak var view: MTKView?
    weak var document: MMDModelDocument?

    private var meshOpaquePipeline: MTLRenderPipelineState!
    private var meshTransparentPipeline: MTLRenderPipelineState!
    private var edgePipeline: MTLRenderPipelineState!
    private var shadowPipeline: MTLRenderPipelineState!
    private var gridPipeline: MTLRenderPipelineState!
    private var overlayPipeline: MTLRenderPipelineState!

    private var opaqueDepthState: MTLDepthStencilState!
    private var overlayDepthState: MTLDepthStencilState!
    private var shadowDepthState: MTLDepthStencilState!

    private var mesh: MMDMesh?
    private var skeleton: MMDSkeleton?
    private var textures: MMDTextureLibrary?
    private var baseDirectory: URL?
    private var fallbackRoot: URL?
    private var loadedRevision = -1
    private var loadedDocumentID: ObjectIdentifier?
    private var loadedUVFlip = false
    private var currentPose: MMDSkeletonPose?
    private var lastMorphWeights: [Float] = []

    var camera = MMDOrbitCamera()
    var onRenderScaleChange: ((CGFloat) -> Void)?

    private var photoCompletion: ((UIImage?) -> Void)?
    private var photoPending = false
    private var engineCaptureHandler: ((Data, Int, Int, Int) -> Void)?
    private var lastEngineCaptureTime: CFTimeInterval = 0
    private let engineCaptureInterval: CFTimeInterval = 1.0 / 30.0

    private var renderScale: CGFloat = 1.0
    private var appliedQuality: MMDQualityMode?
    private var lastQualityCheck = CACurrentMediaTime()
    private var lastAdaptiveChange = CACurrentMediaTime()

    private let statsLock = NSLock()
    private var statsWindowStart = CACurrentMediaTime()
    private var statsFrames = 0
    private var statsCPUSum: Double = 0
    private var statsGPUSum: Double = 0
    private var statsDrawSum = 0
    private var statsTriangleSum = 0
    private var lastDrawCalls = 0
    private var lastTriangles = 0

    private var gridBuffer: MTLBuffer?
    private var gridVertexCount = 0

    private var overlayBuffer: MTLBuffer?
    private var overlayCapacity = 0
    private var overlayAllocated = 0

    private var paletteBuffer: MTLBuffer?
    private var paletteCapacity = 0

    init?(view: MTKView) {
        guard let device = MTLCreateSystemDefaultDevice(),
              let queue = device.makeCommandQueue() else { return nil }
        self.device = device
        self.commandQueue = queue
        self.view = view

        super.init()

        view.device = device
        // Engine recording blits the resolved drawable into a shared buffer.
        // The default framebuffer-only drawable makes that blit illegal.
        view.framebufferOnly = false
        view.colorPixelFormat = .bgra8Unorm_srgb
        view.depthStencilPixelFormat = .depth32Float
        view.sampleCount = 4
        view.preferredFramesPerSecond = max(60, UIScreen.main.maximumFramesPerSecond)
        view.enableSetNeedsDisplay = false
        view.isPaused = false
        view.clearColor = MTLClearColor(red: 0.1, green: 0.11, blue: 0.14, alpha: 1)
        view.delegate = self

        do {
            try buildPipelines(sampleCount: view.sampleCount)
        } catch {
            assertionFailure("Metal pipeline creation failed: \(error)")
            return nil
        }
        textures = MMDTextureLibrary(device: device, commandQueue: queue)
    }

    // MARK: - Pipeline setup

    private func buildPipelines(sampleCount: Int) throws {
        guard let library = device.makeDefaultLibrary() else {
            throw MMDLoadError.io("找不到默认 Metal 着色器库，请确认 Shaders.metal 已加入目标")
        }

        func makePipeline(_ vertex: String, _ fragment: String,
                          blending: Bool,
                          sampleCount: Int) throws -> MTLRenderPipelineState {
            let descriptor = MTLRenderPipelineDescriptor()
            descriptor.vertexFunction = library.makeFunction(name: vertex)
            descriptor.fragmentFunction = library.makeFunction(name: fragment)
            descriptor.colorAttachments[0].pixelFormat = .bgra8Unorm_srgb
            descriptor.depthAttachmentPixelFormat = .depth32Float
            descriptor.rasterSampleCount = sampleCount
            if blending {
                let attachment = descriptor.colorAttachments[0]!
                attachment.isBlendingEnabled = true
                attachment.rgbBlendOperation = .add
                attachment.alphaBlendOperation = .add
                attachment.sourceRGBBlendFactor = .sourceAlpha
                attachment.destinationRGBBlendFactor = .oneMinusSourceAlpha
                attachment.sourceAlphaBlendFactor = .one
                attachment.destinationAlphaBlendFactor = .oneMinusSourceAlpha
            }
            return try device.makeRenderPipelineState(descriptor: descriptor)
        }

        meshOpaquePipeline = try makePipeline("mmd_mesh_vertex", "mmd_mesh_fragment", blending: false, sampleCount: sampleCount)
        meshTransparentPipeline = try makePipeline("mmd_mesh_vertex", "mmd_mesh_fragment", blending: true, sampleCount: sampleCount)
        edgePipeline = try makePipeline("mmd_edge_vertex", "mmd_edge_fragment", blending: false, sampleCount: sampleCount)
        shadowPipeline = try makePipeline("mmd_shadow_vertex", "mmd_shadow_fragment", blending: true, sampleCount: sampleCount)
        gridPipeline = try makePipeline("mmd_grid_vertex", "mmd_grid_fragment", blending: true, sampleCount: sampleCount)
        overlayPipeline = try makePipeline("mmd_overlay_vertex", "mmd_overlay_fragment", blending: true, sampleCount: sampleCount)

        let opaque = MTLDepthStencilDescriptor()
        opaque.depthCompareFunction = .lessEqual
        opaque.isDepthWriteEnabled = true
        opaqueDepthState = device.makeDepthStencilState(descriptor: opaque)

        let overlay = MTLDepthStencilDescriptor()
        overlay.depthCompareFunction = .lessEqual
        overlay.isDepthWriteEnabled = false
        overlayDepthState = device.makeDepthStencilState(descriptor: overlay)

        let shadow = MTLDepthStencilDescriptor()
        shadow.depthCompareFunction = .lessEqual
        shadow.isDepthWriteEnabled = false
        shadowDepthState = device.makeDepthStencilState(descriptor: shadow)
    }

    // MARK: - Document loading

    private func reloadIfNeeded() {
        guard let document else { return }
        let model = document.model
        let identifier = ObjectIdentifier(document)
        let flipV = document.renderSettings.uvFlipV
        if loadedRevision == document.modelRevision && loadedDocumentID == identifier
            && loadedUVFlip == flipV {
            return
        }

        let isDocumentChange = loadedDocumentID != identifier
        do {
            let mesh = try MMDMeshBuilder(device: device).build(model: model, flipV: flipV)
            self.mesh = mesh
            self.skeleton = MMDSkeleton(model: model)
            baseDirectory = document.baseDirectory
            fallbackRoot = document.fallbackRoot
            loadedRevision = document.modelRevision
            loadedDocumentID = identifier
            loadedUVFlip = flipV
            lastMorphWeights = []
            if isDocumentChange {
                camera.fit(bounds: mesh.bounds)
                rebuildGrid(bounds: mesh.bounds)
            }
            refreshMorphPositions(document: document, model: model, force: true)
            textureCacheWillChange()
        } catch {
            mesh = nil
            document.errorMessage = error.localizedDescription
            loadedRevision = document.modelRevision
            loadedDocumentID = identifier
        }
    }

    private func textureCacheWillChange() {
        // The texture library is intentionally retained across draws, but a
        // new mesh/base directory invalidates all resolved paths.
        textures?.clearCache()
    }

    // MARK: - Capture

    /// Captures the next rendered drawable (3D viewport only, no SwiftUI
    /// overlays). The completion is always called on the main queue.
    func capturePhoto(completion: @escaping (UIImage?) -> Void) {
        DispatchQueue.main.async { [weak self] in
            guard let self else { completion(nil); return }
            self.photoCompletion = completion
            self.photoPending = true
            self.view?.setNeedsDisplay()
        }
    }

    /// Starts a per-frame capture used by the engine recorder. The handler is
    /// called off the main thread with tightly packed BGRA rows.
    func setEngineCaptureHandler(_ handler: ((Data, Int, Int, Int) -> Void)?) {
        engineCaptureHandler = handler
        lastEngineCaptureTime = 0
    }

    // MARK: - Camera controls

    func resetCamera() {
        if let mesh { camera.fit(bounds: mesh.bounds) }
        document?.useCameraMotion = false
    }

    /// Camera presets used by the on-canvas camera panel. They always switch
    /// back to a manual camera so a VMD camera track cannot override the view.
    func applyCameraPreset(_ preset: String) {
        guard let mesh else { return }
        let radius = max(mesh.bounds.radius, 0.5)
        var next = camera
        switch preset {
        case "front":
            next.yaw = 0
            next.pitch = 0.1
            next.distance = max(radius * 4.2, 4)
            next.fovDegrees = 30
        case "back":
            next.yaw = .pi
            next.pitch = 0.1
            next.distance = max(radius * 4.2, 4)
            next.fovDegrees = 30
        case "left":
            next.yaw = -.pi / 2
            next.pitch = 0.1
            next.distance = max(radius * 4.2, 4)
            next.fovDegrees = 30
        case "right":
            next.yaw = .pi / 2
            next.pitch = 0.1
            next.distance = max(radius * 4.2, 4)
            next.fovDegrees = 30
        case "top":
            next.yaw = 0
            next.pitch = 1.2
            next.distance = max(radius * 4.6, 4)
            next.fovDegrees = 30
        case "close":
            next.distance = max(radius * 2.2, 2)
            next.fovDegrees = 28
        case "wide":
            next.distance = max(radius * 4.8, 4)
            next.fovDegrees = 48
        default:
            return
        }
        camera = next
        document?.useCameraMotion = false
    }

    func orbitCamera(deltaX: Float, deltaY: Float) {
        document?.useCameraMotion = false
        let width = Float(view?.bounds.width ?? 390)
        let height = Float(view?.bounds.height ?? 700)
        camera.orbit(deltaX: deltaX, deltaY: deltaY,
                     viewportWidth: width, viewportHeight: height)
    }

    func panCamera(deltaX: Float, deltaY: Float) {
        document?.useCameraMotion = false
        let width = Float(view?.bounds.width ?? 390)
        let height = Float(view?.bounds.height ?? 700)
        camera.pan(deltaX: deltaX, deltaY: deltaY,
                  viewportWidth: width, viewportHeight: height)
    }

    func zoomCamera(scale: Float) {
        document?.useCameraMotion = false
        camera.zoom(scale: scale)
    }

    // MARK: - Frame preparation

    private func refreshMorphPositions(document: MMDModelDocument, model: PMXModel, force: Bool = false) {
        guard let mesh else { return }
        let weights = document.effectiveMorphWeights()
        if !force, weights.count == lastMorphWeights.count {
            var same = true
            for index in weights.indices where abs(weights[index] - lastMorphWeights[index]) > 0.0005 {
                same = false
                break
            }
            if same { return }
        }
        let positions = MMDMorphController.positions(model: model,
                                                     weights: MMDMorphController.resolvedWeights(model: model, base: weights))
        mesh.updatePositions(positions)
        lastMorphWeights = weights
    }

    private func makeMaterialUniforms(document: MMDModelDocument, materialIndex: Int,
                                      transparent: Bool, flags: UInt32,
                                      texturePresent: Bool, spherePresent: Bool,
                                      toonPresent: Bool) -> MMDMaterialUniforms {
        let material = document.model.materials[materialIndex]
        let settings = document.materialSettings.indices.contains(materialIndex)
            ? document.materialSettings[materialIndex]
            : MMDMaterialSettings(material: material, index: materialIndex)

        var uniforms = MMDMaterialUniforms()
        uniforms.diffuse = settings.diffuse
        uniforms.specular = SIMD4<Float>(material.specular.x * settings.diffuse.x,
                                        material.specular.y * settings.diffuse.y,
                                        material.specular.z * settings.diffuse.z,
                                        max(1, material.specularPower))
        uniforms.ambient = SIMD4<Float>(material.ambient.x, material.ambient.y, material.ambient.z * settings.diffuse.z, 1)
        uniforms.edgeColor = settings.edgeColor
        uniforms.sphereTint = SIMD4<Float>(1, 1, 1, 1)
        uniforms.edgeSize = max(0, settings.edgeSize) * document.renderSettings.edgeScale
        uniforms.alphaTest = transparent ? 0.0 : 0.03
        uniforms.sphereMode = Int32(settings.sphereMode)
        uniforms.renderMode = document.renderSettings.renderMode.index

        var materialFlags: UInt32 = flags
        if texturePresent { materialFlags |= 1 }
        if spherePresent && settings.sphereMode != 0 { materialFlags |= 2 }
        if toonPresent && settings.useToon && document.renderSettings.toonEnabled { materialFlags |= 4 }
        if settings.doubleSided { materialFlags |= 8 }
        if !transparent { materialFlags |= 16 }
        uniforms.flags = materialFlags
        return uniforms
    }

    private func bindMeshBuffers(_ encoder: MTLRenderCommandEncoder, mesh: MMDMesh) {
        encoder.setVertexBuffer(mesh.positionsBuffer, offset: 0, index: 0)
        encoder.setVertexBuffer(mesh.normalsBuffer, offset: 0, index: 1)
        encoder.setVertexBuffer(mesh.uvsBuffer, offset: 0, index: 2)
        encoder.setVertexBuffer(mesh.boneIndicesBuffer, offset: 0, index: 3)
        encoder.setVertexBuffer(mesh.weightsBuffer, offset: 0, index: 4)
        encoder.setVertexBuffer(mesh.edgeScalesBuffer, offset: 0, index: 5)
    }

    private func setScene(_ scene: MMDSceneUniforms, encoder: MTLRenderCommandEncoder, vertexIndex: Int) {
        var uniforms = scene
        encoder.setVertexBytes(&uniforms, length: MemoryLayout<MMDSceneUniforms>.stride, index: vertexIndex)
    }

    private func setMaterial(_ material: MMDMaterialUniforms, encoder: MTLRenderCommandEncoder, index: Int) {
        var uniforms = material
        encoder.setVertexBytes(&uniforms, length: MemoryLayout<MMDMaterialUniforms>.stride, index: index)
    }

    // MARK: - Quality and performance

    private var autoScale: CGFloat = 1.0
    private var autoLevel = 0

    private var effectiveEdges: Bool {
        guard let document else { return false }
        let settings = document.renderSettings
        guard settings.edgesEnabled, settings.renderMode.usesEdges else { return false }
        if settings.qualityMode == .performance { return false }
        if settings.qualityMode == .auto { return autoLevel < 2 }
        return true
    }

    private var effectiveShadow: Bool {
        guard let document else { return false }
        let settings = document.renderSettings
        guard settings.showGroundShadow else { return false }
        if settings.qualityMode == .performance { return false }
        if settings.qualityMode == .auto { return autoLevel < 2 }
        return true
    }

    private func applyQualityIfNeeded() {
        guard let document else { return }
        let mode = document.renderSettings.qualityMode
        if appliedQuality == mode { return }
        appliedQuality = mode
        switch mode {
        case .auto:
            autoScale = 1.0
            autoLevel = 0
            renderScale = 1.0
            view?.preferredFramesPerSecond = max(60, UIScreen.main.maximumFramesPerSecond)
        case .high:
            renderScale = 1.0
            view?.preferredFramesPerSecond = max(60, UIScreen.main.maximumFramesPerSecond)
        case .balanced:
            renderScale = CGFloat(mode.baseScale)
            view?.preferredFramesPerSecond = 60
        case .performance:
            renderScale = CGFloat(mode.baseScale)
            view?.preferredFramesPerSecond = 60
        }
        onRenderScaleChange?(renderScale)
        lastAdaptiveChange = CACurrentMediaTime()
    }

    private func recordFrame(cpu: Double, gpu: Double, draws: Int, triangles: Int) {
        let now = CACurrentMediaTime()
        var snapshot: (fps: Double, cpu: Double, gpu: Double, draws: Int, tris: Int)?
        statsLock.lock()
        statsFrames += 1
        statsCPUSum += cpu
        statsGPUSum += gpu
        statsDrawSum += draws
        statsTriangleSum += triangles
        let elapsed = now - statsWindowStart
        if elapsed >= 0.5 {
            snapshot = (Double(statsFrames) / max(elapsed, 0.001),
                        statsCPUSum / Double(max(statsFrames, 1)),
                        statsGPUSum / Double(max(statsFrames, 1)),
                        statsDrawSum / max(statsFrames, 1),
                        statsTriangleSum / max(statsFrames, 1))
            statsFrames = 0
            statsCPUSum = 0
            statsGPUSum = 0
            statsDrawSum = 0
            statsTriangleSum = 0
            statsWindowStart = now
        }
        statsLock.unlock()

        guard let snapshot else { return }
        DispatchQueue.main.async { [weak self] in
            self?.applyPerformanceSnapshot(fps: snapshot.fps,
                                           cpu: snapshot.cpu,
                                           gpu: snapshot.gpu,
                                           draws: snapshot.draws,
                                           triangles: snapshot.tris)
        }
    }

    private func applyPerformanceSnapshot(fps: Double, cpu: Double, gpu: Double,
                                          draws: Int, triangles: Int) {
        guard let document else { return }
        var stats = document.renderStats
        stats.fps = fps
        stats.frameMilliseconds = 1000 / max(fps, 0.001)
        stats.cpuMilliseconds = cpu * 1000
        stats.gpuMilliseconds = gpu > 0 ? gpu * 1000 : cpu * 1000
        stats.drawCalls = draws
        stats.triangles = triangles
        stats.renderScale = Double(renderScale)
        stats.resolution = "\(Int((view?.drawableSize.width ?? 0).rounded()))×\(Int((view?.drawableSize.height ?? 0).rounded()))"
        stats.qualityLabel = document.renderSettings.qualityMode.rawValue
            + (document.renderSettings.qualityMode == .auto ? " · \(autoLevel == 0 ? "全质量" : (autoLevel == 1 ? "降采样" : "精简"))" : "")
        stats.missingTextures = textures?.missingCount ?? 0
        document.renderStats = stats
        let names = textures?.missingTextureNames ?? []
        if document.missingTextureNames != names { document.missingTextureNames = names }

        guard document.renderSettings.qualityMode == .auto else { return }
        let now = CACurrentMediaTime()
        guard now - lastAdaptiveChange > 1.0 else { return }
        let target = Double(max(30, view?.preferredFramesPerSecond ?? 60))
        let budget = 1000 / target
        let frameMs = stats.frameMilliseconds
        let tooSlow = frameMs > budget * 1.18 || (gpu > 0 && gpu > budget * 0.95)
        if tooSlow {
            if renderScale > 0.68 {
                autoScale = max(0.65, renderScale - 0.1)
                renderScale = autoScale
                onRenderScaleChange?(renderScale)
            } else if autoLevel < 2 {
                autoLevel += 1
                if autoLevel == 2 {
                    autoScale = 0.7
                    renderScale = autoScale
                    onRenderScaleChange?(renderScale)
                }
            }
            lastAdaptiveChange = now
        } else if frameMs < budget * 0.72, renderScale < 1.0 {
            autoScale = min(1.0, renderScale + 0.05)
            renderScale = autoScale
            onRenderScaleChange?(renderScale)
            lastAdaptiveChange = now
        }
    }

    // MARK: - MTKViewDelegate

    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {
        // MTKView recreates its render targets automatically.
    }

    func draw(in view: MTKView) {
        let cpuStart = CACurrentMediaTime()
        applyQualityIfNeeded()
        reloadIfNeeded()

        if let document {
            view.clearColor = MTLClearColor(red: Double(document.renderSettings.backgroundColor.x),
                                            green: Double(document.renderSettings.backgroundColor.y),
                                            blue: Double(document.renderSettings.backgroundColor.z),
                                            alpha: 1)
        }

        guard let drawable = view.currentDrawable,
              let descriptor = view.currentRenderPassDescriptor,
              let commandBuffer = commandQueue.makeCommandBuffer() else { return }

        guard let encoder = commandBuffer.makeRenderCommandEncoder(descriptor: descriptor) else {
            commandBuffer.present(drawable)
            commandBuffer.commit()
            return
        }

        var drawCalls = 0
        var triangles = 0

        guard let document, let mesh, let skeleton, let textures else {
            encoder.endEncoding()
            commandBuffer.present(drawable)
            commandBuffer.commit()
            return
        }
        let model = document.model

        refreshMorphPositions(document: document, model: model)

        let aspect = Float(max(1, view.drawableSize.width) / max(1, view.drawableSize.height))
        let bounds = mesh.bounds
        let eye: SIMD3<Float>
        let target: SIMD3<Float>
        let fovDegrees: Float

        if document.useCameraMotion, let motion = document.motion, !motion.cameraKeys.isEmpty,
           let pose = VMDMotion.evaluateCamera(keys: motion.cameraKeys, frame: document.currentFrame) {
            eye = pose.eye
            target = pose.target
            fovDegrees = pose.fovDegrees
        } else {
            eye = camera.eye
            target = camera.target
            fovDegrees = camera.fovDegrees
        }

        let radius = max(bounds.radius, 0.5)
        let near = max(0.02, min(camera.distance * 0.02, radius * 0.2))
        let far = max(radius * 8, camera.distance + radius * 6) + 50
        let viewMatrix = mmdLookAt(eye: eye, center: target, up: SIMD3<Float>(0, 1, 0))
        let projection = mmdPerspective(fovYRadians: mmdRadians(fovDegrees), aspect: aspect, near: near, far: far)

        let animations = document.effectiveBoneAnimations(frame: document.currentFrame)
        let pose = skeleton.solve(animations: animations, model: model)
        currentPose = pose

        var scene = MMDSceneUniforms()
        scene.viewProjection = projection * viewMatrix
        scene.view = viewMatrix
        scene.model = matrix_identity_float4x4
        scene.normalMatrix = matrix_identity_float4x4
        let intensity = max(0.2, min(2, document.renderSettings.lightIntensity))
        let lightSettings = document.renderSettings
        let activeLights = Array(lightSettings.lights.filter(\.enabled).prefix(4))
        var lightUniforms = activeLights.map { $0.uniform }
        while lightUniforms.count < 4 { lightUniforms.append(.zero) }
        scene.lights = (lightUniforms[0], lightUniforms[1], lightUniforms[2], lightUniforms[3])
        scene.lightCount = SIMD4<Float>(Float(activeLights.count),
                                        max(0.05, min(1.0, lightSettings.lightAmbient)),
                                        max(0.5, min(2.0, lightSettings.exposure)),
                                        0)
        if let firstSun = lightSettings.lights.first(where: { $0.kind == .sun && $0.enabled }) {
            let direction = simd_length(firstSun.direction) > 0.0001
                ? simd_normalize(firstSun.direction)
                : SIMD3<Float>(0.4, 0.8, 0.5)
            scene.lightDirection = SIMD4<Float>(direction.x, direction.y, direction.z, 0)
            scene.lightColor = SIMD4<Float>(firstSun.color.x * firstSun.intensity,
                                            firstSun.color.y * firstSun.intensity,
                                            firstSun.color.z * firstSun.intensity, 1)
        } else {
            scene.lightDirection = SIMD4<Float>(0.4, 0.8, 0.5, 0)
            scene.lightColor = SIMD4<Float>(0.95 * intensity, 0.95 * intensity, 1.0 * intensity, 1)
        }
        scene.ambientColor = SIMD4<Float>(0.18, 0.18, 0.21, 1)
        scene.lightParams = SIMD4<Float>(max(0.05, min(1.0, lightSettings.lightAmbient)),
                                         max(0.0, min(1.0, lightSettings.lightFill)),
                                         max(0.0, min(1.0, lightSettings.lightRim)),
                                         max(0.5, min(2.0, lightSettings.exposure)))
        scene.cameraPosition = SIMD4<Float>(eye.x, eye.y, eye.z, 1)
        let groundY = bounds.minPoint.y
        let gridSpacing = max(0.05, bounds.height / 20)
        scene.params = SIMD4<Float>(groundY + 0.002, gridSpacing, document.renderSettings.edgeScale, 0)

        encoder.setViewport(MTLViewport(originX: 0, originY: 0,
                                        width: Double(view.drawableSize.width),
                                        height: Double(view.drawableSize.height),
                                        znear: 0, zfar: 1))
        encoder.setCullMode(.none)
        encoder.setFrontFacing(mesh.frontWinding)
        encoder.setTriangleFillMode(document.renderSettings.renderMode == .wireframe ? .lines : .fill)

        // Grid
        if document.renderSettings.showGrid, let gridBuffer, gridVertexCount > 0 {
            encoder.setRenderPipelineState(gridPipeline)
            encoder.setDepthStencilState(overlayDepthState)
            encoder.setVertexBuffer(gridBuffer, offset: 0, index: 0)
            setScene(scene, encoder: encoder, vertexIndex: 1)
            var sceneForFragment = scene
            encoder.setFragmentBytes(&sceneForFragment, length: MemoryLayout<MMDSceneUniforms>.stride, index: 0)
            encoder.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: gridVertexCount)
            drawCalls += 1
            triangles += gridVertexCount / 3
        }

        // Ground shadow
        if effectiveShadow {
            encoder.setRenderPipelineState(shadowPipeline)
            encoder.setDepthStencilState(shadowDepthState)
            bindMeshBuffers(encoder, mesh: mesh)
            setScene(scene, encoder: encoder, vertexIndex: 6)
            if let paletteBuffer = updatePaletteBuffer(pose.palettes) {
                encoder.setVertexBuffer(paletteBuffer, offset: 0, index: 7)
            }
            encoder.setCullMode(.none)
            for submesh in mesh.subMeshes {
                guard document.materialSettings.indices.contains(submesh.materialIndex) else { continue }
                let settings = document.materialSettings[submesh.materialIndex]
                guard settings.visible && settings.castsShadow else { continue }
                encoder.drawIndexedPrimitives(type: .triangle,
                                              indexCount: submesh.indexCount,
                                              indexType: .uint32,
                                              indexBuffer: mesh.indexBuffer,
                                              indexBufferOffset: submesh.indexBufferOffset)
                drawCalls += 1
                triangles += submesh.indexCount / 3
            }
        }

        // Opaque pass
        encoder.setRenderPipelineState(meshOpaquePipeline)
        encoder.setDepthStencilState(opaqueDepthState)
        bindMeshBuffers(encoder, mesh: mesh)
        setScene(scene, encoder: encoder, vertexIndex: 6)
        if let paletteBuffer = updatePaletteBuffer(pose.palettes) {
            encoder.setVertexBuffer(paletteBuffer, offset: 0, index: 7)
        }
        encoder.setFragmentBytes(&scene, length: MemoryLayout<MMDSceneUniforms>.stride, index: 0)

        for submesh in mesh.subMeshes {
            let materialIndex = submesh.materialIndex
            guard document.materialSettings.indices.contains(materialIndex) else { continue }
            let settings = document.materialSettings[materialIndex]
            guard settings.visible, settings.diffuse.w >= 0.999 else { continue }
            let material = model.materials[materialIndex]

            let baseTexture = (settings.useTexture && material.textureIndex >= 0)
                ? textures.embeddedOrFallback(index: material.textureIndex, model: model, baseDirectory: baseDirectory, fallbackRoot: fallbackRoot)
                : textures.whiteTexture
            let sphereTexture = (material.sphereIndex >= 0 && settings.sphereMode != 0)
                ? textures.embeddedOrFallback(index: material.sphereIndex, model: model, baseDirectory: baseDirectory, fallbackRoot: fallbackRoot)
                : textures.whiteTexture
            let toonTexture = textures.toonTexture(for: material, model: model, baseDirectory: baseDirectory, fallbackRoot: fallbackRoot)
            encoder.setFragmentTexture(baseTexture, index: 0)
            encoder.setFragmentTexture(sphereTexture, index: 1)
            encoder.setFragmentTexture(toonTexture, index: 2)

            let uniforms = makeMaterialUniforms(document: document, materialIndex: materialIndex,
                                                transparent: false, flags: 0,
                                                texturePresent: settings.useTexture && material.textureIndex >= 0,
                                                spherePresent: material.sphereIndex >= 0 && settings.sphereMode != 0,
                                                toonPresent: settings.useToon)
            var materialUniforms = uniforms
            encoder.setFragmentBytes(&materialUniforms, length: MemoryLayout<MMDMaterialUniforms>.stride, index: 1)
            encoder.setCullMode(settings.doubleSided ? .none : .back)
            encoder.drawIndexedPrimitives(type: .triangle,
                                          indexCount: submesh.indexCount,
                                          indexType: .uint32,
                                          indexBuffer: mesh.indexBuffer,
                                          indexBufferOffset: submesh.indexBufferOffset)
            drawCalls += 1
            triangles += submesh.indexCount / 3
        }

        // Edge pass
        if effectiveEdges {
            encoder.setRenderPipelineState(edgePipeline)
            encoder.setDepthStencilState(overlayDepthState)
            encoder.setDepthBias(0.0006, slopeScale: 1.2, clamp: 0)
            bindMeshBuffers(encoder, mesh: mesh)
            setScene(scene, encoder: encoder, vertexIndex: 6)
            if let paletteBuffer = updatePaletteBuffer(pose.palettes) {
                encoder.setVertexBuffer(paletteBuffer, offset: 0, index: 8)
            }
            encoder.setCullMode(.front)
            for submesh in mesh.subMeshes {
                let materialIndex = submesh.materialIndex
                guard document.materialSettings.indices.contains(materialIndex) else { continue }
                let settings = document.materialSettings[materialIndex]
                let material = model.materials[materialIndex]
                guard settings.visible, settings.hasEdge, settings.edgeSize > 0,
                      settings.diffuse.w >= 0.999 else { continue }
                let uniforms = makeMaterialUniforms(document: document, materialIndex: materialIndex,
                                                    transparent: false, flags: 0,
                                                    texturePresent: false, spherePresent: false, toonPresent: false)
                var materialUniforms = uniforms
                encoder.setVertexBytes(&materialUniforms, length: MemoryLayout<MMDMaterialUniforms>.stride, index: 7)
                encoder.setFragmentBytes(&materialUniforms, length: MemoryLayout<MMDMaterialUniforms>.stride, index: 0)
                encoder.drawIndexedPrimitives(type: .triangle,
                                              indexCount: submesh.indexCount,
                                              indexType: .uint32,
                                              indexBuffer: mesh.indexBuffer,
                                              indexBufferOffset: submesh.indexBufferOffset)
                drawCalls += 1
                triangles += submesh.indexCount / 3
            }
            encoder.setDepthBias(0, slopeScale: 0, clamp: 0)
        }

        // Transparent pass
        let transparentMeshes = mesh.subMeshes.filter { submesh in
            guard document.materialSettings.indices.contains(submesh.materialIndex) else { return false }
            let settings = document.materialSettings[submesh.materialIndex]
            return settings.visible && settings.diffuse.w < 0.999
        }.sorted { lhs, rhs in
            simd_distance(lhs.center, eye) > simd_distance(rhs.center, eye)
        }

        if !transparentMeshes.isEmpty {
            encoder.setRenderPipelineState(meshTransparentPipeline)
            encoder.setDepthStencilState(overlayDepthState)
            bindMeshBuffers(encoder, mesh: mesh)
            setScene(scene, encoder: encoder, vertexIndex: 6)
            if let paletteBuffer = updatePaletteBuffer(pose.palettes) {
                encoder.setVertexBuffer(paletteBuffer, offset: 0, index: 7)
            }
            encoder.setFragmentBytes(&scene, length: MemoryLayout<MMDSceneUniforms>.stride, index: 0)
            for submesh in transparentMeshes {
                let materialIndex = submesh.materialIndex
                let settings = document.materialSettings[materialIndex]
                let material = model.materials[materialIndex]
                let baseTexture = (settings.useTexture && material.textureIndex >= 0)
                    ? textures.embeddedOrFallback(index: material.textureIndex, model: model, baseDirectory: baseDirectory, fallbackRoot: fallbackRoot)
                    : textures.whiteTexture
                let sphereTexture = (material.sphereIndex >= 0 && settings.sphereMode != 0)
                    ? textures.embeddedOrFallback(index: material.sphereIndex, model: model, baseDirectory: baseDirectory, fallbackRoot: fallbackRoot)
                    : textures.whiteTexture
                let toonTexture = textures.toonTexture(for: material, model: model, baseDirectory: baseDirectory, fallbackRoot: fallbackRoot)
                encoder.setFragmentTexture(baseTexture, index: 0)
                encoder.setFragmentTexture(sphereTexture, index: 1)
                encoder.setFragmentTexture(toonTexture, index: 2)
                let uniforms = makeMaterialUniforms(document: document, materialIndex: materialIndex,
                                                    transparent: true, flags: 0,
                                                    texturePresent: settings.useTexture && material.textureIndex >= 0,
                                                    spherePresent: material.sphereIndex >= 0 && settings.sphereMode != 0,
                                                    toonPresent: settings.useToon)
                var materialUniforms = uniforms
                encoder.setFragmentBytes(&materialUniforms, length: MemoryLayout<MMDMaterialUniforms>.stride, index: 1)
                encoder.setCullMode(settings.doubleSided ? .none : .back)
                encoder.drawIndexedPrimitives(type: .triangle,
                                              indexCount: submesh.indexCount,
                                              indexType: .uint32,
                                              indexBuffer: mesh.indexBuffer,
                                              indexBufferOffset: submesh.indexBufferOffset)
                drawCalls += 1
                triangles += submesh.indexCount / 3
            }
        }

        // Bone overlay
        if document.renderSettings.showBones {
            buildBoneOverlay(document: document, model: model, pose: pose)
            if let overlayBuffer, overlayCapacity > 0 {
                encoder.setRenderPipelineState(overlayPipeline)
                encoder.setDepthStencilState(overlayDepthState)
                encoder.setVertexBuffer(overlayBuffer, offset: 0, index: 0)
                setScene(scene, encoder: encoder, vertexIndex: 1)
                encoder.drawPrimitives(type: .line, vertexStart: 0, vertexCount: overlayCapacity)
                drawCalls += 1
            }
        }

        // Metal allows only one encoder on a command buffer at a time. The
        // optional photo/video blits below must start after the render pass
        // has been closed; creating a blit encoder while the render encoder
        // is still open is invalid and can terminate the process.
        encoder.endEncoding()

        var photoBuffer: MTLBuffer?
        var photoWidth = 0
        var photoHeight = 0
        var photoRowBytes = 0
        if photoPending {
            let texture = drawable.texture
            photoWidth = texture.width
            photoHeight = texture.height
            photoRowBytes = ((photoWidth * 4 + 255) / 256) * 256
            if let buffer = device.makeBuffer(length: photoRowBytes * photoHeight,
                                              options: .storageModeShared),
               let blit = commandBuffer.makeBlitCommandEncoder() {
                blit.copy(from: texture, sourceSlice: 0, sourceLevel: 0,
                          sourceOrigin: MTLOrigin(x: 0, y: 0, z: 0),
                          sourceSize: MTLSize(width: photoWidth, height: photoHeight, depth: 1),
                          to: buffer, destinationOffset: 0,
                          destinationBytesPerRow: photoRowBytes,
                          destinationBytesPerImage: photoRowBytes * photoHeight)
                blit.endEncoding()
                photoBuffer = buffer
            } else {
                DispatchQueue.main.async { [weak self] in
                    self?.photoCompletion?(nil)
                    self?.photoCompletion = nil
                }
            }
            photoPending = false
        }

        var videoBuffer: MTLBuffer?
        var videoWidth = 0
        var videoHeight = 0
        var videoRowBytes = 0
        var videoHandler: ((Data, Int, Int, Int) -> Void)?
        if let handler = engineCaptureHandler {
            let now = CACurrentMediaTime()
            if now - lastEngineCaptureTime >= engineCaptureInterval {
                lastEngineCaptureTime = now
                let texture = drawable.texture
                videoWidth = texture.width
                videoHeight = texture.height
                videoRowBytes = ((videoWidth * 4 + 255) / 256) * 256
                let length = videoRowBytes * videoHeight
                if let buffer = device.makeBuffer(length: length, options: .storageModeShared),
                   let blit = commandBuffer.makeBlitCommandEncoder() {
                    blit.copy(from: texture, sourceSlice: 0, sourceLevel: 0,
                              sourceOrigin: MTLOrigin(x: 0, y: 0, z: 0),
                              sourceSize: MTLSize(width: videoWidth, height: videoHeight, depth: 1),
                              to: buffer, destinationOffset: 0,
                              destinationBytesPerRow: videoRowBytes,
                              destinationBytesPerImage: length)
                    blit.endEncoding()
                    videoBuffer = buffer
                    videoHandler = handler
                } else {
                    DispatchQueue.main.async {
                        NotificationCenter.default.post(name: .mmdStopEngineCapture, object: nil)
                    }
                }
            }
        }

        lastDrawCalls = drawCalls
        lastTriangles = triangles
        let cpuElapsed = CACurrentMediaTime() - cpuStart
        commandBuffer.addCompletedHandler { [weak self] buffer in
            let gpuElapsed = max(0, buffer.gpuEndTime - buffer.gpuStartTime)
            self?.recordFrame(cpu: cpuElapsed, gpu: gpuElapsed,
                              draws: drawCalls, triangles: triangles)
            guard let self else { return }
            if let photoBuffer {
                let image = Self.image(from: photoBuffer,
                                       width: photoWidth, height: photoHeight,
                                       bytesPerRow: photoRowBytes)
                DispatchQueue.main.async {
                    self.photoCompletion?(image)
                    self.photoCompletion = nil
                }
            }
            if let videoBuffer, let videoHandler, videoWidth > 0, videoHeight > 0 {
                let data = Data(bytes: videoBuffer.contents(), count: videoRowBytes * videoHeight)
                DispatchQueue.global(qos: .userInitiated).async {
                    videoHandler(data, videoWidth, videoHeight, videoRowBytes)
                }
            }
        }

        commandBuffer.present(drawable)
        commandBuffer.commit()
    }

    // MARK: - Helpers

    private static func image(from buffer: MTLBuffer, width: Int, height: Int,
                              bytesPerRow: Int) -> UIImage? {
        guard width > 0, height > 0, bytesPerRow >= width * 4 else { return nil }
        let length = bytesPerRow * height
        guard length > 0, buffer.length >= length else { return nil }
        let data = Data(bytes: buffer.contents(), count: length)
        guard let provider = CGDataProvider(data: data as CFData) else { return nil }
        let colorSpace = CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB()
        let bitmapInfo = CGBitmapInfo.byteOrder32Little.rawValue | CGImageAlphaInfo.premultipliedFirst.rawValue
        guard let cgImage = CGImage(width: width, height: height,
                                    bitsPerComponent: 8, bitsPerPixel: 32,
                                    bytesPerRow: bytesPerRow, space: colorSpace,
                                    bitmapInfo: CGBitmapInfo(rawValue: bitmapInfo),
                                    provider: provider, decode: nil,
                                    shouldInterpolate: true, intent: .defaultIntent) else {
            return nil
        }
        return UIImage(cgImage: cgImage, scale: UIScreen.main.scale, orientation: .up)
    }

    private func rebuildGrid(bounds: MMDBox) {
        let groundY = bounds.minPoint.y
        let extent = max(bounds.radius * 40, 60)
        let corners: [SIMD3<Float>] = [
            SIMD3<Float>(-extent, groundY, -extent),
            SIMD3<Float>(extent, groundY, -extent),
            SIMD3<Float>(extent, groundY, extent),
            SIMD3<Float>(-extent, groundY, -extent),
            SIMD3<Float>(extent, groundY, extent),
            SIMD3<Float>(-extent, groundY, extent)
        ]
        let vertices = corners.map { MMDDrawVertex(position: $0, color: SIMD4<Float>(1, 1, 1, 1)) }
        gridVertexCount = vertices.count
        gridBuffer = device.makeBuffer(bytes: vertices,
                                       length: MemoryLayout<MMDDrawVertex>.stride * vertices.count,
                                       options: .storageModeShared)
    }

    private func ensureOverlayCapacity(_ count: Int) -> MTLBuffer? {
        if let overlayBuffer, overlayAllocated >= count { return overlayBuffer }
        let capacity = max(count, 256)
        overlayAllocated = capacity
        let buffer = device.makeBuffer(length: MemoryLayout<MMDDrawVertex>.stride * capacity,
                                       options: .storageModeShared)
        overlayBuffer = buffer
        overlayCapacity = capacity
        return buffer
    }

    private func updatePaletteBuffer(_ palettes: [simd_float4x4]) -> MTLBuffer? {
        guard !palettes.isEmpty else { return nil }
        if paletteBuffer == nil || paletteCapacity < palettes.count {
            paletteCapacity = palettes.count
            paletteBuffer = device.makeBuffer(length: MemoryLayout<simd_float4x4>.stride * palettes.count,
                                              options: .storageModeShared)
        }
        guard let paletteBuffer else { return nil }
        let pointer = paletteBuffer.contents().bindMemory(to: simd_float4x4.self, capacity: palettes.count)
        for index in palettes.indices { pointer[index] = palettes[index] }
        return paletteBuffer
    }

    private func buildBoneOverlay(document: MMDModelDocument, model: PMXModel, pose: MMDSkeletonPose) {
        guard !model.bones.isEmpty, pose.worldMatrices.count == model.bones.count else {
            overlayCapacity = 0
            return
        }
        var vertices = [MMDDrawVertex]()
        vertices.reserveCapacity(model.bones.count * 4)

        let normalColor = SIMD4<Float>(0.25, 0.85, 1.0, 0.62)
        let selectedColor = SIMD4<Float>(1.0, 0.62, 0.18, 1.0)
        let highlightColor = SIMD4<Float>(1.0, 0.85, 0.3, 0.9)

        for (index, bone) in model.bones.enumerated() {
            let position = pose.worldMatrices[index].translation
            if bone.parentIndex >= 0 && bone.parentIndex < model.bones.count {
                let parent = pose.worldMatrices[bone.parentIndex].translation
                let color = index == document.selectedBoneIndex ? selectedColor : normalColor
                vertices.append(MMDDrawVertex(position: position, color: color))
                vertices.append(MMDDrawVertex(position: parent, color: color))
            }
            if bone.tailIndex >= 0 && bone.tailIndex < model.bones.count {
                let tail = pose.worldMatrices[bone.tailIndex].translation
                vertices.append(MMDDrawVertex(position: position, color: normalColor))
                vertices.append(MMDDrawVertex(position: tail, color: normalColor))
            }
        }

        if document.selectedBoneIndex >= 0 && document.selectedBoneIndex < model.bones.count {
            let center = pose.worldMatrices[document.selectedBoneIndex].translation
            let size = max(model.bounds.height * 0.015, 0.02)
            let axes: [SIMD3<Float>] = [
                SIMD3<Float>(1, 0, 0), SIMD3<Float>(0, 1, 0), SIMD3<Float>(0, 0, 1)
            ]
            for axis in axes {
                vertices.append(MMDDrawVertex(position: center - axis * size, color: selectedColor))
                vertices.append(MMDDrawVertex(position: center + axis * size, color: selectedColor))
            }
            if let ik = model.bones[document.selectedBoneIndex].ik, ik.targetIndex >= 0 && ik.targetIndex < model.bones.count {
                let target = pose.worldMatrices[ik.targetIndex].translation
                vertices.append(MMDDrawVertex(position: center, color: highlightColor))
                vertices.append(MMDDrawVertex(position: target, color: highlightColor))
            }
        }

        guard !vertices.isEmpty, let buffer = ensureOverlayCapacity(vertices.count) else {
            overlayCapacity = 0
            return
        }
        let raw = buffer.contents().bindMemory(to: MMDDrawVertex.self, capacity: vertices.count)
        for index in vertices.indices {
            raw[index] = vertices[index]
        }
        overlayCapacity = vertices.count
    }
}
