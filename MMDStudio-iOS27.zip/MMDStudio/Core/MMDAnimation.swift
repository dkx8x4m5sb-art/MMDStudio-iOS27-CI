import Foundation
import simd

struct MMDBoneAnimation {
    var position: SIMD3<Float> = .zero
    var rotation: simd_quatf = mmdIdentityQuaternion
}

struct MMDSkeletonPose {
    var worldMatrices: [simd_float4x4]
    var palettes: [simd_float4x4]
}

/// Computes skinning matrices for the PMX skeleton.
final class MMDSkeleton {

    let boneCount: Int
    private let parentIndices: [Int]
    private let restLocal: [SIMD3<Float>]
    private let order: [Int]
    private let inverseBind: [simd_float4x4]
    let restWorld: [simd_float4x4]

    init(model: PMXModel) {
        boneCount = model.bones.count
        parentIndices = model.bones.map { $0.parentIndex }
        var locals = [SIMD3<Float>](repeating: .zero, count: model.bones.count)
        for (index, bone) in model.bones.enumerated() {
            if bone.parentIndex >= 0 && bone.parentIndex < model.bones.count {
                locals[index] = bone.position - model.bones[bone.parentIndex].position
            } else {
                locals[index] = bone.position
            }
        }
        restLocal = locals

        var order = [Int]()
        order.reserveCapacity(model.bones.count)
        var visited = [Bool](repeating: false, count: model.bones.count)
        for bone in model.bones.indices where !visited[bone] {
            var chain = [Int]()
            var cursor = bone
            var guardCount = 0
            while cursor >= 0 && cursor < model.bones.count && !visited[cursor] && guardCount <= model.bones.count {
                chain.append(cursor)
                cursor = model.bones[cursor].parentIndex
                guardCount += 1
            }
            while let item = chain.popLast() {
                if !visited[item] {
                    visited[item] = true
                    order.append(item)
                }
            }
        }
        self.order = order

        var worlds = [simd_float4x4](repeating: matrix_identity_float4x4, count: model.bones.count)
        for index in order {
            let local = simd_float4x4.translation(locals[index])
            let parent = parentIndices[index]
            worlds[index] = (parent >= 0 ? worlds[parent] : matrix_identity_float4x4) * local
        }
        restWorld = worlds
        inverseBind = worlds.map { simd_inverse($0) }
    }

    func solve(animations: [Int: MMDBoneAnimation], model: PMXModel) -> MMDSkeletonPose {
        guard boneCount > 0 else {
            return MMDSkeletonPose(worldMatrices: [], palettes: [matrix_identity_float4x4])
        }

        var worlds = [simd_float4x4](repeating: matrix_identity_float4x4, count: boneCount)
        for index in order {
            let bone = model.bones[index]
            let animation = animations[index] ?? MMDBoneAnimation()
            var localTranslation = restLocal[index] + animation.position
            var localRotation = animation.rotation

            if bone.appendParent >= 0 && bone.appendParent < boneCount && abs(bone.appendRatio) > 0.0001 {
                let append = animations[bone.appendParent] ?? MMDBoneAnimation()
                let ratio = bone.appendRatio
                let extraRotation = quatSlerp(mmdIdentityQuaternion, append.rotation, ratio)
                localRotation = localRotation * extraRotation
                if bone.inheritsTranslation {
                    localTranslation += append.position * ratio
                }
            }

            let local = simd_float4x4.translation(localTranslation) * simd_float4x4(quaternion: localRotation)
            let parent = parentIndices[index]
            worlds[index] = (parent >= 0 ? worlds[parent] : matrix_identity_float4x4) * local
        }

        var palettes = [simd_float4x4](repeating: matrix_identity_float4x4, count: boneCount)
        for index in 0..<boneCount {
            palettes[index] = worlds[index] * inverseBind[index]
        }
        return MMDSkeletonPose(worldMatrices: worlds, palettes: palettes)
    }

    func boneWorldPositions(_ pose: MMDSkeletonPose) -> [SIMD3<Float>] {
        pose.worldMatrices.map { $0.translation }
    }
}

/// Combines UI morph weights and VMD morph tracks.
final class MMDMorphController {

    static func resolvedWeights(model: PMXModel, base: [Float]) -> [Float] {
        guard !model.morphs.isEmpty else { return base }
        var weights = base.count == model.morphs.count ? base : [Float](repeating: 0, count: model.morphs.count)
        // Propagate group morphs a few levels down; PMX groups are normally shallow.
        for _ in 0..<3 {
            var additions = [Float](repeating: 0, count: model.morphs.count)
            for (index, morph) in model.morphs.enumerated() where morph.isGroup && abs(weights[index]) > 0.0001 {
                for item in morph.groupItems {
                    guard item.morphIndex >= 0 && item.morphIndex < additions.count else { continue }
                    additions[item.morphIndex] += weights[index] * item.ratio
                }
            }
            var changed = false
            for index in weights.indices where abs(additions[index]) > 0.00001 {
                weights[index] += additions[index]
                changed = true
            }
            if !changed { break }
        }
        return weights
    }

    static func positions(model: PMXModel, weights: [Float]) -> [SIMD3<Float>] {
        let base = model.vertices.map { $0.position }
        guard !model.morphs.isEmpty, weights.count == model.morphs.count else { return base }
        var result = base
        for (morphIndex, morph) in model.morphs.enumerated() {
            let weight = weights[morphIndex]
            guard morph.isVertex && abs(weight) > 0.00001 else { continue }
            for offset in morph.vertexOffsets {
                guard offset.vertexIndex >= 0 && offset.vertexIndex < result.count else { continue }
                result[offset.vertexIndex] += offset.offset * weight
            }
        }
        return result
    }
}

// MARK: - Humanoid rig mapping

enum MMDHumanoidJoint: String, CaseIterable, Identifiable, Hashable {
    case center
    case lowerBody
    case upperBody
    case upperBody2
    case neck
    case head
    case leftShoulder
    case rightShoulder
    case leftUpperArm
    case rightUpperArm
    case leftForearm
    case rightForearm
    case leftHand
    case rightHand
    case leftThigh
    case rightThigh
    case leftShin
    case rightShin
    case leftFoot
    case rightFoot

    var id: String { rawValue }

    var label: String {
        switch self {
        case .center: return "中心"
        case .lowerBody: return "下半身"
        case .upperBody: return "上半身"
        case .upperBody2: return "上半身2"
        case .neck: return "首"
        case .head: return "头"
        case .leftShoulder: return "左肩"
        case .rightShoulder: return "右肩"
        case .leftUpperArm: return "左腕"
        case .rightUpperArm: return "右腕"
        case .leftForearm: return "左肘"
        case .rightForearm: return "右肘"
        case .leftHand: return "左手"
        case .rightHand: return "右手"
        case .leftThigh: return "左腿"
        case .rightThigh: return "右腿"
        case .leftShin: return "左膝"
        case .rightShin: return "右膝"
        case .leftFoot: return "左足"
        case .rightFoot: return "右足"
        }
    }

    var aliases: [String] {
        switch self {
        case .center:
            return ["センター", "center", "centre", "pelvis", "hips", "hip", "root", "waist"]
        case .lowerBody:
            return ["下半身", "lowerbody", "lower_body", "hips", "pelvis"]
        case .upperBody:
            return ["上半身", "spine", "chest", "upperbody", "upper_body", "torso", "abdomen"]
        case .upperBody2:
            return ["上半身2", "upperchest", "upper_chest", "chest2", "spine2"]
        case .neck:
            return ["首", "neck"]
        case .head:
            return ["頭", "head"]
        case .leftShoulder:
            return ["左肩", "leftshoulder", "left_shoulder", "clavicle_l", "l_clavicle", "shoulder_l"]
        case .rightShoulder:
            return ["右肩", "rightshoulder", "right_shoulder", "clavicle_r", "r_clavicle", "shoulder_r"]
        case .leftUpperArm:
            return ["左腕", "leftupperarm", "left_upper_arm", "upperarm_l", "arm_l", "l_arm", "leftarm"]
        case .rightUpperArm:
            return ["右腕", "rightupperarm", "right_upper_arm", "upperarm_r", "arm_r", "r_arm", "rightarm"]
        case .leftForearm:
            return ["左ひじ", "左肘", "leftforearm", "left_forearm", "forearm_l", "elbow_l", "l_elbow"]
        case .rightForearm:
            return ["右ひじ", "右肘", "rightforearm", "right_forearm", "forearm_r", "elbow_r", "r_elbow"]
        case .leftHand:
            return ["左手首", "left hand", "left_hand", "hand_l", "wrist_l"]
        case .rightHand:
            return ["右手首", "right hand", "right_hand", "hand_r", "wrist_r"]
        case .leftThigh:
            return ["左足", "leftthigh", "left_thigh", "thigh_l", "leg_l", "upperleg_l"]
        case .rightThigh:
            return ["右足", "rightthigh", "right_thigh", "thigh_r", "leg_r", "upperleg_r"]
        case .leftShin:
            return ["左ひざ", "左膝", "leftshin", "left_shin", "shin_l", "knee_l", "calf_l"]
        case .rightShin:
            return ["右ひざ", "右膝", "rightshin", "right_shin", "shin_r", "knee_r", "calf_r"]
        case .leftFoot:
            return ["左足首", "leftfoot", "left_foot", "foot_l", "ankle_l"]
        case .rightFoot:
            return ["右足首", "rightfoot", "right_foot", "foot_r", "ankle_r"]
        }
    }

    static func matching(trackName: String) -> MMDHumanoidJoint? {
        let key = MMDModelDocument.normalizedBoneName(trackName)
        guard !key.isEmpty else { return nil }
        for joint in allCases {
            if joint.aliases.map(MMDModelDocument.normalizedBoneName).contains(key) {
                return joint
            }
        }
        return nil
    }

    /// Conservative local-Euler limits (degrees). X is the main bend axis for
    /// elbows/knees; the other axes are kept narrow to prevent twist.
    var rotationLimit: (x: (Float, Float), y: (Float, Float), z: (Float, Float)) {
        switch self {
        case .leftForearm, .rightForearm, .leftShin, .rightShin:
            return ((-165, 10), (-40, 40), (-30, 30))
        case .leftThigh, .rightThigh:
            return ((-125, 60), (-50, 50), (-45, 45))
        case .neck:
            return ((-45, 45), (-60, 60), (-35, 35))
        case .head:
            return ((-55, 55), (-70, 70), (-45, 45))
        case .leftShoulder, .rightShoulder:
            return ((-80, 80), (-45, 45), (-80, 80))
        case .leftUpperArm, .rightUpperArm:
            return ((-150, 150), (-90, 90), (-120, 120))
        case .leftHand, .rightHand, .leftFoot, .rightFoot:
            return ((-90, 90), (-60, 60), (-60, 60))
        case .center, .lowerBody, .upperBody, .upperBody2:
            return ((-60, 60), (-60, 60), (-60, 60))
        }
    }

    func constrained(_ degrees: SIMD3<Float>) -> SIMD3<Float> {
        let limit = rotationLimit
        return SIMD3<Float>(
            max(limit.x.0, min(limit.x.1, degrees.x)),
            max(limit.y.0, min(limit.y.1, degrees.y)),
            max(limit.z.0, min(limit.z.1, degrees.z))
        )
    }
}

enum MMDPosePreset: String, CaseIterable, Identifiable {
    case neutral = "自然站姿"
    case aPose = "A-Pose"
    case tPose = "T-Pose"
    case wave = "右手招手"
    case sit = "坐姿"

    var id: String { rawValue }
}

/// A tiny secondary-motion solver for hair/skirt/ribbon chains. It is a
/// spring-damper model, not full PMX rigid-body simulation, but it gives the
/// skirt and hair visible follow-through without changing the authored rig.
struct MMDPhysicsSettings {
    var enabled: Bool = true
    var gravity: Float = 0.55
    var stiffness: Float = 0.45
    var damping: Float = 0.72
    var wind: Float = 0.18
}

final class MMDSpringPhysics {
    private var offsets: [Int: SIMD3<Float>] = [:]
    private var velocities: [Int: SIMD3<Float>] = [:]
    private var phases: [Int: Float] = [:]
    private var secondaryBones: [Int] = []
    private var lastTime: CFTimeInterval = 0
    private var lastBodyRotation: simd_quatf = mmdIdentityQuaternion

    private let keywords = ["髪", "hair", "skirt", "スカート", "ribbon", "リボン",
                            "tail", "尾", "cape", "マント", "袖", "sleeve", "breast", "胸"]

    func reset() {
        offsets.removeAll()
        velocities.removeAll()
        lastTime = 0
        lastBodyRotation = mmdIdentityQuaternion
    }

    func prepare(model: PMXModel) {
        secondaryBones = model.bones.indices.filter { index in
            let lower = model.bones[index].name.lowercased()
            return keywords.contains { lower.contains($0) }
        }
        for index in secondaryBones {
            if phases[index] == nil { phases[index] = Float(index % 11) * 0.37 }
        }
    }

    func apply(animations: [Int: MMDBoneAnimation], model: PMXModel,
               settings: MMDPhysicsSettings, time: CFTimeInterval) -> [Int: MMDBoneAnimation] {
        guard settings.enabled, !secondaryBones.isEmpty else { return animations }
        let dt = lastTime > 0 ? min(0.05, max(0.001, time - lastTime)) : 1.0 / 60.0
        lastTime = time

        let centerIndex = model.bones.firstIndex {
            $0.name == "センター" || $0.name.lowercased().contains("center")
        }
        let bodyRotation = centerIndex.flatMap { animations[$0]?.rotation } ?? mmdIdentityQuaternion
        let delta = bodyRotation * lastBodyRotation.inverse
        let bodyAngle = quatEulerDegrees(delta)
        lastBodyRotation = bodyRotation

        var result = animations
        let gravity = settings.gravity
        let stiffness = max(0.05, settings.stiffness)
        let damping = max(0.05, settings.damping)
        let wind = settings.wind

        for index in secondaryBones {
            guard index >= 0 && index < model.bones.count else { continue }
            let phase = phases[index] ?? 0
            let sway = sinf(Float(time) * (1.1 + wind * 1.5) + phase)
            var offset = offsets[index] ?? .zero
            var velocity = velocities[index] ?? .zero

            // Gravity pulls the chain down, wind pushes it sideways, and the
            // body's angular motion excites a lagged swing. The coefficients
            // are deliberately small; this is a secondary-motion layer.
            var force = SIMD3<Float>(
                -gravity * 0.6 + sway * wind * 7.0,
                bodyAngle.y * 0.08,
                -bodyAngle.x * 0.10 + cosf(Float(time) * 1.7 + phase) * wind * 5.0
            )
            force += -stiffness * offset - damping * velocity
            velocity += force * Float(dt)
            offset += velocity * Float(dt)
            offset.x = max(-18, min(18, offset.x))
            offset.y = max(-14, min(14, offset.y))
            offset.z = max(-18, min(18, offset.z))
            offsets[index] = offset
            velocities[index] = velocity

            var animation = result[index] ?? MMDBoneAnimation()
            let offsetRotation = quatFromEuler(SIMD3<Float>(
                mmdRadians(offset.x), mmdRadians(offset.y), mmdRadians(offset.z)))
            animation.rotation = animation.rotation * offsetRotation
            result[index] = animation
        }
        return result
    }
}
