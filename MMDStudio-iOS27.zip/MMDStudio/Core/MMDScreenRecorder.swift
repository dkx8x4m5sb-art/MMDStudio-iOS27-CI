import Foundation
import ReplayKit
import UIKit

/// Records the app screen (including the MMD viewport) with ReplayKit and
/// shows the standard system preview so the clip can be saved or shared.
final class MMDScreenRecorder: NSObject, ObservableObject, RPPreviewViewControllerDelegate {

    static let shared = MMDScreenRecorder()

    @Published private(set) var isRecording = false
    @Published private(set) var lastError: String?

    private var previewController: RPPreviewViewController?

    private override init() {
        super.init()
    }

    func toggle() {
        if isRecording { stop() } else { start() }
    }

    func start() {
        guard !isRecording else { return }
        let recorder = RPScreenRecorder.shared()
        recorder.isMicrophoneEnabled = false
        recorder.startRecording { [weak self] error in
            DispatchQueue.main.async {
                guard let self else { return }
                if let error {
                    self.lastError = error.localizedDescription
                    MMDLog.shared.error("ReplayKit start failed: \(error.localizedDescription)")
                } else {
                    self.isRecording = true
                    self.lastError = nil
                    MMDLog.shared.info("ReplayKit recording started")
                }
            }
        }
    }

    func stop() {
        guard isRecording else { return }
        RPScreenRecorder.shared().stopRecording { [weak self] preview, error in
            DispatchQueue.main.async {
                guard let self else { return }
                self.isRecording = false
                if let error {
                    self.lastError = error.localizedDescription
                    MMDLog.shared.error("ReplayKit stop failed: \(error.localizedDescription)")
                    return
                }
                MMDLog.shared.info("ReplayKit recording stopped")
                if let preview {
                    preview.previewControllerDelegate = self
                    self.previewController = preview
                    self.present(preview)
                }
            }
        }
    }

    func previewControllerDidFinish(_ previewController: RPPreviewViewController) {
        previewController.dismiss(animated: true)
        self.previewController = nil
    }

    private func present(_ controller: RPPreviewViewController) {
        var top = UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap { $0.windows }
            .first { $0.isKeyWindow }?.rootViewController
        while let presented = top?.presentedViewController { top = presented }
        top?.present(controller, animated: true)
    }
}
