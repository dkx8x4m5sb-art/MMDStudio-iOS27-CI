import Foundation
import AVFoundation
import Vision
import simd

/// Experimental monocular motion capture: samples a video with Apple's
/// on-device body-pose estimator, converts limb angles into local bone
/// rotations and writes a standard VMD 0002 file. It works best with a
/// front-facing, full-body dance clip and a static camera.
final class MMDVideoMotionExtractor {

    struct Result {
        let url: URL
        let sampledFrames: Int
        let detectedFrames: Int
    }

    enum ExtractError: LocalizedError {
        case noVideoTrack
        case cannotRead
        case noPose
        case writeFailed

        var errorDescription: String? {
            switch self {
            case .noVideoTrack: return "视频中没有可读取的画面轨道。"
            case .cannotRead: return "无法读取视频，请换一个 MP4/MOV 文件。"
            case .noPose: return "视频中没有检测到完整人体姿态。请使用正面、全身、光线充足的舞蹈视频。"
            case .writeFailed: return "无法写入 VMD 文件。"
            }
        }
    }

    private struct BoneKey {
        var frame: Int
        var rotation: simd_quatf
    }

    private var tracks: [String: [BoneKey]] = [:]
    private var maxFrame = 0

    func extract(from videoURL: URL,
                 progress: @escaping (Double) -> Void,
                 completion: @escaping (Swift.Result<Result, Error>) -> Void) {
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                let result = try self.run(videoURL: videoURL, progress: progress)
                DispatchQueue.main.async { completion(.success(result)) }
            } catch {
                MMDLog.shared.error("Video motion extraction failed: \(error.localizedDescription)")
                DispatchQueue.main.async { completion(.failure(error)) }
            }
        }
    }

    private func run(videoURL: URL, progress: @escaping (Double) -> Void) throws -> Result {
        let asset = AVURLAsset(url: videoURL)
        guard let track = asset.tracks(withMediaType: .video).first else {
            throw ExtractError.noVideoTrack
        }
        let reader = try AVAssetReader(asset: asset)
        let output = AVAssetReaderTrackOutput(track: track, outputSettings: [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA
        ])
        output.alwaysCopiesSampleData = false
        guard reader.canAdd(output) else { throw ExtractError.cannotRead }
        reader.add(output)
        guard reader.startReading() else { throw ExtractError.cannotRead }

        let duration = max(0.1, CMTimeGetSeconds(asset.duration))
        let sampleInterval = 1.0 / 20.0
        var nextSample = 0.0
        var sampled = 0
        var detected = 0
        let request = VNDetectHumanBodyPoseRequest()

        tracks.removeAll()
        maxFrame = 0

        while reader.status == .reading, let sample = output.copyNextSampleBuffer() {
            let time = CMTimeGetSeconds(CMSampleBufferGetPresentationTimeStamp(sample))
            guard time >= nextSample else { continue }
            nextSample += sampleInterval
            guard let pixelBuffer = CMSampleBufferGetImageBuffer(sample) else { continue }

            sampled += 1
            let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up, options: [:])
            do {
                try handler.perform([request])
            } catch {
                continue
            }
            guard let observation = request.results?.first else { continue }
            guard let joints = try? observation.recognizedPoints(.all) else { continue }

            let keyFrame = Int((time * 30.0).rounded())
            maxFrame = max(maxFrame, keyFrame)
            if addPose(joints: joints, frame: keyFrame) {
                detected += 1
            }
            progress(min(0.98, time / duration))
        }

        if reader.status == .failed { throw ExtractError.cannotRead }
        guard detected > 0, !tracks.isEmpty else { throw ExtractError.noPose }

        let outputURL = try outputURL(for: videoURL)
        try writeVMD(to: outputURL)
        progress(1.0)
        MMDLog.shared.info("Video motion generated: \(outputURL.lastPathComponent), samples=\(sampled), detected=\(detected), frames=\(maxFrame)")
        return Result(url: outputURL, sampledFrames: sampled, detectedFrames: detected)
    }

    private func addPose(joints: [VNHumanBodyPoseObservation.JointName: VNRecognizedPoint], frame: Int) -> Bool {
        func point(_ joint: VNHumanBodyPoseObservation.JointName) -> CGPoint? {
            guard let value = joints[joint], value.confidence >= 0.2 else { return nil }
            return value.location
        }
        func angle(_ a: CGPoint, _ b: CGPoint) -> Float {
            Float(atan2(Double(b.y - a.y), Double(b.x - a.x)))
        }
        func delta(_ value: Float) -> Float {
            atan2(sinf(value), cosf(value))
        }
        func qz(_ radians: Float) -> simd_quatf {
            simd_quatf(angle: radians, axis: SIMD3<Float>(0, 0, 1))
        }
        func add(_ name: String, _ rotation: simd_quatf?) {
            guard let rotation else { return }
            tracks[name, default: []].append(BoneKey(frame: frame, rotation: rotation))
        }

        let neck = point(.neck)
        let root = point(.root)
        let nose = point(.nose)
        let leftShoulder = point(.leftShoulder)
        let rightShoulder = point(.rightShoulder)
        let leftElbow = point(.leftElbow)
        let rightElbow = point(.rightElbow)
        let leftWrist = point(.leftWrist)
        let rightWrist = point(.rightWrist)
        let leftHip = point(.leftHip)
        let rightHip = point(.rightHip)
        let leftKnee = point(.leftKnee)
        let rightKnee = point(.rightKnee)
        let leftAnkle = point(.leftAnkle)
        let rightAnkle = point(.rightAnkle)

        var lean: Float = 0
        if let root, let neck { lean = angle(root, neck) - (.pi / 2) }
        add("センター", qz(-lean * 0.65))

        if let neck, let nose {
            let head = angle(neck, nose) - (.pi / 2)
            add("頭", qz(-(head - lean)))
        }

        if let leftShoulder, let leftElbow {
            add("左腕", qz(-(angle(leftShoulder, leftElbow) - lean)))
        }
        if let rightShoulder, let rightElbow {
            add("右腕", qz(-(delta(angle(rightShoulder, rightElbow) - .pi) - lean)))
        }
        if let leftElbow, let leftWrist, let leftShoulder {
            let upperAngle = angle(leftShoulder, leftElbow)
            add("左ひじ", qz(-delta(angle(leftElbow, leftWrist) - upperAngle)))
        }
        if let rightElbow, let rightWrist, let rightShoulder {
            let upperAngle = angle(rightShoulder, rightElbow)
            add("右ひじ", qz(-delta(angle(rightElbow, rightWrist) - upperAngle)))
        }

        if let leftHip, let leftKnee {
            add("左足", qz(-(delta(angle(leftHip, leftKnee) + .pi / 2) - lean)))
        }
        if let rightHip, let rightKnee {
            add("右足", qz(-(delta(angle(rightHip, rightKnee) + .pi / 2) - lean)))
        }
        if let leftKnee, let leftAnkle, let leftHip {
            add("左ひざ", qz(-delta(angle(leftKnee, leftAnkle) - angle(leftHip, leftKnee))))
        }
        if let rightKnee, let rightAnkle, let rightHip {
            add("右ひざ", qz(-delta(angle(rightKnee, rightAnkle) - angle(rightHip, rightKnee))))
        }

        // Upper body follows the spine by half of the visible lean.
        add("上半身", qz(-lean * 0.35))
        return tracks.values.contains { $0.last?.frame == frame }
    }

    private func outputURL(for videoURL: URL) throws -> URL {
        let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSTemporaryDirectory())
        let directory = documents.appendingPathComponent("MMDStudio/GeneratedMotions", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let base = videoURL.deletingPathExtension().lastPathComponent
        let safe = base.replacingOccurrences(of: "/", with: "_")
        var url = directory.appendingPathComponent("\(safe)-video.vmd")
        var index = 2
        while FileManager.default.fileExists(atPath: url.path) {
            url = directory.appendingPathComponent("\(safe)-video-\(index).vmd")
            index += 1
        }
        return url
    }

    private func writeVMD(to url: URL) throws {
        var data = Data()
        appendFixed("Vocaloid Motion Data 0002", bytes: 30, to: &data)
        appendFixed("MMDStudio Video Capture", bytes: 20, to: &data)

        let tracksSorted = tracks.keys.sorted()
        let totalKeys = tracksSorted.reduce(0) { $0 + (tracks[$1]?.count ?? 0) }
        appendUInt32(UInt32(totalKeys), to: &data)
        let linearInterpolation = interpolationBytes()

        for name in tracksSorted {
            guard let keys = tracks[name] else { continue }
            appendFixed(name, bytes: 15, to: &data)
            for key in keys.sorted(by: { $0.frame < $1.frame }) {
                appendUInt32(UInt32(max(0, key.frame)), to: &data)
                appendFloat(0, to: &data)
                appendFloat(0, to: &data)
                appendFloat(0, to: &data)
                // VMD stores left-handed quaternions; the rest of the app
                // mirrors X/Y when reading them back.
                let q = key.rotation
                appendFloat(-q.imag.x, to: &data)
                appendFloat(-q.imag.y, to: &data)
                appendFloat(q.imag.z, to: &data)
                appendFloat(q.real, to: &data)
                data.append(linearInterpolation)
            }
        }

        appendUInt32(0, to: &data) // morph keys
        appendUInt32(0, to: &data) // camera keys
        guard (try? data.write(to: url, options: .atomic)) != nil else { throw ExtractError.writeFailed }
    }

    private func interpolationBytes() -> Data {
        var bytes = [UInt8](repeating: 0, count: 64)
        for channel in 0..<4 {
            bytes[channel] = 20
            bytes[channel + 4] = 20
            bytes[channel + 8] = 107
            bytes[channel + 12] = 107
        }
        return Data(bytes)
    }

    private func appendFixed(_ text: String, bytes count: Int, to data: inout Data) {
        var raw = [UInt8]((try? text.data(using: .shiftJIS)) ?? Data())
        if raw.count > count { raw = Array(raw.prefix(count)) }
        data.append(contentsOf: raw)
        if raw.count < count { data.append(contentsOf: [UInt8](repeating: 0, count: count - raw.count)) }
    }

    private func appendUInt32(_ value: UInt32, to data: inout Data) {
        data.append(UInt8(value & 0xFF))
        data.append(UInt8((value >> 8) & 0xFF))
        data.append(UInt8((value >> 16) & 0xFF))
        data.append(UInt8((value >> 24) & 0xFF))
    }

    private func appendFloat(_ value: Float, to data: inout Data) {
        appendUInt32(value.bitPattern, to: &data)
    }
}
