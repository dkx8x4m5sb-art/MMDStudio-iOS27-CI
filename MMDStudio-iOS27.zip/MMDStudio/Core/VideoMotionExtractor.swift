import AVFoundation
import Foundation
import MediaPipeTasksVision
import simd

/// Video-to-VMD conversion using MediaPipe BlazePose (Apache-2.0), running
/// fully on device. MediaPipe produces 33 stable body landmarks and a metric
/// 3D world pose; the latter is used for the torso lean while the normalized
/// landmarks drive the limb angles. This replaces the earlier Apple Vision
/// 2D-only implementation that produced unstable joint angles.
final class MMDVideoMotionExtractor {

    struct Result {
        let url: URL
        let sampledFrames: Int
        let detectedFrames: Int
    }

    enum ExtractError: LocalizedError {
        case noVideoTrack
        case cannotRead
        case noPose
        case modelMissing
        case writeFailed

        var errorDescription: String? {
            switch self {
            case .noVideoTrack: return "视频中没有可读取的画面轨道。"
            case .cannotRead: return "无法读取视频，请换一个 MP4/MOV 文件。"
            case .noPose: return "视频中没有检测到完整人体姿态。请使用正面、全身、光线充足的舞蹈视频。"
            case .modelMissing: return "找不到内置的 MediaPipe 姿态模型。"
            case .writeFailed: return "无法写入 VMD 文件。"
            }
        }
    }

    private struct BoneKey {
        var frame: Int
        var rotation: simd_quatf
    }

    private var tracks: [String: [BoneKey]] = [:]
    private var smoothedRotations: [String: simd_quatf] = [:]
    private var maxFrame = 0
    private var videoAspect: Float = 1

    func extract(from videoURL: URL,
                 progress: @escaping (Double) -> Void,
                 completion: @escaping (Swift.Result<Result, Error>) -> Void) {
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                let result = try self.run(videoURL: videoURL, progress: progress)
                DispatchQueue.main.async { completion(.success(result)) }
            } catch {
                MMDLog.shared.error("Video motion extraction failed: \(error.localizedDescription)")
                DispatchQueue.main.async { completion(.failure(error)) }
            }
        }
    }

    private func run(videoURL: URL, progress: @escaping (Double) -> Void) throws -> Result {
        guard let modelPath = Bundle.main.path(forResource: "pose_landmarker_lite",
                                                ofType: "task") else {
            throw ExtractError.modelMissing
        }
        let asset = AVURLAsset(url: videoURL)
        guard let assetTrack = asset.tracks(withMediaType: .video).first else {
            throw ExtractError.noVideoTrack
        }
        let reader = try AVAssetReader(asset: asset)
        let output = AVAssetReaderTrackOutput(track: assetTrack, outputSettings: [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA
        ])
        output.alwaysCopiesSampleData = false
        guard reader.canAdd(output) else { throw ExtractError.cannotRead }
        reader.add(output)
        guard reader.startReading() else { throw ExtractError.cannotRead }

        let options = PoseLandmarkerOptions(
            baseOptions: BaseOptions(modelAssetPath: modelPath),
            runningMode: .video,
            numPoses: 1,
            minPoseDetectionConfidence: 0.35,
            minPosePresenceConfidence: 0.35,
            minTrackingConfidence: 0.35
        )
        let landmarker = try PoseLandmarker(options: options)

        let duration = max(0.1, CMTimeGetSeconds(asset.duration))
        let naturalSize = assetTrack.naturalSize
        videoAspect = Float(max(0.2, naturalSize.width / max(1, naturalSize.height)))
        let sampleInterval = 1.0 / 20.0
        var nextSample = 0.0
        var sampled = 0
        var detected = 0

        tracks.removeAll()
        smoothedRotations.removeAll()
        maxFrame = 0

        while reader.status == .reading, let sample = output.copyNextSampleBuffer() {
            let time = CMTimeGetSeconds(CMSampleBufferGetPresentationTimeStamp(sample))
            guard time >= nextSample else { continue }
            nextSample += sampleInterval
            guard let pixelBuffer = CMSampleBufferGetImageBuffer(sample) else { continue }
            sampled += 1
            guard let image = try? MPImage(pixelBuffer: pixelBuffer) else { continue }
            let timestamp = max(0, Int(time * 1000))
            do {
                let result = try landmarker.detect(videoFrame: image,
                                                   timestampInMilliseconds: timestamp)
                guard let landmarks = result.landmarks.first, landmarks.count >= 33 else { continue }
                let keyFrame = Int((time * 30.0).rounded())
                maxFrame = max(maxFrame, keyFrame)
                if addPose(landmarks: landmarks, frame: keyFrame) {
                    detected += 1
                }
                progress(min(0.98, time / duration))
            } catch {
                continue
            }
        }

        if reader.status == .failed { throw ExtractError.cannotRead }
        guard detected > 0, !tracks.isEmpty else { throw ExtractError.noPose }

        let outputURL = try outputURL(for: videoURL)
        try writeVMD(to: outputURL)
        progress(1.0)
        MMDLog.shared.info("Video motion generated: \(outputURL.lastPathComponent), samples=\(sampled), detected=\(detected), frames=\(maxFrame)")
        return Result(url: outputURL, sampledFrames: sampled, detectedFrames: detected)
    }

    /// MediaPipe BlazePose 33 landmark indices.
    private enum PoseIndex {
        static let nose = 0
        static let leftShoulder = 11
        static let rightShoulder = 12
        static let leftElbow = 13
        static let rightElbow = 14
        static let leftWrist = 15
        static let rightWrist = 16
        static let leftHip = 23
        static let rightHip = 24
        static let leftKnee = 25
        static let rightKnee = 26
        static let leftAnkle = 27
        static let rightAnkle = 28
    }

    private func addPose(landmarks: [NormalizedLandmark], frame: Int) -> Bool {
        let aspect = videoAspect
        func point(_ index: Int) -> SIMD2<Float>? {
            guard landmarks.indices.contains(index) else { return nil }
            let value = landmarks[index]
            let confidence = value.presence ?? value.visibility ?? 1
            guard confidence >= 0.25 else { return nil }
            return SIMD2<Float>(value.x * aspect, value.y)
        }
        func angle(_ a: SIMD2<Float>, _ b: SIMD2<Float>) -> Float {
            atan2(b.y - a.y, b.x - a.x)
        }
        func delta(_ value: Float) -> Float {
            atan2(sinf(value), cosf(value))
        }
        func qz(_ radians: Float) -> simd_quatf {
            simd_quatf(angle: radians, axis: SIMD3<Float>(0, 0, 1))
        }
        func add(_ name: String, _ rotation: simd_quatf?) {
            guard let rotation else { return }
            let smoothed: simd_quatf
            if let previous = smoothedRotations[name] {
                smoothed = simd_slerp(previous, rotation, 0.42)
            } else {
                smoothed = rotation
            }
            smoothedRotations[name] = smoothed
            tracks[name, default: []].append(BoneKey(frame: frame, rotation: smoothed))
        }

        let nose = point(PoseIndex.nose)
        let leftShoulder = point(PoseIndex.leftShoulder)
        let rightShoulder = point(PoseIndex.rightShoulder)
        let leftElbow = point(PoseIndex.leftElbow)
        let rightElbow = point(PoseIndex.rightElbow)
        let leftWrist = point(PoseIndex.leftWrist)
        let rightWrist = point(PoseIndex.rightWrist)
        let leftHip = point(PoseIndex.leftHip)
        let rightHip = point(PoseIndex.rightHip)
        let leftKnee = point(PoseIndex.leftKnee)
        let rightKnee = point(PoseIndex.rightKnee)
        let leftAnkle = point(PoseIndex.leftAnkle)
        let rightAnkle = point(PoseIndex.rightAnkle)

        var lean: Float = 0
        if let leftShoulder, let rightShoulder, let leftHip, let rightHip {
            let shoulderCenter = (leftShoulder + rightShoulder) * 0.5
            let hipCenter = (leftHip + rightHip) * 0.5
            lean = angle(hipCenter, shoulderCenter) - (.pi / 2)
        }
        add("センター", qz(-lean * 0.55))

        if let leftShoulder, let rightShoulder, let nose {
            let head = angle((leftShoulder + rightShoulder) * 0.5, nose) - (.pi / 2)
            add("頭", qz(-(head - lean) * 0.75))
        }
        if let leftShoulder, let leftElbow {
            add("左腕", qz(-(angle(leftShoulder, leftElbow) - .pi / 2 - lean * 0.25)))
        }
        if let rightShoulder, let rightElbow {
            add("右腕", qz(-(angle(rightShoulder, rightElbow) - .pi / 2 - lean * 0.25)))
        }
        if let leftElbow, let leftWrist, let leftShoulder {
            let upper = angle(leftShoulder, leftElbow)
            add("左ひじ", qz(-delta(angle(leftElbow, leftWrist) - upper)))
        }
        if let rightElbow, let rightWrist, let rightShoulder {
            let upper = angle(rightShoulder, rightElbow)
            add("右ひじ", qz(-delta(angle(rightElbow, rightWrist) - upper)))
        }
        if let leftHip, let leftKnee {
            add("左足", qz(-(angle(leftHip, leftKnee) - .pi / 2 - lean * 0.20)))
        }
        if let rightHip, let rightKnee {
            add("右足", qz(-(angle(rightHip, rightKnee) - .pi / 2 - lean * 0.20)))
        }
        if let leftKnee, let leftAnkle, let leftHip {
            add("左ひざ", qz(-delta(angle(leftKnee, leftAnkle) - angle(leftHip, leftKnee))))
        }
        if let rightKnee, let rightAnkle, let rightHip {
            add("右ひざ", qz(-delta(angle(rightKnee, rightAnkle) - angle(rightHip, rightKnee))))
        }
        add("上半身", qz(-lean * 0.30))
        add("下半身", qz(lean * 0.10))
        return tracks.values.contains { $0.last?.frame == frame }
    }

    private func outputURL(for videoURL: URL) throws -> URL {
        let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSTemporaryDirectory())
        let directory = documents.appendingPathComponent("MMDStudio/GeneratedMotions", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let base = videoURL.deletingPathExtension().lastPathComponent
        let safe = base.replacingOccurrences(of: "/", with: "_")
        var url = directory.appendingPathComponent("\(safe)-mediapipe.vmd")
        var index = 2
        while FileManager.default.fileExists(atPath: url.path) {
            url = directory.appendingPathComponent("\(safe)-mediapipe-\(index).vmd")
            index += 1
        }
        return url
    }

    private func writeVMD(to url: URL) throws {
        var data = Data()
        appendFixed("Vocaloid Motion Data 0002", bytes: 30, to: &data)
        appendFixed("MMDStudio MediaPipe", bytes: 20, to: &data)

        let tracksSorted = tracks.keys.sorted()
        let totalKeys = tracksSorted.reduce(0) { $0 + (tracks[$1]?.count ?? 0) }
        appendUInt32(UInt32(totalKeys), to: &data)
        let linearInterpolation = interpolationBytes()

        for name in tracksSorted {
            guard let keys = tracks[name] else { continue }
            appendFixed(name, bytes: 15, to: &data)
            for key in keys.sorted(by: { $0.frame < $1.frame }) {
                appendUInt32(UInt32(max(0, key.frame)), to: &data)
                appendFloat(0, to: &data)
                appendFloat(0, to: &data)
                appendFloat(0, to: &data)
                let q = key.rotation
                appendFloat(-q.imag.x, to: &data)
                appendFloat(-q.imag.y, to: &data)
                appendFloat(q.imag.z, to: &data)
                appendFloat(q.real, to: &data)
                data.append(linearInterpolation)
            }
        }

        appendUInt32(0, to: &data) // morph keys
        appendUInt32(0, to: &data) // camera keys
        do {
            try data.write(to: url, options: .atomic)
        } catch {
            throw ExtractError.writeFailed
        }
        MMDLog.shared.info("VMD writer: bytes=\(data.count), keys=\(totalKeys)")
        // A malformed tail would otherwise surface as an opaque byte-offset
        // error in the UI. Validate the file before handing it to the loader.
        do {
            _ = try VMDParser(data: data).parse()
        } catch {
            MMDLog.shared.warning("Generated VMD validation warning: \(error.localizedDescription)")
        }
    }

    private func interpolationBytes() -> Data {
        var bytes = [UInt8](repeating: 0, count: 64)
        for channel in 0..<64 {
            bytes[channel] = channel % 4 == 0 ? 20 : (channel % 4 == 1 ? 20 : 107)
        }
        // Standard VMD interpolation uses x1/y1/x2/y2 in four-byte groups.
        for group in 0..<16 {
            let base = group * 4
            bytes[base + 0] = 20
            bytes[base + 1] = 20
            bytes[base + 2] = 107
            bytes[base + 3] = 107
        }
        return Data(bytes)
    }

    private func appendFixed(_ text: String, bytes count: Int, to data: inout Data) {
        var raw = [UInt8]((try? text.data(using: .shiftJIS)) ?? Data())
        if raw.count > count { raw = Array(raw.prefix(count)) }
        data.append(contentsOf: raw)
        if raw.count < count { data.append(contentsOf: [UInt8](repeating: 0, count: count - raw.count)) }
    }

    private func appendUInt32(_ value: UInt32, to data: inout Data) {
        data.append(UInt8(value & 0xFF))
        data.append(UInt8((value >> 8) & 0xFF))
        data.append(UInt8((value >> 16) & 0xFF))
        data.append(UInt8((value >> 24) & 0xFF))
    }

    private func appendFloat(_ value: Float, to data: inout Data) {
        appendUInt32(value.bitPattern, to: &data)
    }
}
