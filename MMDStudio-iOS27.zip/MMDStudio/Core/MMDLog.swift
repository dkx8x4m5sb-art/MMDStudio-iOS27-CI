import Foundation
import os.log

/// Lightweight, persistent in-app logger. Importing a model can fail for very
/// different reasons on device, so the app keeps a rotating text log that the
/// user can inspect or share directly from the UI.
final class MMDLog {

    static let shared = MMDLog()

    private let queue = DispatchQueue(label: "com.mmdstudio.log")
    private let fileManager = FileManager.default
    private let directoryURL: URL
    private let currentURL: URL
    private let previousURL: URL
    private let osLogger = Logger(subsystem: "com.mmdstudio.app", category: "MMDStudio")
    private let maxBytes: Int = 2 * 1024 * 1024
    private let formatter: DateFormatter

    private init() {
        let documents = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSTemporaryDirectory())
        directoryURL = documents.appendingPathComponent("MMDStudio/Logs", isDirectory: true)
        currentURL = directoryURL.appendingPathComponent("MMDStudio.log")
        previousURL = directoryURL.appendingPathComponent("MMDStudio.previous.log")
        try? fileManager.createDirectory(at: directoryURL, withIntermediateDirectories: true)
        formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss.SSS"
    }

    func info(_ message: String, file: String = #fileID, line: Int = #line) {
        write("INFO", message, file: file, line: line)
    }

    func warning(_ message: String, file: String = #fileID, line: Int = #line) {
        write("WARN", message, file: file, line: line)
    }

    func error(_ message: String, file: String = #fileID, line: Int = #line) {
        write("ERROR", message, file: file, line: line)
    }

    private func write(_ level: String, _ message: String, file: String, line: Int) {
        let source = URL(fileURLWithPath: file).lastPathComponent
        let stamp = formatter.string(from: Date())
        let lineText = "[\(stamp)] [\(level)] [\(source):\(line)] \(message)\n"
        osLogger.info("\(lineText, privacy: .public)")
        queue.async { [weak self] in
            guard let self else { return }
            self.rotateIfNeeded()
            guard let data = lineText.data(using: .utf8) else { return }
            if let handle = try? FileHandle(forWritingTo: self.currentURL) {
                defer { try? handle.close() }
                _ = try? handle.seekToEnd()
                try? handle.write(contentsOf: data)
            } else {
                try? data.write(to: self.currentURL, options: .atomic)
            }
        }
    }

    private func rotateIfNeeded() {
        guard let attributes = try? fileManager.attributesOfItem(atPath: currentURL.path),
              let size = attributes[.size] as? NSNumber,
              size.intValue > maxBytes else { return }
        try? fileManager.removeItem(at: previousURL)
        try? fileManager.moveItem(at: currentURL, to: previousURL)
    }

    func readRecent(limit: Int = 240_000) -> String {
        queue.sync {
            var text = ""
            if let data = try? Data(contentsOf: previousURL), !data.isEmpty {
                text += "[previous log]\n" + (String(data: data, encoding: .utf8) ?? "") + "\n"
            }
            if let data = try? Data(contentsOf: currentURL), !data.isEmpty {
                let tail = data.count > limit ? data.suffix(limit) : data
                text += String(data: Data(tail), encoding: .utf8) ?? ""
            }
            return text.isEmpty ? "还没有日志。" : text
        }
    }

    func exportURL() -> URL? {
        queue.sync {
            guard fileManager.fileExists(atPath: currentURL.path) else { return nil }
            let export = fileManager.temporaryDirectory.appendingPathComponent("MMDStudio-Log.txt")
            try? fileManager.removeItem(at: export)
            try? fileManager.copyItem(at: currentURL, to: export)
            return export
        }
    }

    func clear() {
        queue.async { [weak self] in
            guard let self else { return }
            try? self.fileManager.removeItem(at: self.currentURL)
            try? self.fileManager.removeItem(at: self.previousURL)
        }
    }
}
