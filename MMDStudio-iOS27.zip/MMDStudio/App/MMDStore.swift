import Foundation
import SwiftUI
import UniformTypeIdentifiers

struct MMDModelEntry: Identifiable, Hashable {
    /// Stable identity: the PMX path relative to the model library.
    let id: String
    let displayName: String
    let pmxPath: String
    /// Top-level imported folder. Several PMX models may share this folder.
    let packageURL: URL
    /// Directory containing the PMX; texture relative paths start here.
    let assetDirectory: URL
    let relativePath: String

    var folderName: String { packageURL.lastPathComponent }
    var isSample: Bool { relativePath.hasPrefix("SampleModel/") }
}

struct MMDImportResult {
    let entries: [MMDModelEntry]
    let warnings: [String]
}

final class MMDStore: ObservableObject {

    @Published var entries: [MMDModelEntry] = []
    @Published var errorMessage: String?

    let libraryURL: URL

    init() {
        let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSTemporaryDirectory())
        libraryURL = documents.appendingPathComponent("MMDModels", isDirectory: true)
        try? FileManager.default.createDirectory(at: libraryURL, withIntermediateDirectories: true)
        MMDLog.shared.info("MMDStore init, library=\(libraryURL.path)")
        installSampleIfNeeded()
        refresh()
    }

    // MARK: - Library

    func refresh() {
        let fileManager = FileManager.default
        guard let enumerator = fileManager.enumerator(at: libraryURL,
                                                      includingPropertiesForKeys: [.isRegularFileKey],
                                                      options: [.skipsHiddenFiles]) else {
            entries = []
            return
        }
        var result: [MMDModelEntry] = []
        let rootPath = libraryURL.standardizedFileURL.path
        for case let url as URL in enumerator {
            guard url.pathExtension.lowercased() == "pmx" else { continue }
            guard (try? url.resourceValues(forKeys: [.isRegularFileKey]).isRegularFile) == true else { continue }
            let path = url.standardizedFileURL.path
            guard path.hasPrefix(rootPath + "/") else { continue }
            let relative = String(path.dropFirst(rootPath.count + 1))
            var components = relative.split(separator: "/").map(String.init)
            guard let fileName = components.popLast(), !fileName.isEmpty else { continue }
            let packageName = components.first ?? url.deletingLastPathComponent().lastPathComponent
            let packageURL = libraryURL.appendingPathComponent(packageName, isDirectory: true)
            let display = Self.friendlyDisplayName(pmx: url, packageName: packageName)
            result.append(MMDModelEntry(id: relative,
                                        displayName: display,
                                        pmxPath: url.path,
                                        packageURL: packageURL,
                                        assetDirectory: url.deletingLastPathComponent(),
                                        relativePath: relative))
        }
        result.sort { lhs, rhs in
            if lhs.isSample { return true }
            if rhs.isSample { return false }
            return lhs.displayName.localizedStandardCompare(rhs.displayName) == .orderedAscending
        }
        entries = result
        MMDLog.shared.info("Library refreshed: \(result.count) model(s)")
    }

    func open(_ entry: MMDModelEntry) throws -> MMDModelDocument {
        MMDLog.shared.info("Open model: \(entry.relativePath), assetDir=\(entry.assetDirectory.path)")
        let pmxURL = URL(fileURLWithPath: entry.pmxPath)
        let data = try Data(contentsOf: pmxURL)
        let model = try PMXParser(data: data).parse()
        MMDLog.shared.info("PMX parsed: vertices=\(model.vertices.count), materials=\(model.materials.count), bones=\(model.bones.count), morphs=\(model.morphs.count), textures=\(model.textures.count)")
        // Textures normally live beside the PMX, but multi-model packages often
        // keep a shared texture folder at the archive root. Both roots are
        // searched, with the PMX directory taking priority.
        let document = MMDModelDocument(model: model,
                                        baseDirectory: entry.assetDirectory,
                                        fallbackRoot: entry.packageURL == entry.assetDirectory ? nil : entry.packageURL,
                                        displayName: model.displayName)
        if let vmd = findFile(withExtension: "vmd", in: entry.assetDirectory)
            ?? findFile(withExtension: "vmd", in: entry.packageURL) {
            do {
                try document.loadMotion(url: vmd)
                MMDLog.shared.info("Auto-loaded motion: \(vmd.lastPathComponent), \(document.motionMappingNote)")
            } catch {
                MMDLog.shared.warning("Auto motion load failed: \(error.localizedDescription)")
            }
        }
        return document
    }

    func delete(_ entry: MMDModelEntry) {
        do {
            let siblings = entries.filter { $0.packageURL == entry.packageURL }
            if siblings.count <= 1 {
                try FileManager.default.removeItem(at: entry.packageURL)
                MMDLog.shared.info("Deleted model package: \(entry.packageURL.lastPathComponent)")
            } else {
                // Multiple models share this package. Remove only this PMX so
                // other models and their textures stay usable.
                try FileManager.default.removeItem(at: URL(fileURLWithPath: entry.pmxPath))
                MMDLog.shared.info("Deleted one PMX from shared package: \(entry.relativePath)")
            }
            refresh()
        } catch {
            MMDLog.shared.error("Delete failed: \(error.localizedDescription)")
            errorMessage = error.localizedDescription
        }
    }

    // MARK: - Import

    /// Import one folder, PMX file, or ZIP archive. All PMX files found inside
    /// the imported folder are registered, not just the first one.
    func importModel(from source: URL) throws -> MMDModelEntry {
        let result = try importModels(from: [source])
        guard let first = result.entries.first else {
            throw MMDLoadError.invalidData("没有找到可导入的模型")
        }
        return first
    }

    func importModels(from sources: [URL]) throws -> MMDImportResult {
        var entries = [MMDModelEntry]()
        var warnings = [String]()
        for source in sources {
            let accessed = source.startAccessingSecurityScopedResource()
            defer { if accessed { source.stopAccessingSecurityScopedResource() } }
            MMDLog.shared.info("Import source: \(source.lastPathComponent), securityScope=\(accessed)")

            let fileManager = FileManager.default
            let isDirectory = (try? source.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
            let extensionName = source.pathExtension.lowercased()
            let stem = source.deletingPathExtension().lastPathComponent
            let baseName = stem.isEmpty ? "导入模型" : stem
            let destination = uniqueFolder(named: baseName)
            try fileManager.createDirectory(at: destination, withIntermediateDirectories: true)

            do {
                if isDirectory {
                    let contents = try fileManager.contentsOfDirectory(at: source,
                                                                       includingPropertiesForKeys: nil,
                                                                       options: [.skipsHiddenFiles])
                    for item in contents {
                        let target = destination.appendingPathComponent(item.lastPathComponent)
                        if !fileManager.fileExists(atPath: target.path) {
                            try fileManager.copyItem(at: item, to: target)
                        }
                    }
                    MMDLog.shared.info("Copied folder: \(contents.count) top-level item(s)")
                } else if extensionName == "zip" {
                    let extracted = try MMDZipArchive.extract(url: source, to: destination)
                    MMDLog.shared.info("ZIP extracted: \(extracted) file(s) -> \(destination.path)")
                } else if extensionName == "pmx" {
                    try fileManager.copyItem(at: source,
                                             to: destination.appendingPathComponent(source.lastPathComponent))
                    if !copySiblingResources(from: source.deletingLastPathComponent(), to: destination) {
                        warnings.append("单个 PMX 可能缺少同目录贴图；如贴图缺失，请改选模型文件夹或 ZIP。")
                    }
                } else {
                    throw MMDLoadError.unsupported("不支持的文件类型 .\(extensionName)")
                }
            } catch {
                MMDLog.shared.error("Import copy/extract failed: \(error.localizedDescription)")
                try? fileManager.removeItem(at: destination)
                throw error
            }

            let pmxFiles = findAllPMX(in: destination)
            guard !pmxFiles.isEmpty else {
                try? fileManager.removeItem(at: destination)
                throw MMDLoadError.invalidData("导入内容中没有找到 .pmx 模型文件")
            }
            MMDLog.shared.info("Found \(pmxFiles.count) PMX model(s) in \(destination.lastPathComponent)")
            if pmxFiles.count > 1 {
                warnings.append("\(source.lastPathComponent) 中发现 \(pmxFiles.count) 个模型，已全部加入模型库。")
            }

            for pmx in pmxFiles {
                let path = pmx.standardizedFileURL.path
                let rootPath = libraryURL.standardizedFileURL.path
                let relative = path.hasPrefix(rootPath + "/") ? String(path.dropFirst(rootPath.count + 1)) : pmx.lastPathComponent
                let display = Self.friendlyDisplayName(pmx: pmx, packageName: destination.lastPathComponent)
                entries.append(MMDModelEntry(id: relative,
                                             displayName: display,
                                             pmxPath: pmx.path,
                                             packageURL: destination,
                                             assetDirectory: pmx.deletingLastPathComponent(),
                                             relativePath: relative))
            }
        }
        refresh()
        return MMDImportResult(entries: entries, warnings: warnings)
    }

    /// Copy images and nested texture folders next to a single PMX. Returns
    /// false when the source directory cannot be read at all.
    @discardableResult
    private func copySiblingResources(from parent: URL, to destination: URL) -> Bool {
        let fileManager = FileManager.default
        guard let contents = try? fileManager.contentsOfDirectory(at: parent,
                                                                  includingPropertiesForKeys: [.isDirectoryKey],
                                                                  options: [.skipsHiddenFiles]) else {
            return false
        }
        let imageExtensions: Set<String> = ["png", "jpg", "jpeg", "bmp", "tga", "gif", "webp", "dds"]
        for item in contents {
            let isDirectory = (try? item.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
            let target = destination.appendingPathComponent(item.lastPathComponent)
            if fileManager.fileExists(atPath: target.path) { continue }
            if isDirectory {
                try? fileManager.copyItem(at: item, to: target)
            } else if imageExtensions.contains(item.pathExtension.lowercased()) {
                try? fileManager.copyItem(at: item, to: target)
            }
        }
        return true
    }

    private func uniqueFolder(named rawName: String) -> URL {
        let sanitized = rawName.replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "\\", with: "_")
            .replacingOccurrences(of: ":", with: "_")
            .replacingOccurrences(of: "..", with: "_")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let name = sanitized.isEmpty ? "导入模型" : sanitized
        var candidate = libraryURL.appendingPathComponent(name, isDirectory: true)
        var index = 2
        while FileManager.default.fileExists(atPath: candidate.path) {
            candidate = libraryURL.appendingPathComponent("\(name) \(index)", isDirectory: true)
            index += 1
        }
        return candidate
    }

    // MARK: - Sample

    private func installSampleIfNeeded() {
        let fileManager = FileManager.default
        let destination = libraryURL.appendingPathComponent("SampleModel", isDirectory: true)
        if fileManager.fileExists(atPath: destination.path) { return }
        guard let source = Bundle.main.url(forResource: "SampleModel", withExtension: nil) else { return }
        do {
            try fileManager.createDirectory(at: destination, withIntermediateDirectories: true)
            let contents = try fileManager.contentsOfDirectory(at: source,
                                                               includingPropertiesForKeys: nil,
                                                               options: [.skipsHiddenFiles])
            for item in contents {
                try? fileManager.copyItem(at: item, to: destination.appendingPathComponent(item.lastPathComponent))
            }
            MMDLog.shared.info("Sample model installed")
        } catch {
            MMDLog.shared.error("Sample install failed: \(error.localizedDescription)")
            errorMessage = "示例模型安装失败：\(error.localizedDescription)"
        }
    }

    // MARK: - Helpers

    private func findAllPMX(in folder: URL) -> [URL] {
        let fileManager = FileManager.default
        guard let enumerator = fileManager.enumerator(at: folder,
                                                      includingPropertiesForKeys: [.isRegularFileKey],
                                                      options: [.skipsHiddenFiles]) else { return [] }
        var files = [URL]()
        for case let url as URL in enumerator {
            guard url.pathExtension.lowercased() == "pmx" else { continue }
            if (try? url.resourceValues(forKeys: [.isRegularFileKey]).isRegularFile) == true {
                files.append(url)
            }
        }
        return files.sorted { $0.path.localizedStandardCompare($1.path) == .orderedAscending }
    }

    private func findPMX(in folder: URL) -> URL? {
        findAllPMX(in: folder).first
    }

    private func findFile(withExtension ext: String, in folder: URL) -> URL? {
        guard let enumerator = FileManager.default.enumerator(at: folder,
                                                              includingPropertiesForKeys: [.isRegularFileKey],
                                                              options: [.skipsHiddenFiles]) else { return nil }
        for case let url as URL in enumerator {
            if url.pathExtension.lowercased() == ext { return url }
        }
        return nil
    }

    private static func friendlyDisplayName(pmx: URL, packageName: String) -> String {
        if pmx.path.contains("/SampleModel/") { return "示例模型 · 舞" }
        let stem = pmx.deletingPathExtension().lastPathComponent
        let generic: Set<String> = ["model", "mesh", "body", "character", "mmd", "main", "untitled", "pmx", "default"]
        if generic.contains(stem.lowercased()) || stem.isEmpty {
            return packageName
        }
        return stem.replacingOccurrences(of: "_", with: " ")
    }
}
