import Foundation
import SwiftUI
import Combine
import QuartzCore

final class MMDModelDocument: ObservableObject, Identifiable {

    let id = UUID()
    let displayName: String

    @Published var model: PMXModel
    @Published var modelRevision: Int = 1
    @Published var baseDirectory: URL
    /// Optional package root used as a secondary texture search root.
    @Published var fallbackRoot: URL?
    @Published var materialSettings: [MMDMaterialSettings]
    @Published var morphWeights: [Float]
    @Published var boneRotations: [Int: SIMD3<Float>] = [:]
    @Published var selectedBoneIndex: Int = -1
    @Published var selectedMaterialIndex: Int = 0

    @Published var motion: VMDMotion?
    @Published var motionName: String = ""
    @Published var useCameraMotion: Bool = false
    @Published var currentFrame: Float = 0
    @Published var isPlaying: Bool = false
    @Published var loopPlayback: Bool = true
    @Published var playbackSpeed: Float = 1.0
    @Published var renderSettings = MMDRenderSettings()
    @Published var renderStats = MMDRenderStats()
    @Published var motionMappingNote: String = ""
    @Published var missingTextureNames: [String] = []
    @Published var errorMessage: String?

    private(set) var motionBoneTracks: [Int: VMDBoneTrack] = [:]
    private(set) var motionMorphTracks: [Int: VMDMorphTrack] = [:]

    private var timer: Timer?
    private var lastTick: CFTimeInterval = 0

    init(model: PMXModel, baseDirectory: URL, fallbackRoot: URL? = nil, displayName: String) {
        self.model = model
        self.baseDirectory = baseDirectory
        self.fallbackRoot = fallbackRoot
        self.displayName = displayName.isEmpty ? model.displayName : displayName
        self.materialSettings = model.materials.enumerated().map { index, material in
            MMDMaterialSettings(material: material, index: index)
        }
        self.morphWeights = [Float](repeating: 0, count: model.morphs.count)
        self.selectedMaterialIndex = model.materials.isEmpty ? -1 : 0
        self.selectedBoneIndex = model.bones.isEmpty ? -1 : 0
    }

    deinit {
        timer?.invalidate()
    }

    var duration: Float {
        guard let motion else { return 0 }
        return max(0.1, Float(motion.duration))
    }

    var hasMotion: Bool { motion != nil && !(motion?.isEmpty ?? true) }

    var timeText: String {
        Self.formatTime(currentFrame / 30)
    }

    var durationText: String {
        Self.formatTime(duration)
    }

    static func formatTime(_ seconds: Float) -> String {
        let value = max(0, seconds)
        let minutes = Int(value) / 60
        let secs = Int(value) % 60
        let frames = Int((value - Float(Int(value))) * 30)
        return String(format: "%02d:%02d.%02d", minutes, secs, frames)
    }

    // MARK: - Motion

    func loadMotion(url: URL) throws {
        let data = try Data(contentsOf: url)
        let motion = try VMDParser(data: data).parse()
        guard !motion.isEmpty else {
            throw MMDLoadError.invalidData("VMD 文件不包含骨骼、变形或相机关键帧")
        }
        pause()
        self.motion = motion
        MMDLog.shared.info("VMD loaded: \(url.lastPathComponent), bones=\(motion.boneTracks.count), morphs=\(motion.morphTracks.count), camera=\(motion.cameraKeys.count), frames=\(motion.maxFrame)")
        self.motionName = motion.name.isEmpty ? url.deletingPathExtension().lastPathComponent : motion.name
        self.currentFrame = 0
        // VMD camera motion is opt-in. Auto-enabling it makes a user's first
        // camera swipe appear to do nothing, because the VMD camera wins.
        self.useCameraMotion = false
        self.boneRotations.removeAll()
        buildMotionMaps(motion)
    }

    func removeMotion() {
        pause()
        motion = nil
        motionName = ""
        motionMappingNote = ""
        motionBoneTracks = [:]
        motionMorphTracks = [:]
        currentFrame = 0
        useCameraMotion = false
    }

    private func buildMotionMaps(_ motion: VMDMotion) {
        var boneByName: [String: Int] = [:]
        var boneByNormalized: [String: Int] = [:]
        for (index, bone) in model.bones.enumerated() {
            if boneByName[bone.name] == nil { boneByName[bone.name] = index }
            if !bone.nameEn.isEmpty, boneByName[bone.nameEn] == nil { boneByName[bone.nameEn] = index }
            let key = Self.normalizedBoneName(bone.name)
            if !key.isEmpty, boneByNormalized[key] == nil { boneByNormalized[key] = index }
        }
        var boneTracks: [Int: VMDBoneTrack] = [:]
        var unmatched: [String] = []
        for track in motion.boneTracks {
            if let index = boneByName[track.name] ?? boneByNormalized[Self.normalizedBoneName(track.name)] {
                boneTracks[index] = track
                continue
            }
            // ZZZ / custom rigs often rename the standard MMD bones to
            // English or game-specific names. Retarget the generated tracks
            // through a conservative alias table before giving up.
            if let aliasIndex = Self.aliasBoneIndex(for: track.name, model: model,
                                                   normalized: boneByNormalized) {
                boneTracks[aliasIndex] = track
                continue
            }
            // VMD stores only 15 Shift-JIS bytes per name. A long PMX bone
            // name can therefore arrive truncated. Use a conservative prefix
            // match only when the stored name is long enough to be unique.
            let trimmed = track.name.trimmingCharacters(in: .whitespacesAndNewlines)
            if trimmed.count >= 4,
               let index = model.bones.firstIndex(where: {
                   $0.name.hasPrefix(trimmed) || (Self.normalizedBoneName($0.name).hasPrefix(Self.normalizedBoneName(trimmed)))
               }) {
                boneTracks[index] = track
            } else {
                unmatched.append(track.name)
            }
        }
        motionBoneTracks = boneTracks

        var morphByName: [String: Int] = [:]
        for (index, morph) in model.morphs.enumerated() {
            if morphByName[morph.name] == nil { morphByName[morph.name] = index }
            if !morph.nameEn.isEmpty, morphByName[morph.nameEn] == nil { morphByName[morph.nameEn] = index }
        }
        var morphTracks: [Int: VMDMorphTrack] = [:]
        for track in motion.morphTracks {
            if let index = morphByName[track.name] {
                morphTracks[index] = track
            }
        }
        motionMorphTracks = morphTracks

        let mapped = boneTracks.count
        let total = motion.boneTracks.count
        if unmatched.isEmpty {
            motionMappingNote = "动作已映射 \(mapped)/\(total) 根骨骼"
        } else {
            let sample = unmatched.prefix(3).joined(separator: "、")
            motionMappingNote = "动作映射 \(mapped)/\(total) 根骨骼；未匹配：\(sample)"
        }
        if mapped == 0 && !motion.boneTracks.isEmpty {
            motionMappingNote = "动作骨骼名称与模型不匹配，请确认 VMD 与 PMX 是否来自同一角色"
        }
        MMDLog.shared.info("Motion mapping: \(mapped)/\(total) bones, morphs=\(morphTracks.count)/\(motion.morphTracks.count)")
        if !unmatched.isEmpty {
            MMDLog.shared.warning("Unmatched VMD bones: \(unmatched.joined(separator: ", "))")
        }
    }

    private static let boneAliasGroups: [[String]] = [
        ["センター", "center", "centre", "pelvis", "hips", "hip", "root", "下半身"],
        ["上半身", "spine", "chest", "upperbody", "upper_body", "torso"],
        ["上半身2", "upperchest", "upper_chest", "chest2"],
        ["頭", "head", "neck"],
        ["左腕", "leftupperarm", "left_upper_arm", "upperarm_l", "arm_l", "l_arm", "leftarm"],
        ["右腕", "rightupperarm", "right_upper_arm", "upperarm_r", "arm_r", "r_arm", "rightarm"],
        ["左ひじ", "leftforearm", "left_forearm", "forearm_l", "elbow_l", "l_elbow"],
        ["右ひじ", "rightforearm", "right_forearm", "forearm_r", "elbow_r", "r_elbow"],
        ["左手首", "lefthand", "left_hand", "hand_l", "wrist_l"],
        ["右手首", "righthand", "right_hand", "hand_r", "wrist_r"],
        ["左足", "leftthigh", "left_thigh", "thigh_l", "leg_l", "upperleg_l"],
        ["右足", "rightthigh", "right_thigh", "thigh_r", "leg_r", "upperleg_r"],
        ["左ひざ", "leftshin", "left_shin", "shin_l", "knee_l", "calf_l"],
        ["右ひざ", "rightshin", "right_shin", "shin_r", "knee_r", "calf_r"],
        ["左足首", "leftfoot", "left_foot", "foot_l", "ankle_l"],
        ["右足首", "rightfoot", "right_foot", "foot_r", "ankle_r"],
    ]

    private static func aliasBoneIndex(for trackName: String,
                                       model: PMXModel,
                                       normalized: [String: Int]) -> Int? {
        let key = normalizedBoneName(trackName)
        guard !key.isEmpty else { return nil }
        for group in boneAliasGroups {
            let aliases = group.map(normalizedBoneName)
            guard aliases.contains(key) else { continue }
            for alias in aliases {
                if let index = normalized[alias] { return index }
            }
            // Some rigs prefix every bone (e.g. "mixamorig:LeftArm").
            for (name, index) in normalized {
                if aliases.contains(where: { name.hasSuffix($0) || name.hasPrefix($0) }) {
                    return index
                }
            }
        }
        return nil
    }

    private static func normalizedBoneName(_ name: String) -> String {
        name.replacingOccurrences(of: " ", with: "")
            .replacingOccurrences(of: "_", with: "")
            .replacingOccurrences(of: "・", with: "")
            .replacingOccurrences(of: "･", with: "")
            .lowercased()
    }

    // MARK: - Playback

    func togglePlayback() {
        if isPlaying { pause() } else { play() }
    }

    func play() {
        guard hasMotion else { return }
        if currentFrame >= duration - 0.05 { currentFrame = 0 }
        isPlaying = true
        lastTick = CACurrentMediaTime()
        timer?.invalidate()
        let newTimer = Timer(timeInterval: 1.0 / 30.0, repeats: true) { [weak self] _ in
            self?.tick()
        }
        newTimer.tolerance = 0.003
        timer = newTimer
        RunLoop.main.add(newTimer, forMode: .common)
    }

    func pause() {
        isPlaying = false
        timer?.invalidate()
        timer = nil
    }

    private func tick() {
        guard isPlaying, hasMotion else { return }
        let now = CACurrentMediaTime()
        let delta = Float(max(0, now - lastTick))
        lastTick = now
        currentFrame += delta * 30 * max(0.1, playbackSpeed)
        if currentFrame >= duration {
            if loopPlayback {
                currentFrame = currentFrame.truncatingRemainder(dividingBy: max(duration, 0.1))
            } else {
                currentFrame = duration
                pause()
            }
        }
    }

    func seek(to frame: Float) {
        currentFrame = max(0, min(duration, frame))
    }

    // MARK: - Animation sampling

    func effectiveBoneAnimations(frame: Float) -> [Int: MMDBoneAnimation] {
        var result: [Int: MMDBoneAnimation] = [:]
        for (boneIndex, track) in motionBoneTracks {
            if let sample = VMDMotion.evaluateBone(track: track, frame: frame) {
                result[boneIndex] = MMDBoneAnimation(position: sample.position, rotation: sample.rotation)
            }
        }
        for (boneIndex, degrees) in boneRotations {
            guard boneIndex >= 0 && boneIndex < model.bones.count else { continue }
            var animation = result[boneIndex] ?? MMDBoneAnimation()
            animation.rotation = quatFromEuler(SIMD3<Float>(mmdRadians(degrees.x), mmdRadians(degrees.y), mmdRadians(degrees.z)))
            result[boneIndex] = animation
        }
        return result
    }

    func effectiveMorphWeights() -> [Float] {
        var weights = morphWeights.count == model.morphs.count
            ? morphWeights
            : [Float](repeating: 0, count: model.morphs.count)
        if let motion {
            for (morphIndex, track) in motionMorphTracks {
                guard morphIndex >= 0 && morphIndex < weights.count else { continue }
                weights[morphIndex] += VMDMotion.evaluateMorph(track: track, frame: currentFrame)
            }
        }
        for index in weights.indices {
            weights[index] = max(-2, min(2, weights[index]))
        }
        return weights
    }

    // MARK: - Editing

    func setBoneRotation(index: Int, degrees: SIMD3<Float>) {
        guard index >= 0 && index < model.bones.count else { return }
        if abs(degrees.x) < 0.0001 && abs(degrees.y) < 0.0001 && abs(degrees.z) < 0.0001 {
            boneRotations[index] = nil
        } else {
            boneRotations[index] = degrees
        }
    }

    func resetBone(_ index: Int) {
        boneRotations[index] = nil
    }

    func resetAllBones() {
        boneRotations.removeAll()
    }

    func resetMorphs() {
        morphWeights = [Float](repeating: 0, count: model.morphs.count)
    }

    func resetMaterialSettings() {
        materialSettings = model.materials.enumerated().map { index, material in
            MMDMaterialSettings(material: material, index: index)
        }
    }

    func reloadModel() {
        modelRevision += 1
        if materialSettings.count != model.materials.count {
            materialSettings = model.materials.enumerated().map { index, material in
                MMDMaterialSettings(material: material, index: index)
            }
        }
        if morphWeights.count != model.morphs.count {
            morphWeights = [Float](repeating: 0, count: model.morphs.count)
        }
    }


    var availableBoneNames: [String] {
        model.bones.map { $0.name }
    }

    var materialNames: [String] {
        model.materials.map { $0.name }
    }
}
