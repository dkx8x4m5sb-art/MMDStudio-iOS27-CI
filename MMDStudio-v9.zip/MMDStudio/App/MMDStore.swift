import Foundation
import SwiftUI
import UniformTypeIdentifiers

enum MMDModelRole: String, Codable {
    case character = "角色"
    case accessory = "配饰"
}

struct MMDModelGroup: Identifiable, Codable, Hashable {
    var id = UUID()
    var name: String
}

private struct MMDLibraryMetadata: Codable {
    var groups: [MMDModelGroup] = []
    /// Key: top-level imported package folder. Logical grouping leaves the
    /// archive's internal texture paths untouched.
    var packageGroups: [String: UUID] = [:]
}

struct MMDModelEntry: Identifiable, Hashable {
    /// Stable identity: the PMX path relative to the model library.
    let id: String
    let displayName: String
    let pmxPath: String
    /// Top-level imported folder. Several PMX models may share this folder.
    let packageURL: URL
    /// Directory containing the PMX; texture relative paths start here.
    let assetDirectory: URL
    let relativePath: String
    var role: MMDModelRole = .character
    var groupID: UUID?

    var folderName: String { packageURL.lastPathComponent }
}

struct MMDImportResult {
    let entries: [MMDModelEntry]
    let warnings: [String]
}

final class MMDStore: ObservableObject {

    @Published var entries: [MMDModelEntry] = []
    @Published var groups: [MMDModelGroup] = []
    @Published var errorMessage: String?

    let libraryURL: URL
    private var packageGroups: [String: UUID] = [:]
    private var metadataURL: URL { libraryURL.appendingPathComponent(".mmd-library.json") }

    init() {
        let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSTemporaryDirectory())
        libraryURL = documents.appendingPathComponent("MMDModels", isDirectory: true)
        try? FileManager.default.createDirectory(at: libraryURL, withIntermediateDirectories: true)
        MMDLog.shared.info("MMDStore init, library=\(libraryURL.path)")
        removeLegacySampleIfNeeded()
        loadMetadata()
        refresh()
    }

    private func loadMetadata() {
        guard let data = try? Data(contentsOf: metadataURL),
              let metadata = try? JSONDecoder().decode(MMDLibraryMetadata.self, from: data) else { return }
        groups = metadata.groups
        packageGroups = metadata.packageGroups
    }

    private func saveMetadata() {
        let metadata = MMDLibraryMetadata(groups: groups, packageGroups: packageGroups)
        if let data = try? JSONEncoder().encode(metadata) {
            try? data.write(to: metadataURL, options: .atomic)
        }
    }

    // MARK: - Library

    func refresh() {
        let fileManager = FileManager.default
        guard let enumerator = fileManager.enumerator(at: libraryURL,
                                                      includingPropertiesForKeys: [.isRegularFileKey],
                                                      options: [.skipsHiddenFiles]) else {
            entries = []
            return
        }
        var result: [MMDModelEntry] = []
        let rootPath = libraryURL.standardizedFileURL.path
        for case let url as URL in enumerator {
            guard url.pathExtension.lowercased() == "pmx" else { continue }
            guard (try? url.resourceValues(forKeys: [.isRegularFileKey]).isRegularFile) == true else { continue }
            let path = url.standardizedFileURL.path
            guard path.hasPrefix(rootPath + "/") else { continue }
            let relative = String(path.dropFirst(rootPath.count + 1))
            var components = relative.split(separator: "/").map(String.init)
            guard let fileName = components.popLast(), !fileName.isEmpty else { continue }
            let packageName = components.first ?? url.deletingLastPathComponent().lastPathComponent
            let packageURL = libraryURL.appendingPathComponent(packageName, isDirectory: true)
            let display = Self.friendlyDisplayName(pmx: url, packageName: packageName)
            result.append(MMDModelEntry(id: relative,
                                        displayName: display,
                                        pmxPath: url.path,
                                        packageURL: packageURL,
                                        assetDirectory: url.deletingLastPathComponent(),
                                        relativePath: relative,
                                        role: Self.isAccessoryPath(relative) ? .accessory : .character,
                                        groupID: packageGroups[packageName]))
        }
        result.sort { lhs, rhs in
            lhs.displayName.localizedStandardCompare(rhs.displayName) == .orderedAscending
        }
        entries = result
        MMDLog.shared.info("Library refreshed: \(result.count) model(s)")
    }

    @discardableResult
    func createGroup(name: String) -> MMDModelGroup {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let group = MMDModelGroup(name: trimmed.isEmpty ? "新建模型文件夹" : trimmed)
        groups.append(group)
        saveMetadata()
        return group
    }

    func renameGroup(_ group: MMDModelGroup, to name: String) {
        guard let index = groups.firstIndex(where: { $0.id == group.id }) else { return }
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        groups[index].name = trimmed
        saveMetadata()
    }

    func deleteGroup(_ group: MMDModelGroup) {
        groups.removeAll { $0.id == group.id }
        packageGroups = packageGroups.filter { $0.value != group.id }
        saveMetadata()
        refresh()
    }

    func assign(entries selected: [MMDModelEntry], to groupID: UUID?) {
        for entry in selected {
            packageGroups[entry.packageURL.lastPathComponent] = groupID
        }
        saveMetadata()
        refresh()
    }

    func groupName(for entry: MMDModelEntry) -> String {
        groups.first { $0.id == entry.groupID }?.name ?? "未分组"
    }

    func rename(_ entry: MMDModelEntry, to name: String) throws {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        let ext = URL(fileURLWithPath: entry.pmxPath).pathExtension
        let destination = entry.assetDirectory.appendingPathComponent(trimmed).appendingPathExtension(ext)
        if destination.path != entry.pmxPath {
            try FileManager.default.moveItem(at: URL(fileURLWithPath: entry.pmxPath), to: destination)
        }
        refresh()
    }

    /// Files are shown relative to the imported package so users can inspect
    /// exactly which textures/PMX files belong together before deleting them.
    func packageFiles(for entry: MMDModelEntry) -> [URL] {
        guard let enumerator = FileManager.default.enumerator(at: entry.packageURL,
                                                              includingPropertiesForKeys: [.isRegularFileKey],
                                                              options: [.skipsHiddenFiles]) else { return [] }
        var result = [URL]()
        for case let url as URL in enumerator {
            if (try? url.resourceValues(forKeys: [.isRegularFileKey]).isRegularFile) == true { result.append(url) }
        }
        return result.sorted { $0.path < $1.path }
    }

    func deleteFiles(_ files: [URL], in entry: MMDModelEntry) throws {
        let root = entry.packageURL.standardizedFileURL.path + "/"
        for file in files {
            guard file.standardizedFileURL.path.hasPrefix(root) else { continue }
            try FileManager.default.removeItem(at: file)
        }
        refresh()
    }

    func importFiles(_ files: [URL], into entry: MMDModelEntry) throws {
        let destination = entry.packageURL.appendingPathComponent("Imports", isDirectory: true)
        try FileManager.default.createDirectory(at: destination, withIntermediateDirectories: true)
        for file in files {
            if file.pathExtension.lowercased() == "zip" {
                _ = try MMDZipArchive.extract(url: file, to: destination)
            } else {
                try FileManager.default.copyItem(at: file, to: destination.appendingPathComponent(file.lastPathComponent))
            }
        }
        refresh()
    }

    func delete(entries selected: [MMDModelEntry]) {
        let allByPackage = Dictionary(grouping: entries, by: { $0.packageURL.path })
        let selectedByPackage = Dictionary(grouping: selected, by: { $0.packageURL.path })
        for (package, selectedInPackage) in selectedByPackage {
            guard let first = selectedInPackage.first else { continue }
            let selectedIDs = Set(selectedInPackage.map(\.id))
            let allIDs = Set(allByPackage[package]?.map(\.id) ?? [])
            if selectedIDs == allIDs {
                try? FileManager.default.removeItem(at: first.packageURL)
            } else {
                for item in selectedInPackage {
                    try? FileManager.default.removeItem(at: URL(fileURLWithPath: item.pmxPath))
                }
            }
        }
        refresh()
    }

    func open(_ entry: MMDModelEntry) throws -> MMDModelDocument {
        MMDLog.shared.info("Open model: \(entry.relativePath), assetDir=\(entry.assetDirectory.path)")
        let pmxURL = URL(fileURLWithPath: entry.pmxPath)
        let data = try Data(contentsOf: pmxURL)
        let model = try PMXParser(data: data).parse()
        MMDLog.shared.info("PMX parsed: vertices=\(model.vertices.count), materials=\(model.materials.count), bones=\(model.bones.count), morphs=\(model.morphs.count), textures=\(model.textures.count)")
        // Textures normally live beside the PMX, but multi-model packages often
        // keep a shared texture folder at the archive root. Both roots are
        // searched, with the PMX directory taking priority.
        let document = MMDModelDocument(model: model,
                                        baseDirectory: entry.assetDirectory,
                                        fallbackRoot: entry.packageURL == entry.assetDirectory ? nil : entry.packageURL,
                                        displayName: model.displayName)
        if entry.role == .character {
            var imported = 0
            for candidate in findAllPMX(in: entry.packageURL) where candidate.path != pmxURL.path {
                guard imported < 8, Self.shouldAutoAttach(candidate, relativeTo: model) else { continue }
                do {
                    let id = try document.addAttachment(url: candidate, autoBind: true)
                    document.updateAttachment(id: id) { $0.fallbackRoot = entry.packageURL }
                    imported += 1
                } catch {
                    MMDLog.shared.warning("Auto accessory failed: \(candidate.lastPathComponent): \(error.localizedDescription)", category: "Scene")
                }
            }
            if imported > 0 {
                MMDLog.shared.info("Package auto-assigned \(imported) accessory model(s)", category: "Scene")
                document.sceneEditEnabled = false
            }
        }
        if let vmd = findFile(withExtension: "vmd", in: entry.assetDirectory)
            ?? findFile(withExtension: "vmd", in: entry.packageURL) {
            do {
                try document.loadMotion(url: vmd)
                MMDLog.shared.info("Auto-loaded motion: \(vmd.lastPathComponent), \(document.motionMappingNote)")
            } catch {
                MMDLog.shared.warning("Auto motion load failed: \(error.localizedDescription)")
            }
        }
        return document
    }

    func delete(_ entry: MMDModelEntry) {
        delete(entries: [entry])
    }

    // MARK: - Import

    /// Import one folder, PMX file, or ZIP archive. All PMX files found inside
    /// the imported folder are registered, not just the first one.
    func importModel(from source: URL) throws -> MMDModelEntry {
        let result = try importModels(from: [source])
        guard let first = result.entries.first else {
            throw MMDLoadError.invalidData("没有找到可导入的模型")
        }
        return first
    }

    func importModels(from sources: [URL]) throws -> MMDImportResult {
        var entries = [MMDModelEntry]()
        var warnings = [String]()
        for source in sources {
            let accessed = source.startAccessingSecurityScopedResource()
            defer { if accessed { source.stopAccessingSecurityScopedResource() } }
            MMDLog.shared.info("Import source: \(source.lastPathComponent), securityScope=\(accessed)")

            let fileManager = FileManager.default
            let isDirectory = (try? source.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
            let extensionName = source.pathExtension.lowercased()
            let stem = source.deletingPathExtension().lastPathComponent
            let baseName = stem.isEmpty ? "导入模型" : stem
            let destination = uniqueFolder(named: baseName)
            try fileManager.createDirectory(at: destination, withIntermediateDirectories: true)

            do {
                if isDirectory {
                    let contents = try fileManager.contentsOfDirectory(at: source,
                                                                       includingPropertiesForKeys: nil,
                                                                       options: [.skipsHiddenFiles])
                    for item in contents {
                        let target = destination.appendingPathComponent(item.lastPathComponent)
                        if !fileManager.fileExists(atPath: target.path) {
                            try fileManager.copyItem(at: item, to: target)
                        }
                    }
                    MMDLog.shared.info("Copied folder: \(contents.count) top-level item(s)")
                } else if extensionName == "zip" {
                    let extracted = try MMDZipArchive.extract(url: source, to: destination)
                    MMDLog.shared.info("ZIP extracted: \(extracted) file(s) -> \(destination.path)")
                } else if extensionName == "pmx" {
                    try fileManager.copyItem(at: source,
                                             to: destination.appendingPathComponent(source.lastPathComponent))
                    if !copySiblingResources(from: source.deletingLastPathComponent(), to: destination) {
                        warnings.append("单个 PMX 可能缺少同目录贴图；如贴图缺失，请改选模型文件夹或 ZIP。")
                    }
                } else {
                    throw MMDLoadError.unsupported("不支持的文件类型 .\(extensionName)")
                }
            } catch {
                MMDLog.shared.error("Import copy/extract failed: \(error.localizedDescription)")
                try? fileManager.removeItem(at: destination)
                throw error
            }

            let pmxFiles = findAllPMX(in: destination)
            guard !pmxFiles.isEmpty else {
                try? fileManager.removeItem(at: destination)
                throw MMDLoadError.invalidData("导入内容中没有找到 .pmx 模型文件")
            }
            MMDLog.shared.info("Found \(pmxFiles.count) PMX model(s) in \(destination.lastPathComponent)")
            if pmxFiles.count > 1 {
                warnings.append("\(source.lastPathComponent) 中发现 \(pmxFiles.count) 个模型，已全部加入模型库。")
            }

            for pmx in pmxFiles {
                let path = pmx.standardizedFileURL.path
                let rootPath = libraryURL.standardizedFileURL.path
                let relative = path.hasPrefix(rootPath + "/") ? String(path.dropFirst(rootPath.count + 1)) : pmx.lastPathComponent
                let display = Self.friendlyDisplayName(pmx: pmx, packageName: destination.lastPathComponent)
                entries.append(MMDModelEntry(id: relative,
                                             displayName: display,
                                             pmxPath: pmx.path,
                                             packageURL: destination,
                                             assetDirectory: pmx.deletingLastPathComponent(),
                                             relativePath: relative))
            }
        }
        refresh()
        return MMDImportResult(entries: entries, warnings: warnings)
    }

    /// Copy images and nested texture folders next to a single PMX. Returns
    /// false when the source directory cannot be read at all.
    @discardableResult
    private func copySiblingResources(from parent: URL, to destination: URL) -> Bool {
        let fileManager = FileManager.default
        guard let contents = try? fileManager.contentsOfDirectory(at: parent,
                                                                  includingPropertiesForKeys: [.isDirectoryKey],
                                                                  options: [.skipsHiddenFiles]) else {
            return false
        }
        let imageExtensions: Set<String> = ["png", "jpg", "jpeg", "bmp", "tga", "gif", "webp", "dds"]
        for item in contents {
            let isDirectory = (try? item.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
            let target = destination.appendingPathComponent(item.lastPathComponent)
            if fileManager.fileExists(atPath: target.path) { continue }
            if isDirectory {
                try? fileManager.copyItem(at: item, to: target)
            } else if imageExtensions.contains(item.pathExtension.lowercased()) {
                try? fileManager.copyItem(at: item, to: target)
            }
        }
        return true
    }

    private func uniqueFolder(named rawName: String) -> URL {
        let sanitized = rawName.replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "\\", with: "_")
            .replacingOccurrences(of: ":", with: "_")
            .replacingOccurrences(of: "..", with: "_")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let name = sanitized.isEmpty ? "导入模型" : sanitized
        var candidate = libraryURL.appendingPathComponent(name, isDirectory: true)
        var index = 2
        while FileManager.default.fileExists(atPath: candidate.path) {
            candidate = libraryURL.appendingPathComponent("\(name) \(index)", isDirectory: true)
            index += 1
        }
        return candidate
    }

    // MARK: - Legacy cleanup

    /// Earlier builds shipped a generated sample PMX/VMD. It is no longer
    /// part of the app; remove the old copy from Documents on upgrade so the
    /// library starts clean.
    private func removeLegacySampleIfNeeded() {
        let fileManager = FileManager.default
        let destination = libraryURL.appendingPathComponent("SampleModel", isDirectory: true)
        guard fileManager.fileExists(atPath: destination.path) else { return }
        do {
            try fileManager.removeItem(at: destination)
            MMDLog.shared.info("Removed legacy SampleModel")
        } catch {
            MMDLog.shared.warning("Legacy SampleModel removal failed: \(error.localizedDescription)")
        }
    }

    // MARK: - Helpers

    private func findAllPMX(in folder: URL) -> [URL] {
        let fileManager = FileManager.default
        guard let enumerator = fileManager.enumerator(at: folder,
                                                      includingPropertiesForKeys: [.isRegularFileKey],
                                                      options: [.skipsHiddenFiles]) else { return [] }
        var files = [URL]()
        for case let url as URL in enumerator {
            guard url.pathExtension.lowercased() == "pmx" else { continue }
            if (try? url.resourceValues(forKeys: [.isRegularFileKey]).isRegularFile) == true {
                files.append(url)
            }
        }
        return files.sorted { $0.path.localizedStandardCompare($1.path) == .orderedAscending }
    }

    private static func isAccessoryPath(_ path: String) -> Bool {
        let value = path.lowercased()
        let keywords = ["weapon", "sword", "katana", "gun", "rifle", "prop", "accessor",
                        "hat", "cap", "crown", "glasses", "mask", "bag", "backpack",
                        "武器", "配饰", "道具", "剑", "刀", "枪", "帽", "眼镜", "面具", "背包"]
        return keywords.contains { value.contains($0) }
    }

    private static func shouldAutoAttach(_ url: URL, relativeTo character: PMXModel) -> Bool {
        if isAccessoryPath(url.path) { return true }
        guard let data = try? Data(contentsOf: url, options: [.mappedIfSafe]),
              let model = try? PMXParser(data: data).parse() else { return false }
        // Conservative fallback: only small, non-humanoid static meshes are
        // treated as props. Alternative full characters stay independent.
        let hasHead = model.bones.contains {
            let name = MMDModelDocument.normalizedBoneName($0.name)
            return ["head", "頭", "头"].contains { name == $0 || name.contains($0) }
        }
        let hasThigh = model.bones.contains {
            let name = MMDModelDocument.normalizedBoneName($0.name)
            return ["thigh", "leg", "足", "腿"].contains { name.contains($0) }
        }
        let smallEnough = model.vertices.count < max(500, character.vertices.count / 3)
        return smallEnough && (!hasHead || !hasThigh) && model.bones.count <= 8
    }

    private func findPMX(in folder: URL) -> URL? {
        findAllPMX(in: folder).first
    }

    private func findFile(withExtension ext: String, in folder: URL) -> URL? {
        guard let enumerator = FileManager.default.enumerator(at: folder,
                                                              includingPropertiesForKeys: [.isRegularFileKey],
                                                              options: [.skipsHiddenFiles]) else { return nil }
        for case let url as URL in enumerator {
            if url.pathExtension.lowercased() == ext { return url }
        }
        return nil
    }

    private static func friendlyDisplayName(pmx: URL, packageName: String) -> String {
        if let data = try? Data(contentsOf: pmx, options: [.mappedIfSafe]),
           let headerName = PMXParser.readDisplayName(data: data) {
            let trimmed = headerName.trimmingCharacters(in: .whitespacesAndNewlines)
            let generic: Set<String> = ["model", "mesh", "body", "character", "mmd", "main", "untitled", "pmx", "default", "モデル"]
            if !trimmed.isEmpty && !generic.contains(trimmed.lowercased()) {
                return trimmed
            }
        }
        let stem = pmx.deletingPathExtension().lastPathComponent
        // If the archive stored a CP1252/Latin-1 interpretation of a CJK
        // filename, macOS exposes combining marks such as I+U+0302. Do not
        // show that garbage in the library; the package name is a better
        // fallback until the user re-imports the archive.
        if stem.unicodeScalars.contains(where: { (0x0300...0x036F).contains($0.value) }) {
            return packageName
        }
        if let repaired = MMDZipArchive.repairedFilename(stem), repaired != stem {
            return repaired
        }
        let generic: Set<String> = ["model", "mesh", "body", "character", "mmd", "main", "untitled", "pmx", "default"]
        if generic.contains(stem.lowercased()) || stem.isEmpty {
            return packageName
        }
        return stem.replacingOccurrences(of: "_", with: " ")
    }
}
