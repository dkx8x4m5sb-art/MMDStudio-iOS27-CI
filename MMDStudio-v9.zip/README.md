# MMD Studio

原生 iOS 的 PMX 模型浏览、编辑与 MMD 动作播放器。使用 SwiftUI + Metal 与自研渲染管线；视频动作使用 MediaPipe Tasks Vision（Apache-2.0）在本机推理。

> 目标系统：iOS 17.0 及以上，可直接在 iOS 27 上运行。使用 iOS 27 SDK 的 Xcode 打开即可；部署目标保持 17.0，以兼容更多设备。

## 构建与运行

仓库已附带 `.github/workflows/build-ipa.yml`。v8 源码通过 GitHub Actions 的 `macos-15-intel` runner + Xcode 16.4 实际构建；本源码包是同一份编译通过的源码。

1. 解压源码包。
2. 用 Xcode 打开 `MMDStudio.xcodeproj`。
3. 在 target **MMDStudio** 的 *Signing & Capabilities* 中选择你的 Apple Developer Team；如需上架，把 Bundle Identifier 从 `com.mmdstudio.app` 改成自己的。
4. Scheme 选择 **MMDStudio**，设备选择 iPhone 或 iPad，点击 Run。

工程使用 Swift Package Manager 解析 Google MediaPipe Tasks Vision（`https://github.com/google-ai-edge/mediapipe`，分支 `master`）。首次打开需要联网让 Xcode 拉取依赖；仓库不内置示例模型或动作，首次启动模型库为空。

如果 Xcode 提示签名失败，先选择 Team；模拟器通常不需要签名。若要在 iOS 27 真机验证，请在 Xcode 中选择带 iOS 27 SDK 的版本，并确认设备已信任开发者证书。

## 功能

- **导入**：从「文件」App 选择整个 PMX 模型文件夹、单个 `.pmx` 或 `.zip`。ZIP 会自动解压并递归识别所有 PMX，保留 `tex/`、`sph/` 等贴图子目录；只识别到一个模型时会自动打开并加载贴图。
- **浏览**：轨道相机（单指旋转、双指平移、捏合缩放、双击重置），自动按模型包围盒取景；渐变摄影棚背景、柔和接触阴影、可选网格、骨骼线框叠加。
- **PMX 渲染**：PMX 2.0 / 2.1；UTF-16LE / UTF-8 文本；BDEF1 / BDEF2 / BDEF4 / QDEF 权重（SDEF 近似为 BDEF2）；GPU 蒙皮；卡通渐变；球面贴图（乘法 / 加法）；基础贴图；透明混合；反壳描边；Alpha 裁切；双面材质。
- **材质编辑**：漫反射颜色、不透明度、显示开关、双面、地面阴影、基础贴图开关、卡通渐变开关、球面模式、描边颜色/宽度/开关、恢复单个或全部材质默认值。
- **顶点变形**：顶点 Morph 与组 Morph 的滑杆；可与 VMD 的 Morph 关键帧叠加。
- **骨骼编辑**：搜索骨骼；手动 X/Y/Z 旋转（角度）；单根或全部归零；选中骨骼在视图中高亮，并显示 IK 目标连线。
- **VMD 动作**：骨骼关键帧（位置/四元数/贝塞尔补间）、Morph 关键帧、相机关键帧；30 FPS 播放、拖动进度、循环、0.5x–2x 速度、VMD 相机开关、替换/移除动作。
- **视频转动作（v8）**：MediaPipe BlazePose 33 关键点、30 Hz 采样，按视频完整时长生成时间轴；肩、上臂、前臂、手、躯干、头、大腿、小腿、脚掌全部输出轨道。语义绑定会排除 `左肩P`、`左腕捩`、`左足先` 等 helper/twist 骨，并输出详细骨骼映射日志与检测覆盖区间。
- **渲染工作台（v8）**：画风预设、卡通阴影柔化/暗部抬亮/阴影色调/轮廓光、主光/补光、对比度/饱和度/曝光/暗角、描边与输出分辨率集中编辑。
- **离屏渲染图（v8）**：独立 Metal 渲染目标，支持 1080×1920、1440×2560、2160×3840、2048×2048，可透明背景、网格与骨骼线；不再回退为屏幕截图。
- **贴图导出（v8）**：按 PNG/JPG/BMP/TGA/DDS 原始文件复制到 `Documents/MMDStudio/Exports/Textures`，不转码、不压缩，并生成 `_manifest.txt` 清单。
- **日志（v8）**：按信息/警告/错误筛选、全文搜索、分类与来源显示、一键复制、合并上一轮日志后分享；新增人体骨骼绑定明细、视频检测覆盖区间和离屏渲染尺寸日志。
- **模型信息**：版本、顶点/三角面/材质/骨骼/变形/贴图数量、尺寸、解析警告。

## 操作

- 单指拖动：旋转视角
- 双指拖动：平移目标点
- 捏合：缩放
- 双击：重置相机
- 顶部画风条：MMD 标准 / 原神 / 星穹铁道 / 绝区零 / 写实一键切换
- 底部命令栏：材质、贴图、表情、骨骼、灯光、相机、设置、重置、骨架、拍照、录制
- 底部播放栏：播放/暂停、进度、循环、速度、相机动作、更换 VMD

## 目录结构

```
MMDStudio/
├── MMDStudio.xcodeproj
├── MMDStudio/
│   ├── App/                 # App 入口、文档状态、模型库
│   ├── Core/                # PMX/VMD 解析、数学、动画、贴图
│   ├── Render/              # Metal 渲染器、网格构建、着色器
│   ├── UI/                  # SwiftUI 页面与 Inspector
│   ├── Assets.xcassets
│   └── Info.plist
└── README.md
```

主要类型：

- `MMDStore`：模型库、文件夹/单文件导入。
- `MMDModelDocument`：当前模型、材质/Morph/骨骼编辑状态、VMD 播放。
- `PMXParser` / `VMDParser`：二进制解析与坐标转换。
- `MMDSkeleton` / `MMDMorphController`：骨骼世界矩阵、蒙皮 palette、Morph 顶点位移。
- `MMDMeshBuilder` / `MMDRenderer` / `Shaders.metal`：Metal 资源、渲染通道与着色。

## 坐标与格式约定

- PMX 为左手坐标系；加载时顶点位置、法线、Morph 偏移的 Z 取负，转为右手系。模型正面朝 +Z，默认相机在 +Z。
- VMD 四元数 `(x,y,z,w)` 转为 `(-x,-y,z,w)`，位移 Z 取负。
- 三角形绕序不信任导出器：按面法线与顶点法线的一致性自动翻转，并按整体得分设置 `MTLWinding`。
- 渲染顺序：渐变背景 → 可选网格 → 柔和接触阴影 → 不透明材质（Alpha 裁切）→ 反壳描边 → 透明材质（按材质中心到相机距离排序）→ 骨骼线框。

## 示例资产

本版本不内置示例模型或动作，避免安装包携带占位资产。请导入自己的 PMX 文件夹与 VMD/视频动作。

## 当前限制

- 不计算 PMX 刚体与柔软体物理（无重力、碰撞、布料）。
- 不求解 IK；IK 信息会解析并在 UI 中提示，但姿态由 VMD 骨骼旋转直接驱动。
- 不支持 PMD；不支持 VMD 音频、表情音轨、VPV。
- SDEF 按 BDEF2 近似；材质 Morph、UV Morph、骨骼 Morph 会解析但暂不参与渲染。
- VMD 相机姿态为近似实现，忽略 roll；未与 MMD 原版逐帧比对。
- 不提供模型导出或视频导出；视频动作会额外备份一份 VMD 到 `Documents/MMDStudio/GeneratedMotions`，但正式动作仍以内存轨道直接驱动。

## 构建状态与验证

v8 已在 GitHub Actions 的 `macos-15-intel` runner、Xcode 16.4 上完成实际 `xcodebuild archive`，生成未签名 IPA（run #31，commit `4ffb957`）：

- 架构：arm64
- 最低系统：iOS 17.0
- 版本：`8.0` / build `8`
- IPA 大小：19,371,195 字节
- 产物：`MMDStudio-unsigned-v8.ipa`

已完成以下验证：

- `default.metallib` 已随 target 编译进 App 包；卡通阴影参数与平滑法线进入最终二进制。
- `info.plist` 校验 `CFBundleShortVersionString=8.0`、`CFBundleVersion=8`。
- 二进制符号包含 `Humanoid auto-bind`、`Video motion coverage: first=`、`RenderStudioView`、`toonSoftness`，确认 v8 的骨骼绑定日志、完整时长检测、渲染工作台与卡通参数已进入构建，而非仅有版本号变化。
- Xcode `project.pbxproj` 通过 Python `pbxproj` 解析，target `MMDStudio` 与 Build Phases 可识别。

真机上的模型观感、视频动作效果、贴图导出和日志交互仍需实际设备验收；CI 只能证明工程可编译、可打包。

## 故障排除

- **启动后模型库为空**：这是正常行为，本版本不再附带示例模型；请从「文件」App 导入 PMX 文件夹。
- **模型黑屏 / 无画面**：检查 `Shaders.metal` 是否在 target 的 Compile Sources；查看 Xcode 控制台是否有 Metal pipeline 创建失败日志。
- **贴图丢失**：优先导入整个模型文件夹；PMX 内的 Windows 绝对路径会回退到文件名匹配，并做大小写不敏感查找。
- **真机无法安装**：设置 Team 与唯一 Bundle Identifier；确认设备系统版本 ≥ iOS 17。
