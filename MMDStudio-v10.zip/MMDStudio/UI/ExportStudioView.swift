import SwiftUI
import UIKit

struct ExportStudioView: View {

    @ObservedObject var document: MMDModelDocument
    @Environment(\.dismiss) private var dismiss
    @StateObject private var videoExporter = MMDVideoExporter()

    @State private var modelSummary: MMDModelExportSummary?
    @State private var modelError: String?
    @State private var modelExporting = false
    @State private var shareItems: [URL] = []
    @State private var showShare = false

    var body: some View {
        NavigationStack {
            List {
                Section("模型与姿态") {
                    Button {
                        exportModel()
                    } label: {
                        HStack {
                            Label(modelExporting ? "正在导出当前姿态…" : "导出当前姿态 OBJ + MTL + VPD",
                                  systemImage: "cube.transparent")
                            Spacer()
                            if modelExporting { ProgressView().scaleEffect(0.8) }
                        }
                    }
                    .disabled(modelExporting)
                    Text("OBJ 会烘焙当前帧的骨骼蒙皮与顶点表情，附原格式贴图和原始 PMX/PMD 副本；VPD 可导回 MMD。OBJ 不携带骨骼、IK、刚体、材质变形滑块，PMX 副本保持原样未修改。")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                    if let summary = modelSummary {
                        LabeledContent("贴图/资源", value: "\(summary.copiedAssets) 个")
                        LabeledContent("原始模型", value: summary.copiedSourceModel ? "已复制" : "无源文件")
                        Text(summary.directory.path)
                            .font(.system(size: 9, design: .monospaced))
                            .foregroundStyle(.secondary)
                            .textSelection(.enabled)
                        Button {
                            shareItems = [summary.objURL, summary.mtlURL, summary.directory]
                            showShare = true
                        } label: {
                            Label("分享 OBJ 与目录", systemImage: "square.and.arrow.up")
                        }
                    }
                    if let modelError {
                        Text(modelError).font(.caption).foregroundStyle(.red)
                    }
                }

                Section("离线视频") {
                    LabeledContent("画面", value: "1080 × 1920 · 30 FPS · H.264")
                    LabeledContent("时长", value: document.durationText)
                    LabeledContent("总帧数", value: "\(Int(ceil(Double(document.durationSeconds) * 30)) + 1)")
                    if videoExporter.isExporting {
                        ProgressView(value: videoExporter.progress)
                        Text(videoExporter.statusText)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        Button("取消导出", role: .destructive) {
                            videoExporter.cancel()
                        }
                    } else {
                        Button {
                            startVideoExport()
                        } label: {
                            Label("按 VMD 时间轴导出 MP4", systemImage: "film.stack")
                        }
                        .disabled(!document.hasMotion)
                        Text(videoExporter.statusText.isEmpty
                             ? "逐帧驱动当前帧并离屏 Metal 渲染，不是屏幕录制；有同步音频时会合并音轨。导出期间请保持页面在前台。"
                             : videoExporter.statusText)
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                    if let url = videoExporter.outputURL {
                        Text(url.path)
                            .font(.system(size: 9, design: .monospaced))
                            .foregroundStyle(.secondary)
                            .textSelection(.enabled)
                        Button {
                            shareItems = [url]
                            showShare = true
                        } label: {
                            Label("分享 MP4", systemImage: "square.and.arrow.up")
                        }
                    }
                    if let error = videoExporter.errorText {
                        Text(error).font(.caption).foregroundStyle(.red)
                    }
                }

                Section("说明") {
                    Text("视频导出分辨率固定为 1080×1920，使用 H.264；透明背景在 MP4 中会合成为当前背景色。模型导出格式为 OBJ（当前姿态）与原始 PMX/PMD 副本、VPD 姿态，不做 PMX 重写。")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("导出工作室")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("完成") { dismiss() }
                }
            }
            .sheet(isPresented: $showShare) {
                ActivityView(items: shareItems)
            }
        }
    }

    private func exportModel() {
        guard !modelExporting else { return }
        modelExporting = true
        modelError = nil
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                let summary = try MMDModelExporter.exportCurrentPose(document: document)
                DispatchQueue.main.async {
                    modelSummary = summary
                    modelExporting = false
                }
            } catch {
                DispatchQueue.main.async {
                    modelError = error.localizedDescription
                    modelExporting = false
                }
            }
        }
    }

    private func startVideoExport() {
        guard let renderer = MMDRenderer.active else {
            videoExporter.errorText = "找不到 Metal 渲染器，请返回模型页面后重试"
            return
        }
        document.pause()
        videoExporter.export(document: document, renderer: renderer)
    }
}
