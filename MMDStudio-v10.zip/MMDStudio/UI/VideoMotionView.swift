import SwiftUI
import UniformTypeIdentifiers

struct VideoMotionView: View {
    @ObservedObject var document: MMDModelDocument
    @Environment(\.dismiss) private var dismiss

    @State private var showPicker = false
    @State private var videoURL: URL?
    @State private var isProcessing = false
    @State private var progress: Double = 0
    @State private var status: String?
    @State private var errorText: String?
    @ObservedObject private var poseStore = MMDPoseModelStore.shared
    @State private var selectedModel: MMDPoseModelKind = .lite

    private let extractor = MMDVideoMotionExtractor()

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Text("从一段正面、全身的舞蹈视频中提取关节点，直接驱动当前模型的骨骼。建议固定机位、人物完整入镜、光线充足。")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }

                Section("当前模型") {
                    LabeledContent("人体关节", value: "\(document.humanoidBoneNameMap().count) / \(MMDHumanoidJoint.allCases.count)")
                    Text(document.humanoidBoneNameMap().isEmpty
                         ? "尚未绑定人体骨骼。请先在骨骼面板执行自动绑定，否则动作无法落到模型上。"
                         : "动作会按模型真实骨骼名写入轨道，不再依赖 VMD 的名称匹配。")
                        .font(.caption2)
                        .foregroundStyle(document.humanoidBoneNameMap().isEmpty ? Color.orange : Color.secondary)
                }

                Section("视频") {
                    Button {
                        showPicker = true
                    } label: {
                        Label(videoURL == nil ? "选择舞蹈视频" : "重新选择视频",
                              systemImage: "video.badge.plus")
                    }
                    if let videoURL {
                        LabeledContent("文件", value: videoURL.lastPathComponent)
                    }
                }

                Section("姿态模型（开源）") {
                    Picker("使用模型", selection: $selectedModel) {
                        ForEach(MMDPoseModelKind.allCases) { kind in
                            Text(kind.title).tag(kind)
                        }
                    }
                    ForEach(MMDPoseModelKind.allCases) { kind in
                        HStack(spacing: 10) {
                            Image(systemName: kind == .lite ? "iphone" : "arrow.down.circle")
                                .foregroundStyle(poseStore.isAvailable(kind) ? Color.cyan : Color.gray)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(kind.title)
                                    .font(.subheadline.weight(kind == selectedModel ? .semibold : .regular))
                                Text(kind.detail)
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            if kind.isBundled {
                                Text("内置")
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                            } else if poseStore.isAvailable(kind) {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundStyle(.green)
                                    .onTapGesture { poseStore.remove(kind) }
                            } else if poseStore.downloading == kind {
                                ProgressView()
                                    .scaleEffect(0.8)
                            } else {
                                Button("下载") { poseStore.download(kind) }
                                    .buttonStyle(.bordered)
                                    .font(.caption)
                            }
                        }
                        .contentShape(Rectangle())
                        .onTapGesture {
                            if poseStore.isAvailable(kind) { selectedModel = kind }
                        }
                    }
                    if let error = poseStore.lastError {
                        Text(error)
                            .font(.caption2)
                            .foregroundStyle(.red)
                    }
                    Text("Full/Heavy 从 Google 官方模型库下载到 Documents/MMDStudio/Models，不占安装包；下载后可离线推理。")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }

                Section("更多开源方案（外部链接）") {
                    ForEach(mmdExternalMotionSchemes) { scheme in
                        Link(destination: scheme.url) {
                            VStack(alignment: .leading, spacing: 3) {
                                HStack {
                                    Text(scheme.title)
                                        .font(.subheadline.weight(.semibold))
                                    Spacer()
                                    Image(systemName: "arrow.up.right.square")
                                        .font(.caption)
                                }
                                Text(scheme.detail)
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                                    .multilineTextAlignment(.leading)
                            }
                        }
                    }
                }

                if isProcessing {
                    Section("提取进度") {
                        ProgressView(value: progress)
                        Text("\(Int(progress * 100))% · 正在逐帧估计人体姿态")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }

                if let status {
                    Section {
                        Label(status, systemImage: "checkmark.circle.fill")
                            .foregroundStyle(.green)
                        if !document.motionMappingNote.isEmpty {
                            Text(document.motionMappingNote)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                }

                if let errorText {
                    Section {
                        Text(errorText)
                            .font(.caption)
                            .foregroundStyle(.red)
                    }
                }

                Section("实现说明") {
                    Text("App 内使用 MediaPipe BlazePose（Apache-2.0，33 关键点）做姿态估计：按 30 Hz 逐帧采样，输出与视频等长的完整时间轴，驱动肩、上臂、前臂、手、躯干、头、大腿、小腿和脚掌；四元数平滑保留快速节拍。单目视频缺少真实深度，快速旋转和遮挡仍可能产生误差。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section {
                    Button {
                        startExtraction()
                    } label: {
                        HStack {
                            Spacer()
                            Label("生成并载入动作", systemImage: "figure.dance")
                                .font(.headline)
                            Spacer()
                        }
                    }
                    .disabled(videoURL == nil || isProcessing
                              || !poseStore.isAvailable(selectedModel)
                              || document.humanoidBoneNameMap().count < 4)
                }
            }
            .navigationTitle("视频转动作")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("完成") { dismiss() }
                }
            }
            .sheet(isPresented: $showPicker) {
                MMDDocumentPicker(contentTypes: [.movie],
                                  allowsMultipleSelection: false,
                                  onPick: { urls in
                                      showPicker = false
                                      videoURL = urls.first
                                      status = nil
                                      errorText = nil
                                  },
                                  onCancel: { showPicker = false })
            }
        }
    }

    private func startExtraction() {
        guard let videoURL, !isProcessing else { return }
        isProcessing = true
        progress = 0
        status = nil
        errorText = nil
        let boneNames = document.humanoidBoneNameMap()
        guard boneNames.count >= 4 else {
            isProcessing = false
            errorText = "模型人体关节不足（\(boneNames.count) 个）。请先在骨骼面板执行自动绑定。"
            return
        }
        MMDLog.shared.info("Video motion extraction requested: \(videoURL.lastPathComponent), " +
                           "joints=\(boneNames.count)", category: "VideoMotion")
        let modelURL = poseStore.localURL(for: selectedModel)
        extractor.extract(from: videoURL, modelURL: modelURL, boneNames: boneNames,
                          bodyHeight: document.model.bounds.height, progress: { value in
            DispatchQueue.main.async { self.progress = value }
        }, completion: { result in
            DispatchQueue.main.async {
                isProcessing = false
                switch result {
                case .success(let output):
                    do {
                        try document.loadGeneratedMotion(output.motion, name: "视频动作")
                        let seconds = MMDModelDocument.formatTime(output.duration)
                        let exportNote = output.url.map { "；VMD 备份：\($0.lastPathComponent)" } ?? ""
                        status = "已载入动作：\(seconds)，映射 \(output.boneCount) 根骨骼 / " +
                                 "\(output.mappedJoints.count) 个关节，检测覆盖 " +
                                 "\(String(format: "%.1f", output.firstPoseTime))–\(String(format: "%.1f", output.lastPoseTime))s / " +
                                 "\(String(format: "%.1f", output.videoDuration))s\(exportNote)"
                        if output.boneCount < 8 {
                            status = "动作只映射到 \(output.boneCount) 根骨骼，效果可能不完整。请检查自动绑定。"
                        }
                        document.play()
                        MMDLog.shared.info("Video motion installed: bones=\(output.boneCount), " +
                                           "joints=\(output.mappedJoints.count), frames=\(output.detectedFrames)",
                                           category: "VideoMotion")
                    } catch {
                        errorText = "动作已生成，但载入失败：\(error.localizedDescription)"
                        MMDLog.shared.error("loadGeneratedMotion failed: \(error.localizedDescription)",
                                            category: "VideoMotion")
                    }
                case .failure(let error):
                    errorText = error.localizedDescription
                }
            }
        })
    }
}
