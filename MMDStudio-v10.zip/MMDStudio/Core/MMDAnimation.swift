import Foundation
import simd

struct MMDBoneAnimation {
    var position: SIMD3<Float> = .zero
    var rotation: simd_quatf = mmdIdentityQuaternion
}

struct MMDSkeletonPose {
    var worldMatrices: [simd_float4x4]
    var palettes: [simd_float4x4]
}

/// Computes skinning matrices for the PMX skeleton.
final class MMDSkeleton {

    let boneCount: Int
    private let parentIndices: [Int]
    private let restLocal: [SIMD3<Float>]
    private let order: [Int]
    private let inverseBind: [simd_float4x4]
    let restWorld: [simd_float4x4]

    init(model: PMXModel) {
        boneCount = model.bones.count
        parentIndices = model.bones.map { $0.parentIndex }
        var locals = [SIMD3<Float>](repeating: .zero, count: model.bones.count)
        for (index, bone) in model.bones.enumerated() {
            if bone.parentIndex >= 0 && bone.parentIndex < model.bones.count {
                locals[index] = bone.position - model.bones[bone.parentIndex].position
            } else {
                locals[index] = bone.position
            }
        }
        restLocal = locals

        var order = [Int]()
        order.reserveCapacity(model.bones.count)
        var visited = [Bool](repeating: false, count: model.bones.count)
        for bone in model.bones.indices where !visited[bone] {
            var chain = [Int]()
            var cursor = bone
            var guardCount = 0
            while cursor >= 0 && cursor < model.bones.count && !visited[cursor] && guardCount <= model.bones.count {
                chain.append(cursor)
                cursor = model.bones[cursor].parentIndex
                guardCount += 1
            }
            while let item = chain.popLast() {
                if !visited[item] {
                    visited[item] = true
                    order.append(item)
                }
            }
        }
        self.order = order

        var worlds = [simd_float4x4](repeating: matrix_identity_float4x4, count: model.bones.count)
        for index in order {
            let local = simd_float4x4.translation(locals[index])
            let parent = parentIndices[index]
            worlds[index] = (parent >= 0 ? worlds[parent] : matrix_identity_float4x4) * local
        }
        restWorld = worlds
        inverseBind = worlds.map { simd_inverse($0) }
    }

    func solve(animations: [Int: MMDBoneAnimation], model: PMXModel,
               ikEnabled: Bool = false) -> MMDSkeletonPose {
        guard boneCount > 0 else {
            return MMDSkeletonPose(worldMatrices: [], palettes: [matrix_identity_float4x4])
        }
        guard ikEnabled else { return solveFK(animations: animations, model: model) }

        var working = animations
        var pose = solveFK(animations: working, model: model)
        for (ikBoneIndex, bone) in model.bones.enumerated() {
            guard let ik = bone.ik, ik.targetIndex >= 0, ik.targetIndex < boneCount,
                  !ik.links.isEmpty else { continue }
            let iterations = max(1, min(16, ik.iterations))
            for _ in 0..<iterations {
                let target = pose.worldMatrices[ikBoneIndex].translation
                let effector = pose.worldMatrices[ik.targetIndex].translation
                if simd_distance(target, effector) < 0.0005 { break }
                var moved = false
                for link in ik.links {
                    let linkIndex = link.boneIndex
                    guard linkIndex >= 0 && linkIndex < boneCount else { continue }
                    let pivot = pose.worldMatrices[linkIndex].translation
                    let current = effector - pivot
                    let desired = target - pivot
                    let currentLength = simd_length(current)
                    let desiredLength = simd_length(desired)
                    guard currentLength > 0.00001, desiredLength > 0.00001 else { continue }
                    let currentDir = current / currentLength
                    let desiredDir = desired / desiredLength
                    let dotValue = max(-1, min(1, simd_dot(currentDir, desiredDir)))
                    if abs(dotValue - 1) < 0.0001 { continue }
                    let axis: SIMD3<Float>
                    if simd_length(simd_cross(currentDir, desiredDir)) < 0.00001 {
                        axis = simd_normalize(simd_cross(currentDir, SIMD3<Float>(0, 1, 0)))
                    } else {
                        axis = simd_normalize(simd_cross(currentDir, desiredDir))
                    }
                    let angle = acos(dotValue) * class_half_clamp(ik.angleLimit)
                    let worldAlignment = simd_quatf(angle: angle, axis: axis)

                    let parent = model.bones[linkIndex].parentIndex
                    let parentRotation = parent >= 0 ? pose.worldMatrices[parent] : matrix_identity_float4x4
                    let parentQuat = quatFromRotationMatrix(simd_float3x3(
                        SIMD3<Float>(parentRotation.columns.0.x, parentRotation.columns.0.y, parentRotation.columns.0.z),
                        SIMD3<Float>(parentRotation.columns.1.x, parentRotation.columns.1.y, parentRotation.columns.1.z),
                        SIMD3<Float>(parentRotation.columns.2.x, parentRotation.columns.2.y, parentRotation.columns.2.z)))
                    let linkWorld = pose.worldMatrices[linkIndex]
                    let linkQuat = quatFromRotationMatrix(simd_float3x3(
                        SIMD3<Float>(linkWorld.columns.0.x, linkWorld.columns.0.y, linkWorld.columns.0.z),
                        SIMD3<Float>(linkWorld.columns.1.x, linkWorld.columns.1.y, linkWorld.columns.1.z),
                        SIMD3<Float>(linkWorld.columns.2.x, linkWorld.columns.2.y, linkWorld.columns.2.z)))
                    var localRotation = parentQuat.inverse * worldAlignment * linkQuat
                    if link.hasLimit {
                        var euler = quatEulerDegrees(localRotation)
                        euler.x = max(link.lowerLimit.x * 57.2958, min(link.upperLimit.x * 57.2958, euler.x))
                        euler.y = max(link.lowerLimit.y * 57.2958, min(link.upperLimit.y * 57.2958, euler.y))
                        euler.z = max(link.lowerLimit.z * 57.2958, min(link.upperLimit.z * 57.2958, euler.z))
                        localRotation = quatFromEuler(SIMD3<Float>(mmdRadians(euler.x), mmdRadians(euler.y), mmdRadians(euler.z)))
                    }
                    var animation = working[linkIndex] ?? MMDBoneAnimation()
                    animation.rotation = localRotation
                    working[linkIndex] = animation
                    pose = solveFK(animations: working, model: model)
                    moved = true
                }
                if !moved { break }
            }
        }
        return pose
    }

    private func solveFK(animations: [Int: MMDBoneAnimation], model: PMXModel) -> MMDSkeletonPose {
        var worlds = [simd_float4x4](repeating: matrix_identity_float4x4, count: boneCount)
        for index in order {
            let bone = model.bones[index]
            let animation = animations[index] ?? MMDBoneAnimation()
            var localTranslation = restLocal[index] + animation.position
            var localRotation = animation.rotation

            if bone.appendParent >= 0 && bone.appendParent < boneCount && abs(bone.appendRatio) > 0.0001 {
                let append = animations[bone.appendParent] ?? MMDBoneAnimation()
                let ratio = bone.appendRatio
                let extraRotation = quatSlerp(mmdIdentityQuaternion, append.rotation, ratio)
                localRotation = localRotation * extraRotation
                if bone.inheritsTranslation {
                    localTranslation += append.position * ratio
                }
            }

            let local = simd_float4x4.translation(localTranslation) * simd_float4x4(quaternion: localRotation)
            let parent = parentIndices[index]
            worlds[index] = (parent >= 0 ? worlds[parent] : matrix_identity_float4x4) * local
        }

        var palettes = [simd_float4x4](repeating: matrix_identity_float4x4, count: boneCount)
        for index in 0..<boneCount {
            palettes[index] = worlds[index] * inverseBind[index]
        }
        return MMDSkeletonPose(worldMatrices: worlds, palettes: palettes)
    }

    func boneWorldPositions(_ pose: MMDSkeletonPose) -> [SIMD3<Float>] {
        pose.worldMatrices.map { $0.translation }
    }
}

/// Combines UI morph weights and VMD morph tracks.
final class MMDMorphController {

    static func resolvedWeights(model: PMXModel, base: [Float]) -> [Float] {
        guard !model.morphs.isEmpty else { return base }
        var weights = base.count == model.morphs.count ? base : [Float](repeating: 0, count: model.morphs.count)
        // Propagate group morphs a few levels down; PMX groups are normally shallow.
        for _ in 0..<3 {
            var additions = [Float](repeating: 0, count: model.morphs.count)
            for (index, morph) in model.morphs.enumerated() where morph.isGroup && abs(weights[index]) > 0.0001 {
                for item in morph.groupItems {
                    guard item.morphIndex >= 0 && item.morphIndex < additions.count else { continue }
                    additions[item.morphIndex] += weights[index] * item.ratio
                }
            }
            var changed = false
            for index in weights.indices where abs(additions[index]) > 0.00001 {
                weights[index] += additions[index]
                changed = true
            }
            if !changed { break }
        }
        return weights
    }

    static func positions(model: PMXModel, weights: [Float]) -> [SIMD3<Float>] {
        let base = model.vertices.map { $0.position }
        guard !model.morphs.isEmpty, weights.count == model.morphs.count else { return base }
        var result = base
        for (morphIndex, morph) in model.morphs.enumerated() {
            let weight = weights[morphIndex]
            guard morph.isVertex && abs(weight) > 0.00001 else { continue }
            for offset in morph.vertexOffsets {
                guard offset.vertexIndex >= 0 && offset.vertexIndex < result.count else { continue }
                result[offset.vertexIndex] += offset.offset * weight
            }
        }
        return result
    }
}

// MARK: - Humanoid rig mapping

enum MMDHumanoidJoint: String, CaseIterable, Identifiable, Hashable {
    case center
    case lowerBody
    case upperBody
    case upperBody2
    case neck
    case head
    case leftShoulder
    case rightShoulder
    case leftUpperArm
    case rightUpperArm
    case leftForearm
    case rightForearm
    case leftHand
    case rightHand
    case leftThigh
    case rightThigh
    case leftShin
    case rightShin
    case leftFoot
    case rightFoot

    var id: String { rawValue }

    var label: String {
        switch self {
        case .center: return "中心"
        case .lowerBody: return "下半身"
        case .upperBody: return "上半身"
        case .upperBody2: return "上半身2"
        case .neck: return "首"
        case .head: return "头"
        case .leftShoulder: return "左肩"
        case .rightShoulder: return "右肩"
        case .leftUpperArm: return "左腕"
        case .rightUpperArm: return "右腕"
        case .leftForearm: return "左肘"
        case .rightForearm: return "右肘"
        case .leftHand: return "左手"
        case .rightHand: return "右手"
        case .leftThigh: return "左腿"
        case .rightThigh: return "右腿"
        case .leftShin: return "左膝"
        case .rightShin: return "右膝"
        case .leftFoot: return "左足"
        case .rightFoot: return "右足"
        }
    }

    var aliases: [String] {
        switch self {
        case .center:
            return ["センター", "center", "centre", "pelvis", "hips", "hip", "root", "waist", "腰", "中心"]
        case .lowerBody:
            return ["下半身", "lowerbody", "lower_body", "hips", "pelvis", "骨盤", "腰下"]
        case .upperBody:
            return ["上半身", "spine", "chest", "upperbody", "upper_body", "torso", "abdomen", "背", "胸"]
        case .upperBody2:
            return ["上半身2", "upperchest", "upper_chest", "chest2", "spine2", "spine1", "胸2"]
        case .neck:
            return ["首", "neck", "脖子", "颈"]
        case .head:
            return ["頭", "head", "头", "头部"]
        case .leftShoulder:
            return ["左肩", "leftshoulder", "left_shoulder", "clavicle_l", "clavicleleft",
                    "shoulder_l", "shoulderleft", "lclavicle", "l_clavicle", "左锁骨", "左锁"]
        case .rightShoulder:
            return ["右肩", "rightshoulder", "right_shoulder", "clavicle_r", "clavicleright",
                    "shoulder_r", "shoulderright", "rclavicle", "r_clavicle", "右锁骨", "右锁"]
        case .leftUpperArm:
            return ["左腕", "左上臂", "左上腕", "左大臂", "leftupperarm", "left_upper_arm",
                    "upperarm_l", "upperarmleft", "arm_l", "armleft", "leftarm",
                    "lupperarm", "l_upperarm", "larm"]
        case .rightUpperArm:
            return ["右腕", "右上臂", "右上腕", "右大臂", "rightupperarm", "right_upper_arm",
                    "upperarm_r", "upperarmright", "arm_r", "armright", "rightarm",
                    "rupperarm", "r_upperarm", "rarm"]
        case .leftForearm:
            return ["左ひじ", "左肘", "左小臂", "左前臂", "leftforearm", "left_forearm",
                    "forearm_l", "forearmleft", "elbow_l", "elbowleft", "lforearm",
                    "l_forearm", "lowerarmleft", "larmlower"]
        case .rightForearm:
            return ["右ひじ", "右肘", "右小臂", "右前臂", "rightforearm", "right_forearm",
                    "forearm_r", "forearmright", "elbow_r", "elbowright", "rforearm",
                    "r_forearm", "lowerarmright", "rarmlower"]
        case .leftHand:
            return ["左手首", "左手", "左腕关节", "left hand", "left_hand", "hand_l", "handleft",
                    "wrist_l", "wristleft", "lhand", "l_hand"]
        case .rightHand:
            return ["右手首", "右手", "右腕关节", "right hand", "right_hand", "hand_r", "handright",
                    "wrist_r", "wristright", "rhand", "r_hand"]
        case .leftThigh:
            return ["左足", "左大腿", "左腿", "leftthigh", "left_thigh", "thigh_l",
                    "thighleft", "upperleg_l", "upperlegleft", "leg_l", "legleft",
                    "lthigh", "l_thigh", "lleg"]
        case .rightThigh:
            return ["右足", "右大腿", "右腿", "rightthigh", "right_thigh", "thigh_r",
                    "thighright", "upperleg_r", "upperlegright", "leg_r", "legright",
                    "rthigh", "r_thigh", "rleg"]
        case .leftShin:
            return ["左ひざ", "左膝", "左小腿", "leftshin", "left_shin", "shin_l",
                    "shinleft", "knee_l", "kneeleft", "calf_l", "calfleft",
                    "lshin", "lcalf", "l_calf", "lowerlegleft"]
        case .rightShin:
            return ["右ひざ", "右膝", "右小腿", "rightshin", "right_shin", "shin_r",
                    "shinright", "knee_r", "kneeright", "calf_r", "calfright",
                    "rshin", "rcalf", "r_calf", "lowerlegright"]
        case .leftFoot:
            return ["左足首", "左脚", "左足踝", "leftfoot", "left_foot", "foot_l",
                    "footleft", "ankle_l", "ankleleft", "lfoot", "l_foot"]
        case .rightFoot:
            return ["右足首", "右脚", "右足踝", "rightfoot", "right_foot", "foot_r",
                    "footright", "ankle_r", "ankleright", "rfoot", "r_foot"]
        }
    }

    static func matching(trackName: String) -> MMDHumanoidJoint? {
        let key = MMDModelDocument.normalizedBoneName(trackName)
        guard !key.isEmpty else { return nil }
        for joint in allCases {
            if joint.aliases.map(MMDModelDocument.normalizedBoneName).contains(key) {
                return joint
            }
        }
        return nil
    }

    /// Conservative local-Euler limits (degrees). X is the main bend axis for
    /// elbows/knees; the other axes are kept narrow to prevent twist.
    var rotationLimit: (x: (Float, Float), y: (Float, Float), z: (Float, Float)) {
        switch self {
        case .leftForearm, .rightForearm, .leftShin, .rightShin:
            return ((-165, 10), (-40, 40), (-30, 30))
        case .leftThigh, .rightThigh:
            return ((-125, 60), (-50, 50), (-45, 45))
        case .neck:
            return ((-45, 45), (-60, 60), (-35, 35))
        case .head:
            return ((-55, 55), (-70, 70), (-45, 45))
        case .leftShoulder, .rightShoulder:
            return ((-80, 80), (-45, 45), (-80, 80))
        case .leftUpperArm, .rightUpperArm:
            return ((-150, 150), (-90, 90), (-120, 120))
        case .leftHand, .rightHand, .leftFoot, .rightFoot:
            return ((-90, 90), (-60, 60), (-60, 60))
        case .center, .lowerBody, .upperBody, .upperBody2:
            return ((-60, 60), (-60, 60), (-60, 60))
        }
    }

    func constrained(_ degrees: SIMD3<Float>) -> SIMD3<Float> {
        let limit = rotationLimit
        return SIMD3<Float>(
            max(limit.x.0, min(limit.x.1, degrees.x)),
            max(limit.y.0, min(limit.y.1, degrees.y)),
            max(limit.z.0, min(limit.z.1, degrees.z))
        )
    }
}

enum MMDPosePreset: String, CaseIterable, Identifiable {
    case neutral = "自然站姿"
    case aPose = "A-Pose"
    case tPose = "T-Pose"
    case wave = "右手招手"
    case sit = "坐姿"

    var id: String { rawValue }
}

/// Real-time secondary-motion and PMX rigid-body solver.
///
/// The chain solver drives skirt/ribbon/hair/wing bones with inertia, gravity,
/// damping and wind. PMX dynamic rigid bodies (mode 2) are integrated as
/// spheres/boxes with joint springs, floor contact and body-body collision;
/// their motion is fed back into the bound bones. This is a compact Bullet-like
/// approximation, not a bit-exact port of Bullet's constraint solver.
struct MMDPhysicsSettings {
    var enabled: Bool = true
    var gravity: Float = 0.55
    var stiffness: Float = 0.45
    var damping: Float = 0.72
    var wind: Float = 0.18
    var inertia: Float = 0.85
    var collision: Bool = true
    var maxAngle: Float = 55
    var substeps: Int = 2
}

final class MMDSpringPhysics {

    private struct ChainBone {
        var index: Int
        var parent: Int
        var depth: Int
        var maxAngle: Float
        var phase: Float
    }

    private struct RigidState {
        var body: PMXRigidBody
        var position: SIMD3<Float>
        var restPosition: SIMD3<Float>
        var rotation: simd_quatf
        var restRotation: simd_quatf
        var velocity: SIMD3<Float> = .zero
        var angularVelocity: SIMD3<Float> = .zero
    }

    private struct JointLink {
        var type: UInt8
        var a: Int
        var b: Int
        var offset: SIMD3<Float>
        var spring: SIMD3<Float>
        var springRotation: SIMD3<Float>
    }

    private var offsets: [Int: SIMD3<Float>] = [:]
    private var velocities: [Int: SIMD3<Float>] = [:]
    private var chainBones: [ChainBone] = []
    private var rigidStates: [RigidState] = []
    private var rigidStateByBody: [Int: Int] = [:]
    private var joints: [JointLink] = []
    private var lastTime: CFTimeInterval = 0
    private var lastBodyRotation: simd_quatf = mmdIdentityQuaternion
    private var rigidBoneIndices: Set<Int> = []
    private(set) var solvedRigidBodyCount = 0
    private(set) var solvedJointCount = 0

    private let keywords = ["髪", "hair", "skirt", "スカート", "ribbon", "リボン",
                            "tail", "尾", "cape", "マント", "袖", "sleeve", "breast", "胸",
                            "wing", "羽", "翼", "frill", "フリル", "cloth", "裾", "垂"]

    func reset() {
        offsets.removeAll()
        velocities.removeAll()
        lastTime = 0
        lastBodyRotation = mmdIdentityQuaternion
        for index in rigidStates.indices {
            rigidStates[index].position = rigidStates[index].restPosition
            rigidStates[index].rotation = rigidStates[index].restRotation
            rigidStates[index].velocity = .zero
            rigidStates[index].angularVelocity = .zero
        }
    }

    func prepare(model: PMXModel) {
        chainBones.removeAll()
        offsets.removeAll()
        velocities.removeAll()
        rigidStates.removeAll()
        rigidStateByBody.removeAll()
        joints.removeAll()
        rigidBoneIndices.removeAll()

        var byName = [String: Int]()
        for (index, bone) in model.bones.enumerated() {
            byName[bone.name] = index
            if !bone.nameEn.isEmpty { byName[bone.nameEn] = index }
        }

        var secondary = Set<Int>()
        for (index, bone) in model.bones.enumerated() {
            let lower = bone.name.lowercased() + " " + bone.nameEn.lowercased()
            guard keywords.contains(where: { lower.contains($0) }) else { continue }
            secondary.insert(index)
        }
        // Some rigs only name the chain root ("skirt_master") and leave child
        // bones generic. Walk upward from every bone and include a chain when
        // its parent is a known secondary root.
        for (index, bone) in model.bones.enumerated() {
            var cursor = bone.parentIndex
            var guardCount = 0
            while cursor >= 0 && cursor < model.bones.count && guardCount < 8 {
                if secondary.contains(cursor) {
                    secondary.insert(index)
                    break
                }
                cursor = model.bones[cursor].parentIndex
                guardCount += 1
            }
        }

        for index in secondary.sorted() {
            guard index >= 0 && index < model.bones.count else { continue }
            let bone = model.bones[index]
            let lower = bone.name.lowercased() + " " + bone.nameEn.lowercased()
            var maxAngle: Float = 38
            if lower.contains("wing") || lower.contains("羽") || lower.contains("翼") { maxAngle = 52 }
            else if lower.contains("ribbon") || lower.contains("リボン") || lower.contains("尾") { maxAngle = 48 }
            else if lower.contains("skirt") || lower.contains("スカート") || lower.contains("裾") { maxAngle = 32 }
            else if lower.contains("hair") || lower.contains("髪") { maxAngle = 26 }
            else if lower.contains("sleeve") || lower.contains("袖") { maxAngle = 34 }
            var depth = 0
            var cursor = bone.parentIndex
            while cursor >= 0 && cursor < model.bones.count && depth < 12 {
                depth += 1
                cursor = model.bones[cursor].parentIndex
            }
            chainBones.append(ChainBone(index: index, parent: bone.parentIndex,
                                        depth: depth,
                                        maxAngle: maxAngle,
                                        phase: Float(index % 11) * 0.37))
        }

        // Build rigid-body state. Static/kinematic bodies are anchors only.
        for (bodyIndex, body) in model.rigidBodies.enumerated() where body.mode >= 2 && body.boneIndex >= 0 {
            let restRotation = quatFromEuler(SIMD3<Float>(mmdRadians(body.rotation.x),
                                                          mmdRadians(body.rotation.y),
                                                          mmdRadians(body.rotation.z)))
            rigidStateByBody[bodyIndex] = rigidStates.count
            rigidStates.append(RigidState(body: body, position: body.position,
                                          restPosition: body.position,
                                          rotation: restRotation,
                                          restRotation: restRotation))
            rigidBoneIndices.insert(body.boneIndex)
        }
        // Limit the O(n²) collision pass on very heavy models while retaining
        // the bodies closest to the hips/legs and hair.
        if rigidStates.count > 96 {
            rigidStates = Array(rigidStates.prefix(96))
            rigidBoneIndices = Set(rigidStates.map { $0.body.boneIndex })
        }
        for joint in model.joints {
            guard joint.bodyA >= 0, joint.bodyB >= 0,
                  joint.bodyA < model.rigidBodies.count,
                  joint.bodyB < model.rigidBodies.count else { continue }
            let a = model.rigidBodies[joint.bodyA].position
            let b = model.rigidBodies[joint.bodyB].position
            joints.append(JointLink(type: joint.type, a: joint.bodyA, b: joint.bodyB,
                                    offset: a - b,
                                    spring: joint.springPosition,
                                    springRotation: joint.springRotation))
        }
        solvedRigidBodyCount = rigidStates.count
        solvedJointCount = joints.count
        reset()
    }

    func apply(animations: [Int: MMDBoneAnimation], model: PMXModel,
               settings: MMDPhysicsSettings, time: CFTimeInterval,
               forcedStep: Float? = nil,
               driveRotation: simd_quatf? = nil) -> [Int: MMDBoneAnimation] {
        guard settings.enabled else { return animations }
        if forcedStep == nil && time < lastTime { reset() }
        let dt: Float
        if let forcedStep {
            dt = max(0.001, min(0.05, forcedStep))
        } else {
            if lastTime == 0 {
                lastTime = time
                return animations
            }
            guard time > lastTime + 0.00001 else {
                return animations
            }
            dt = Float(min(0.05, max(0.001, time - lastTime)))
        }
        lastTime = max(lastTime, time)

        let centerIndex = model.bones.firstIndex {
            $0.name == "センター" || $0.name.lowercased().contains("center")
        }
        let bodyRotation = driveRotation
            ?? centerIndex.flatMap { animations[$0]?.rotation }
            ?? mmdIdentityQuaternion
        let delta = bodyRotation * lastBodyRotation.inverse
        let bodyDelta = quatEulerDegrees(delta)
        lastBodyRotation = bodyRotation

        var result = animations
        let gravity = max(0, settings.gravity)
        let stiffness = max(0.02, settings.stiffness)
        let damping = max(0.02, settings.damping)
        let wind = max(0, settings.wind)
        let inertia = max(0, settings.inertia)

        for node in chainBones {
            let index = node.index
            guard !rigidBoneIndices.contains(index) else { continue }
            let sway = sinf(Float(time) * (1.1 + wind * 1.5) + node.phase)
            var offset = offsets[index] ?? .zero
            var velocity = velocities[index] ?? .zero
            var force = SIMD3<Float>(
                -gravity * 2.2 + sway * wind * 8.0,
                bodyDelta.y * 0.10 * inertia,
                -bodyDelta.x * 0.14 * inertia + cosf(Float(time) * 1.7 + node.phase) * wind * 6.0
            )
            // Upper chain links inherit part of the parent's angular velocity,
            // producing the classic skirt/ribbon follow-through.
            if node.parent >= 0, let parentOffset = offsets[node.parent] {
                force += (parentOffset - offset) * (0.10 + Float(node.depth) * 0.012) * stiffness
            }
            force += -stiffness * offset - damping * velocity
            velocity += force * (dt * 60)
            offset += velocity * dt * 60
            let limit = min(settings.maxAngle, node.maxAngle)
            offset.x = max(-limit, min(limit, offset.x))
            offset.y = max(-limit * 0.6, min(limit * 0.6, offset.y))
            offset.z = max(-limit, min(limit, offset.z))
            offsets[index] = offset
            velocities[index] = velocity

            var animation = result[index] ?? MMDBoneAnimation()
            let offsetRotation = quatFromEuler(SIMD3<Float>(
                mmdRadians(offset.x), mmdRadians(offset.y), mmdRadians(offset.z)))
            animation.rotation = animation.rotation * offsetRotation
            result[index] = animation
        }

        if settings.enabled && !rigidStates.isEmpty {
            stepRigidBodies(model: model, settings: settings, dt: dt)
            applyRigidBodies(to: &result, model: model)
        }
        return result
    }

    // MARK: - Rigid bodies

    private func stepRigidBodies(model: PMXModel, settings: MMDPhysicsSettings, dt: Float) {
        let substeps = max(1, min(4, settings.substeps))
        let subDt = dt / Float(substeps)
        let gravity = SIMD3<Float>(0, -max(0, settings.gravity) * 9.8, 0)
        let floorY = model.bounds.minPoint.y

        for _ in 0..<substeps {
            for index in rigidStates.indices {
                var state = rigidStates[index]
                let mass = max(0.001, state.body.mass)
                var force = gravity * mass
                // Damped angular inertia from body rotation.
                force.x -= state.velocity.x * state.body.linearDamping * mass * 18
                force.y -= state.velocity.y * state.body.linearDamping * mass * 18
                force.z -= state.velocity.z * state.body.linearDamping * mass * 18

                // Joint springs pull dynamic bodies toward their anchored rest
                // offset. Bodies not referenced by joints keep their shape.
                for joint in joints {
                    guard joint.a < model.rigidBodies.count, joint.b < model.rigidBodies.count else { continue }
                    let isA = rigidStateByBody[joint.a] == index
                    let isB = rigidStateByBody[joint.b] == index
                    guard isA || isB else { continue }
                    let otherIndex = isA ? joint.b : joint.a
                    let otherPosition = model.rigidBodies[otherIndex].position
                    let anchor = otherPosition + (isA ? joint.offset : -joint.offset)
                    let stiffnessVector = SIMD3<Float>(abs(joint.spring.x), abs(joint.spring.y), abs(joint.spring.z))
                    let strength = 18.0 / (1.0 + stiffnessVector.x + stiffnessVector.y + stiffnessVector.z)
                    let delta = anchor - state.position
                    force += delta * strength * mass
                    let angularThis = state.angularVelocity
                    let springRot = (abs(joint.springRotation.x) + abs(joint.springRotation.y) + abs(joint.springRotation.z)) / 3
                    state.angularVelocity -= angularThis * min(0.95, 0.06 + springRot * 0.02)
                }

                state.velocity += force / mass * subDt
                let speed = simd_length(state.velocity)
                if speed > 8 { state.velocity *= 8 / speed }
                state.position += state.velocity * subDt
                let angularSpeed = simd_length(state.angularVelocity)
                if angularSpeed > 0.0001 {
                    let step = min(0.35, angularSpeed * subDt)
                    state.rotation = simd_quatf(angle: step,
                                                axis: state.angularVelocity / angularSpeed) * state.rotation
                }
                let angularDamping = max(0.0, min(1.0, state.body.angularDamping))
                state.angularVelocity *= max(0, 1 - angularDamping * subDt * 60 * 0.35)
                state.velocity *= max(0, 1 - state.body.linearDamping * subDt * 60 * 0.20)

                if settings.collision {
                    let radius = max(state.body.size.x, max(state.body.size.y, state.body.size.z))
                    if state.position.y - radius < floorY {
                        state.position.y = floorY + radius
                        if state.velocity.y < 0 {
                            state.velocity.y = -state.velocity.y * max(0, min(0.9, state.body.restitution))
                        }
                    }
                }
                rigidStates[index] = state
            }

            if settings.collision {
                for i in rigidStates.indices {
                    for j in (i + 1)..<rigidStates.count {
                        let a = rigidStates[i]
                        let b = rigidStates[j]
                        if a.body.group == b.body.group { continue }
                        let ra = max(a.body.size.x, max(a.body.size.y, a.body.size.z))
                        let rb = max(b.body.size.x, max(b.body.size.y, b.body.size.z))
                        let delta = b.position - a.position
                        let distance = simd_length(delta)
                        let minimum = ra + rb
                        guard distance < minimum, distance > 0.0001 else { continue }
                        let normal = delta / distance
                        let penetration = minimum - distance
                        rigidStates[i].position -= normal * penetration * 0.5
                        rigidStates[j].position += normal * penetration * 0.5
                        let relative = simd_dot(rigidStates[j].velocity - rigidStates[i].velocity, normal)
                        if relative < 0 {
                            let impulse = normal * (-relative * 0.5)
                            rigidStates[i].velocity -= impulse
                            rigidStates[j].velocity += impulse
                        }
                    }
                }
            }
        }
    }

    private func applyRigidBodies(to animations: inout [Int: MMDBoneAnimation], model: PMXModel) {
        var applied: Set<Int> = []
        for state in rigidStates {
            let boneIndex = state.body.boneIndex
            guard boneIndex >= 0 && boneIndex < model.bones.count,
                  applied.insert(boneIndex).inserted else { continue }
            var deltaPosition = state.position - state.restPosition
            let length = simd_length(deltaPosition)
            if length > 1.2 { deltaPosition *= 1.2 / length }
            let deltaRotation = state.rotation * state.restRotation.inverse
            var animation = animations[boneIndex] ?? MMDBoneAnimation()
            let parent = model.bones[boneIndex].parentIndex
            let parentRotation = parent >= 0 ? (animations[parent]?.rotation ?? mmdIdentityQuaternion)
                                             : mmdIdentityQuaternion
            animation.position += parentRotation.inverse.act(deltaPosition)
            let localRotation = parentRotation.inverse * deltaRotation * parentRotation
            animation.rotation = animation.rotation * localRotation
            animations[boneIndex] = animation
        }
    }
}


/// MMD's IK "unit angle" is a multiplier on the alignment step. Clamp it to a
/// sane range so a malformed PMX cannot make one iteration jump 180 degrees.
func class_half_clamp(_ value: Float) -> Float {
    max(0.02, min(1.0, value))
}
