import AVFoundation
import Combine
import Foundation
import MediaPipeTasksVision
import simd

/// Video-to-VMD conversion using MediaPipe BlazePose (Apache-2.0), running
/// fully on device. MediaPipe produces 33 stable body landmarks and a metric
/// 3D world pose; the latter is used for the torso lean while the normalized
/// landmarks drive the limb angles. This replaces the earlier Apple Vision
/// 2D-only implementation that produced unstable joint angles.
final class MMDVideoMotionExtractor {

    struct Result {
        let url: URL?
        let motion: VMDMotion
        let sampledFrames: Int
        let detectedFrames: Int
        let boneCount: Int
        let duration: Float
        let mappedJoints: [MMDHumanoidJoint]
        let firstPoseTime: Float
        let lastPoseTime: Float
        let videoDuration: Float
    }

    enum ExtractError: LocalizedError {
        case noVideoTrack
        case cannotRead
        case noPose
        case modelMissing
        case writeFailed
        case noMappedBones

        var errorDescription: String? {
            switch self {
            case .noVideoTrack: return "视频中没有可读取的画面轨道。"
            case .cannotRead: return "无法读取视频，请换一个 MP4/MOV 文件。"
            case .noPose: return "视频中没有检测到完整人体姿态。请使用正面、全身、光线充足的舞蹈视频。"
            case .modelMissing: return "找不到内置的 MediaPipe 姿态模型。"
            case .writeFailed: return "无法写入 VMD 文件。"
            case .noMappedBones: return "模型没有可匹配的人体骨骼。请先在骨骼面板执行自动绑定。"
            }
        }
    }

    private struct BoneKey {
        var frame: Int
        var position: SIMD3<Float> = .zero
        var rotation: simd_quatf
    }

    private var tracks: [String: [BoneKey]] = [:]
    private var smoothedRotations: [String: simd_quatf] = [:]
    private var smoothedPositions: [String: SIMD3<Float>] = [:]
    private var bodyHeight: Float = 0
    private var maxFrame = 0
    private var videoAspect: Float = 1
    private var boneNames: [MMDHumanoidJoint: String] = [:]
    private var mappedJoints: Set<MMDHumanoidJoint> = []
    private var lastLandmarkTimestamp = 0
    private var worldPoseCount = 0

    func extract(from videoURL: URL,
                 modelURL: URL? = nil,
                 boneNames: [MMDHumanoidJoint: String] = [:],
                 bodyHeight: Float = 0,
                 progress: @escaping (Double) -> Void,
                 completion: @escaping (Swift.Result<Result, Error>) -> Void) {
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                let result = try self.run(videoURL: videoURL, modelURL: modelURL,
                                          boneNames: boneNames, bodyHeight: bodyHeight,
                                          progress: progress)
                DispatchQueue.main.async { completion(.success(result)) }
            } catch {
                MMDLog.shared.error("Video motion extraction failed: \(error.localizedDescription)",
                                    category: "VideoMotion")
                DispatchQueue.main.async { completion(.failure(error)) }
            }
        }
    }

    private func run(videoURL: URL, modelURL: URL?,
                     boneNames: [MMDHumanoidJoint: String],
                     bodyHeight: Float,
                     progress: @escaping (Double) -> Void) throws -> Result {
        let modelPath: String
        if let modelURL, FileManager.default.fileExists(atPath: modelURL.path) {
            modelPath = modelURL.path
        } else if let bundled = Bundle.main.path(forResource: "pose_landmarker_lite", ofType: "task") {
            modelPath = bundled
        } else {
            throw ExtractError.modelMissing
        }
        let asset = AVURLAsset(url: videoURL)
        guard let assetTrack = asset.tracks(withMediaType: .video).first else {
            throw ExtractError.noVideoTrack
        }
        let assetSeconds = CMTimeGetSeconds(asset.duration)
        let trackSeconds = CMTimeGetSeconds(assetTrack.timeRange.duration)
        let metadataDuration: Double
        if trackSeconds.isFinite && trackSeconds > 0.1 {
            metadataDuration = trackSeconds
        } else {
            metadataDuration = assetSeconds.isFinite && assetSeconds > 0.1 ? assetSeconds : 0
        }
        let duration = max(0.1, metadataDuration)
        let reader = try AVAssetReader(asset: asset)
        let pixelSettings: [String: Any] = [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA
        ]

        // AVAssetReaderTrackOutput ignores the track's preferredTransform.
        // ReplayKit/portrait phone videos often carry a 90° transform, which
        // made MediaPipe see a sideways dancer and produced a 90° VMD root
        // rotation. Render through a one-layer video composition so the
        // landmarker receives an upright image.
        let naturalSize = assetTrack.naturalSize
        let preferred = assetTrack.preferredTransform
        let transformedRect = CGRect(origin: .zero, size: naturalSize).applying(preferred)
        let renderSize = CGSize(width: max(1, abs(transformedRect.width)),
                                height: max(1, abs(transformedRect.height)))
        let composition = AVMutableVideoComposition()
        composition.renderSize = renderSize
        composition.frameDuration = CMTime(value: 1, timescale: 30)
        let instruction = AVMutableVideoCompositionInstruction()
        instruction.timeRange = CMTimeRange(start: .zero, duration: asset.duration)
        let layer = AVMutableVideoCompositionLayerInstruction(assetTrack: assetTrack)
        layer.setTransform(preferred, at: .zero)
        instruction.layerInstructions = [layer]
        composition.instructions = [instruction]

        let compositionOutput = AVAssetReaderVideoCompositionOutput(videoTracks: [assetTrack],
                                                                   videoSettings: pixelSettings)
        compositionOutput.videoComposition = composition
        compositionOutput.alwaysCopiesSampleData = false

        let nextSample: () -> CMSampleBuffer?
        if reader.canAdd(compositionOutput) {
            reader.add(compositionOutput)
            nextSample = { compositionOutput.copyNextSampleBuffer() }
        } else {
            let trackOutput = AVAssetReaderTrackOutput(track: assetTrack, outputSettings: pixelSettings)
            trackOutput.alwaysCopiesSampleData = false
            guard reader.canAdd(trackOutput) else { throw ExtractError.cannotRead }
            reader.add(trackOutput)
            nextSample = { trackOutput.copyNextSampleBuffer() }
        }
        guard reader.startReading() else { throw ExtractError.cannotRead }

        let options = PoseLandmarkerOptions()
        options.baseOptions.modelAssetPath = modelPath
        options.runningMode = .video
        options.numPoses = 1
        options.minPoseDetectionConfidence = 0.35
        options.minPosePresenceConfidence = 0.35
        options.minTrackingConfidence = 0.35
        let landmarker = try PoseLandmarker(options: options)

        videoAspect = Float(max(0.2, renderSize.width / max(1, renderSize.height)))
        let sampleInterval = 1.0 / 30.0
        var firstSampleTime: Double?
        var nextSampleTime = 0.0
        var observedDuration = 0.1
        var sampled = 0
        var detected = 0
        var firstPoseTime: Double?
        var lastPoseTime: Double?

        tracks.removeAll()
        smoothedRotations.removeAll()
        self.boneNames = boneNames
        self.bodyHeight = max(0, bodyHeight)
        smoothedPositions.removeAll()
        mappedJoints.removeAll()
        maxFrame = 0
        lastLandmarkTimestamp = 0
        worldPoseCount = 0
        MMDLog.shared.info("Video motion start: duration=\(String(format: "%.2f", duration))s, " +
                           "render=\(Int(renderSize.width))x\(Int(renderSize.height)), " +
                           "mappedJoints=\(boneNames.count)", category: "VideoMotion")
        let boneMapDescription = MMDHumanoidJoint.allCases.compactMap { joint -> String? in
            guard let name = boneNames[joint] else { return nil }
            return "\(joint.rawValue)=\(name)"
        }.joined(separator: ", ")
        MMDLog.shared.info("Video motion bone map: \(boneMapDescription)", category: "VideoMotion")

        var detectionFailures = 0
        while reader.status == .reading, let sample = nextSample() {
            let rawTime = CMTimeGetSeconds(CMSampleBufferGetPresentationTimeStamp(sample))
            if firstSampleTime == nil { firstSampleTime = rawTime }
            // Reader outputs can carry a non-zero or absolute start timestamp
            // (common for ReplayKit and edited clips). Normalize against the
            // first sample, then clip to the asset duration; otherwise every
            // generated key can land near the frame cap and the character
            // appears frozen while the timeline becomes absurdly long.
            let normalized = max(0, rawTime - (firstSampleTime ?? rawTime))
            // Some asset-reader pipelines omit presentation timestamps. Fall
            // back to the sampled frame index so the motion still has a
            // monotonic timeline instead of collapsing every key onto frame 0.
            let time = normalized > 0.0001
                ? min(metadataDuration > 0.1 ? metadataDuration : 3600.0, normalized)
                : Double(sampled) / 30.0
            // Track the end of the stream even when this frame is skipped by
            // the 30 Hz sampler; otherwise a long video can be reported as a
            // two-second action and the timeline looks truncated.
            observedDuration = max(observedDuration, time)
            guard time >= nextSampleTime else { continue }
            nextSampleTime = max(nextSampleTime + sampleInterval, time + sampleInterval)
            guard let pixelBuffer = CMSampleBufferGetImageBuffer(sample) else { continue }
            sampled += 1
            guard let image = try? MPImage(pixelBuffer: pixelBuffer) else { continue }
            lastLandmarkTimestamp = max(lastLandmarkTimestamp + 1, Int(time * 1000))
            do {
                let result = try landmarker.detect(videoFrame: image,
                                                   timestampInMilliseconds: lastLandmarkTimestamp)
                guard let landmarks = result.landmarks.first, landmarks.count >= 33 else { continue }
                // A dance clip longer than one hour is outside the app's
                // intended use; clamping also protects the timeline from
                // malformed CMTime values.
                let keyFrame = min(108_000, max(0, Int((time * 30.0).rounded())))
                maxFrame = max(maxFrame, keyFrame)
                let world = result.worldLandmarks.first
                if world != nil { worldPoseCount += 1 }
                if addPose(landmarks: landmarks, worldLandmarks: world, frame: keyFrame) {
                    detected += 1
                    if firstPoseTime == nil { firstPoseTime = time }
                    lastPoseTime = time
                }
                progress(min(0.98, time / duration))
            } catch {
                detectionFailures += 1
                if detectionFailures == 1 {
                    MMDLog.shared.warning("MediaPipe detect failed: \(error.localizedDescription)",
                                          category: "VideoMotion")
                }
                continue
            }
        }

        if reader.status == .failed {
            MMDLog.shared.error("AVAssetReader failed: \(reader.error?.localizedDescription ?? "unknown")",
                                category: "VideoMotion")
            throw ExtractError.cannotRead
        }
        guard detected > 0, !tracks.isEmpty else { throw ExtractError.noPose }
        // The action timeline must be the full video duration, not the last
        // successfully detected frame. A dancer leaving the frame or a long
        // camera pan should not silently shorten the VMD to a few seconds.
        let outputDuration = max(0.1, max(observedDuration, metadataDuration))
        maxFrame = min(108_000, max(maxFrame, Int(ceil(outputDuration * 30.0))))
        let coverageStart = firstPoseTime ?? 0
        let coverageEnd = lastPoseTime ?? 0
        MMDLog.shared.info("Video motion coverage: first=\(String(format: "%.2f", coverageStart))s, " +
                           "last=\(String(format: "%.2f", coverageEnd))s, " +
                           "video=\(String(format: "%.2f", outputDuration))s, " +
                           "worldLandmarks=\(worldPoseCount)", category: "VideoMotion")
        if coverageEnd + 0.35 < outputDuration {
            MMDLog.shared.warning("Pose detection ended \(String(format: "%.2f", outputDuration - coverageEnd))s before the video ended; the last pose will hold for that tail.",
                                  category: "VideoMotion")
        }

        let finalMotion = buildMotion()
        guard !finalMotion.boneTracks.isEmpty else { throw ExtractError.noMappedBones }

        // The in-memory motion is authoritative. The VMD copy is only an
        // export/debug artifact; a write failure must not discard a valid
        // action that can already drive the skeleton.
        var exportURL: URL?
        do {
            let candidate = try outputURL(for: videoURL, modelURL: modelURL)
            try writeVMD(finalMotion, to: candidate)
            exportURL = candidate
        } catch {
            MMDLog.shared.warning("VMD export failed (in-memory motion kept): \(error.localizedDescription)",
                                  category: "VideoMotion")
        }
        progress(1.0)
        let durationValue = Float(finalMotion.duration)
        let joints = Array(mappedJoints).sorted { $0.rawValue < $1.rawValue }
        MMDLog.shared.info("Video motion ready: samples=\(sampled), detected=\(detected), " +
                           "bones=\(finalMotion.boneTracks.count), keys=" +
                           "\(finalMotion.boneTracks.reduce(0) { $0 + $1.keys.count }), " +
                           "frames=\(maxFrame), duration=\(String(format: "%.2f", durationValue))s, " +
                           "joints=\(joints.map(\.rawValue).joined(separator: ","))",
                           category: "VideoMotion")
        return Result(url: exportURL, motion: finalMotion, sampledFrames: sampled,
                      detectedFrames: detected, boneCount: finalMotion.boneTracks.count,
                      duration: durationValue, mappedJoints: joints,
                      firstPoseTime: Float(coverageStart),
                      lastPoseTime: Float(coverageEnd),
                      videoDuration: Float(outputDuration))
    }

    /// MediaPipe BlazePose 33 landmark indices.
    private enum PoseIndex {
        static let nose = 0
        static let leftEye = 2
        static let rightEye = 5
        static let leftEar = 7
        static let rightEar = 8
        static let leftShoulder = 11
        static let rightShoulder = 12
        static let leftElbow = 13
        static let rightElbow = 14
        static let leftWrist = 15
        static let rightWrist = 16
        static let leftPinky = 17
        static let rightPinky = 18
        static let leftIndex = 19
        static let rightIndex = 20
        static let leftHip = 23
        static let rightHip = 24
        static let leftKnee = 25
        static let rightKnee = 26
        static let leftAnkle = 27
        static let rightAnkle = 28
        static let leftHeel = 29
        static let rightHeel = 30
        static let leftFootIndex = 31
        static let rightFootIndex = 32
    }

    private func addPose(landmarks: [NormalizedLandmark],
                         worldLandmarks: [Landmark]? = nil,
                         frame: Int) -> Bool {
        let aspect = videoAspect
        func point(_ index: Int) -> SIMD2<Float>? {
            guard landmarks.indices.contains(index) else { return nil }
            let value = landmarks[index]
            let confidence = value.presence?.floatValue ?? value.visibility?.floatValue ?? 1
            guard confidence >= 0.20 else { return nil }
            return SIMD2<Float>(value.x * aspect, value.y)
        }
        func angle(_ a: SIMD2<Float>, _ b: SIMD2<Float>) -> Float {
            atan2(b.y - a.y, b.x - a.x)
        }
        func delta(_ value: Float) -> Float {
            atan2(sinf(value), cosf(value))
        }
        func clamp(_ value: Float, _ low: Float, _ high: Float) -> Float {
            min(high, max(low, value))
        }
        func qz(_ radians: Float) -> simd_quatf {
            simd_quatf(angle: radians, axis: SIMD3<Float>(0, 0, 1))
        }
        func qy(_ radians: Float) -> simd_quatf {
            simd_quatf(angle: radians, axis: SIMD3<Float>(0, 1, 0))
        }
        func addTrack(_ name: String, _ rotation: simd_quatf,
                      position: SIMD3<Float> = .zero) {
            guard !name.isEmpty else { return }
            let smoothed: simd_quatf
            if let previous = smoothedRotations[name] {
                // A light low-pass removes MediaPipe's per-frame jitter while
                // preserving the timing of fast dance beats.
                smoothed = simd_slerp(previous, rotation, 0.68)
            } else {
                smoothed = rotation
            }
            smoothedRotations[name] = smoothed
            let smoothedPosition: SIMD3<Float>
            if let previous = smoothedPositions[name] {
                smoothedPosition = previous + (position - previous) * 0.62
            } else {
                smoothedPosition = position
            }
            smoothedPositions[name] = smoothedPosition
            // At 30 Hz sampling several samples can round to the same 30 fps
            // frame; replace instead of appending duplicate keys.
            if tracks[name]?.last?.frame == frame {
                tracks[name]?.removeLast()
            }
            tracks[name, default: []].append(BoneKey(frame: frame,
                                                     position: smoothedPosition,
                                                     rotation: smoothed))
        }
        func add(_ joint: MMDHumanoidJoint, _ rotation: simd_quatf?,
                 position: SIMD3<Float> = .zero) {
            guard let rotation, let name = boneNames[joint] else { return }
            mappedJoints.insert(joint)
            addTrack(name, rotation, position: position)
        }

        let nose = point(PoseIndex.nose)
        let leftEye = point(PoseIndex.leftEye)
        let rightEye = point(PoseIndex.rightEye)
        let leftEar = point(PoseIndex.leftEar)
        let rightEar = point(PoseIndex.rightEar)
        let leftShoulder = point(PoseIndex.leftShoulder)
        let rightShoulder = point(PoseIndex.rightShoulder)
        let leftElbow = point(PoseIndex.leftElbow)
        let rightElbow = point(PoseIndex.rightElbow)
        let leftWrist = point(PoseIndex.leftWrist)
        let rightWrist = point(PoseIndex.rightWrist)
        let leftIndex = point(PoseIndex.leftIndex)
        let rightIndex = point(PoseIndex.rightIndex)
        let leftHip = point(PoseIndex.leftHip)
        let rightHip = point(PoseIndex.rightHip)
        let leftKnee = point(PoseIndex.leftKnee)
        let rightKnee = point(PoseIndex.rightKnee)
        let leftAnkle = point(PoseIndex.leftAnkle)
        let rightAnkle = point(PoseIndex.rightAnkle)
        let leftFootIndex = point(PoseIndex.leftFootIndex)
        let rightFootIndex = point(PoseIndex.rightFootIndex)

        var lean: Float = 0
        if let leftShoulder, let rightShoulder, let leftHip, let rightHip {
            let shoulderCenter = (leftShoulder + rightShoulder) * 0.5
            let hipCenter = (leftHip + rightHip) * 0.5
            // Image coordinates point down. An upright shoulder line gives
            // angle(hip -> shoulder) = -π/2, so add +π/2.
            lean = angle(hipCenter, shoulderCenter) + (.pi / 2)
            lean = clamp(lean, -0.42, 0.42) // never twist the whole rig by 90°
        }

        // Root: clamped sway plus a larger lateral/vertical translation derived
        // from the hip center. The previous 5% scale barely moved the model,
        // which made full-body dance steps look like hand-only motion.
        var rootPosition = SIMD3<Float>.zero
        if bodyHeight > 0, let leftHip, let rightHip {
            let hip = (leftHip + rightHip) * 0.5
            rootPosition.x = clamp((hip.x / max(aspect, 0.2) - 0.5) * bodyHeight * 0.55,
                                   -bodyHeight * 0.22, bodyHeight * 0.22)
            rootPosition.y = clamp((0.54 - hip.y) * bodyHeight * 0.55,
                                   -bodyHeight * 0.18, bodyHeight * 0.18)
        }
        var rootRotation = qz(-lean * 0.35)
        if let leftHip, let rightHip {
            let hipRoll = clamp(atan2(rightHip.y - leftHip.y,
                                      rightHip.x - leftHip.x), -0.45, 0.45)
            rootRotation = qz(-lean * 0.35 + hipRoll * 0.18)
        }
        add(.center, rootRotation, position: rootPosition)
        add(.lowerBody, qz(lean * 0.12))
        add(.upperBody, qz(-lean * 0.30))
        add(.upperBody2, qz(-lean * 0.18))

        // Clavicles were previously left at rest. A small shoulder roll and
        // side lift gives shrugs and arm raises a real attachment motion.
        if let leftShoulder, let rightShoulder {
            let roll = clamp(atan2(rightShoulder.y - leftShoulder.y,
                                   rightShoulder.x - leftShoulder.x), -0.55, 0.55)
            add(.leftShoulder, qz(roll * 0.26))
            add(.rightShoulder, qz(-roll * 0.26))
        }

        if let leftShoulder, let rightShoulder, let nose {
            let shoulderCenter = (leftShoulder + rightShoulder) * 0.5
            let headAngle = angle(shoulderCenter, nose) + (.pi / 2)
            let headTilt = clamp(headAngle - lean, -0.55, 0.55)
            var yaw: Float = 0
            if let leftEar, let rightEar {
                let earCenter = (leftEar + rightEar) * 0.5
                let earWidth = max(simd_distance(leftEar, rightEar), 0.001)
                yaw = clamp((nose.x - earCenter.x) / earWidth, -1, 1) * 0.30
            }
            let headRotation = qz(-headTilt * 0.75) * qy(-yaw)
            add(.neck, qz(-headTilt * 0.35) * qy(-yaw * 0.45))
            add(.head, headRotation)
        } else if let leftEye, let rightEye, let nose {
            // Ear landmarks are often hidden by hair; eyes still provide a
            // usable head direction for close-up footage.
            let eyeCenter = (leftEye + rightEye) * 0.5
            let eyeWidth = max(simd_distance(leftEye, rightEye), 0.001)
            let yaw = clamp((nose.x - eyeCenter.x) / eyeWidth, -1, 1) * 0.30
            add(.head, qy(-yaw))
        }

        if let leftShoulder, let leftElbow {
            let arm = clamp(angle(leftShoulder, leftElbow) - .pi / 2 - lean * 0.25,
                            -2.4, 2.4)
            add(.leftUpperArm, qz(-arm))
        }
        if let rightShoulder, let rightElbow {
            let arm = clamp(angle(rightShoulder, rightElbow) - .pi / 2 - lean * 0.25,
                            -2.4, 2.4)
            add(.rightUpperArm, qz(-arm))
        }
        if let leftElbow, let leftWrist, let leftShoulder {
            let upper = angle(leftShoulder, leftElbow)
            let elbow = clamp(delta(angle(leftElbow, leftWrist) - upper), -2.3, 2.3)
            add(.leftForearm, qz(-elbow))
            if let leftIndex {
                let hand = clamp(delta(angle(leftWrist, leftIndex) - angle(leftElbow, leftWrist)),
                                 -1.6, 1.6)
                add(.leftHand, qz(-hand * 0.65))
            } else {
                add(.leftHand, qz(-elbow * 0.18))
            }
        }
        if let rightElbow, let rightWrist, let rightShoulder {
            let upper = angle(rightShoulder, rightElbow)
            let elbow = clamp(delta(angle(rightElbow, rightWrist) - upper), -2.3, 2.3)
            add(.rightForearm, qz(-elbow))
            if let rightIndex {
                let hand = clamp(delta(angle(rightWrist, rightIndex) - angle(rightElbow, rightWrist)),
                                 -1.6, 1.6)
                add(.rightHand, qz(-hand * 0.65))
            } else {
                add(.rightHand, qz(-elbow * 0.18))
            }
        }
        if let leftHip, let leftKnee {
            let leg = clamp(angle(leftHip, leftKnee) - .pi / 2 - lean * 0.20,
                            -2.0, 2.0)
            add(.leftThigh, qz(-leg))
        }
        if let rightHip, let rightKnee {
            let leg = clamp(angle(rightHip, rightKnee) - .pi / 2 - lean * 0.20,
                            -2.0, 2.0)
            add(.rightThigh, qz(-leg))
        }
        if let leftKnee, let leftAnkle, let leftHip {
            let knee = clamp(delta(angle(leftKnee, leftAnkle) - angle(leftHip, leftKnee)),
                             -2.4, 2.4)
            add(.leftShin, qz(-knee))
            if let leftFootIndex {
                let foot = clamp(delta(angle(leftAnkle, leftFootIndex) - .pi / 2),
                                 -1.0, 1.0)
                add(.leftFoot, qz(-foot * 0.70))
            }
        }
        if let rightKnee, let rightAnkle, let rightHip {
            let knee = clamp(delta(angle(rightKnee, rightAnkle) - angle(rightHip, rightKnee)),
                             -2.4, 2.4)
            add(.rightShin, qz(-knee))
            if let rightFootIndex {
                let foot = clamp(delta(angle(rightAnkle, rightFootIndex) - .pi / 2),
                                 -1.0, 1.0)
                add(.rightFoot, qz(-foot * 0.70))
            }
        }
        return tracks.values.contains { $0.last?.frame == frame }
    }

    private func buildMotion() -> VMDMotion {
        guard maxFrame > 0 else {
            return VMDMotion(name: "MediaPipe Video Motion", boneTracks: [],
                             morphTracks: [], cameraKeys: [], maxFrame: 0)
        }
        var finalTracks = tracks
        for name in Array(finalTracks.keys) {
            guard let last = finalTracks[name]?.last else { continue }
            if last.frame < maxFrame {
                finalTracks[name, default: []].append(BoneKey(frame: maxFrame, position: last.position, rotation: last.rotation))
            }
        }
        let boneTracks = finalTracks.keys.sorted().compactMap { name -> VMDBoneTrack? in
            guard let keys = finalTracks[name], !keys.isEmpty else { return nil }
            let frames = keys.sorted { $0.frame < $1.frame }.map { key in
                VMDBoneKeyframe(frame: key.frame,
                                position: key.position,
                                rotation: key.rotation,
                                curveX: .linear, curveY: .linear,
                                curveZ: .linear, curveRotation: .linear)
            }
            return VMDBoneTrack(name: name, keys: frames)
        }
        return VMDMotion(name: "MediaPipe Video Motion",
                         boneTracks: boneTracks,
                         morphTracks: [],
                         cameraKeys: [],
                         maxFrame: maxFrame)
    }

    private func outputURL(for videoURL: URL, modelURL: URL?) throws -> URL {
        let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSTemporaryDirectory())
        let directory = documents.appendingPathComponent("MMDStudio/GeneratedMotions", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let base = videoURL.deletingPathExtension().lastPathComponent
        let safe = base.replacingOccurrences(of: "/", with: "_")
        let modelTag = modelURL?.deletingPathExtension().lastPathComponent ?? "lite"
        var url = directory.appendingPathComponent("\(safe)-\(modelTag).vmd")
        var index = 2
        while FileManager.default.fileExists(atPath: url.path) {
            url = directory.appendingPathComponent("\(safe)-\(modelTag)-\(index).vmd")
            index += 1
        }
        return url
    }

    private func writeVMD(_ motion: VMDMotion, to url: URL) throws {
        var data = Data()
        appendFixed("Vocaloid Motion Data 0002", bytes: 30, to: &data)
        appendFixed("MMDStudio MediaPipe", bytes: 20, to: &data)

        let totalKeys = motion.boneTracks.reduce(0) { $0 + $1.keys.count }
        appendUInt32(UInt32(totalKeys), to: &data)
        let linearInterpolation = interpolationBytes()

        for track in motion.boneTracks {
            appendFixed(track.name, bytes: 15, to: &data)
            for key in track.keys.sorted(by: { $0.frame < $1.frame }) {
                appendUInt32(UInt32(max(0, key.frame)), to: &data)
                appendFloat(key.position.x, to: &data)
                appendFloat(key.position.y, to: &data)
                appendFloat(-key.position.z, to: &data)
                let q = key.rotation
                appendFloat(-q.imag.x, to: &data)
                appendFloat(-q.imag.y, to: &data)
                appendFloat(q.imag.z, to: &data)
                appendFloat(q.real, to: &data)
                data.append(linearInterpolation)
            }
        }

        appendUInt32(0, to: &data) // morph keys
        appendUInt32(0, to: &data) // camera keys
        do {
            try data.write(to: url, options: .atomic)
        } catch {
            throw ExtractError.writeFailed
        }
        MMDLog.shared.info("VMD writer: bytes=\(data.count), keys=\(totalKeys)", category: "VideoMotion")
        // A malformed tail would otherwise surface as an opaque byte-offset
        // error in the UI. Validate the file before handing it to the loader.
        do {
            _ = try VMDParser(data: data).parse()
        } catch {
            MMDLog.shared.warning("Generated VMD validation warning: \(error.localizedDescription)",
                                  category: "VideoMotion")
        }
    }

    private func interpolationBytes() -> Data {
        var bytes = [UInt8](repeating: 0, count: 64)
        for channel in 0..<64 {
            bytes[channel] = channel % 4 == 0 ? 20 : (channel % 4 == 1 ? 20 : 107)
        }
        // Standard VMD interpolation uses x1/y1/x2/y2 in four-byte groups.
        for group in 0..<16 {
            let base = group * 4
            bytes[base + 0] = 20
            bytes[base + 1] = 20
            bytes[base + 2] = 107
            bytes[base + 3] = 107
        }
        return Data(bytes)
    }

    private func appendFixed(_ text: String, bytes count: Int, to data: inout Data) {
        var raw = [UInt8]((try? text.data(using: .shiftJIS)) ?? Data())
        if raw.count > count { raw = Array(raw.prefix(count)) }
        data.append(contentsOf: raw)
        if raw.count < count { data.append(contentsOf: [UInt8](repeating: 0, count: count - raw.count)) }
    }

    private func appendUInt32(_ value: UInt32, to data: inout Data) {
        data.append(UInt8(value & 0xFF))
        data.append(UInt8((value >> 8) & 0xFF))
        data.append(UInt8((value >> 16) & 0xFF))
        data.append(UInt8((value >> 24) & 0xFF))
    }

    private func appendFloat(_ value: Float, to data: inout Data) {
        appendUInt32(value.bitPattern, to: &data)
    }
}

// MARK: - Downloadable pose models

enum MMDPoseModelKind: String, CaseIterable, Identifiable, Hashable {
    case lite
    case full
    case heavy

    var id: String { rawValue }

    var title: String {
        switch self {
        case .lite: return "MediaPipe Lite（内置）"
        case .full: return "MediaPipe Full（下载）"
        case .heavy: return "MediaPipe Heavy（下载）"
        }
    }

    var detail: String {
        switch self {
        case .lite: return "5.6 MB · 速度优先，适合手机实时/普通舞蹈"
        case .full: return "约 7 MB · 精度更高，适合清晰全身视频"
        case .heavy: return "约 30 MB · 精度最高，速度较慢"
        }
    }

    var localFilename: String { "pose_landmarker_\(rawValue).task" }

    var remoteURL: URL? {
        switch self {
        case .lite:
            return Bundle.main.url(forResource: "pose_landmarker_lite", withExtension: "task")
        case .full:
            return URL(string: "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_full/float16/latest/pose_landmarker_full.task")
        case .heavy:
            return URL(string: "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_heavy/float16/latest/pose_landmarker_heavy.task")
        }
    }

    var isBundled: Bool { self == .lite }
}

final class MMDPoseModelStore: ObservableObject {

    static let shared = MMDPoseModelStore()

    @Published private(set) var downloaded: Set<MMDPoseModelKind> = []
    @Published private(set) var downloading: MMDPoseModelKind?
    @Published private(set) var lastError: String?

    private let fileManager = FileManager.default

    private var modelsDirectory: URL {
        let documents = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSTemporaryDirectory())
        return documents.appendingPathComponent("MMDStudio/Models", isDirectory: true)
    }

    private init() {
        refresh()
    }

    func refresh() {
        var result = Set<MMDPoseModelKind>()
        for kind in MMDPoseModelKind.allCases where !kind.isBundled {
            if fileManager.fileExists(atPath: modelsDirectory.appendingPathComponent(kind.localFilename).path) {
                result.insert(kind)
            }
        }
        downloaded = result
    }

    func isAvailable(_ kind: MMDPoseModelKind) -> Bool {
        kind.isBundled || downloaded.contains(kind)
    }

    func localURL(for kind: MMDPoseModelKind) -> URL? {
        if kind.isBundled {
            return Bundle.main.url(forResource: "pose_landmarker_lite", withExtension: "task")
        }
        let url = modelsDirectory.appendingPathComponent(kind.localFilename)
        return fileManager.fileExists(atPath: url.path) ? url : nil
    }

    func download(_ kind: MMDPoseModelKind) {
        guard !kind.isBundled, downloading == nil, let remoteURL = kind.remoteURL else { return }
        downloading = kind
        lastError = nil
        let destination = modelsDirectory.appendingPathComponent(kind.localFilename)
        do {
            try fileManager.createDirectory(at: modelsDirectory, withIntermediateDirectories: true)
        } catch {
            downloading = nil
            lastError = error.localizedDescription
            return
        }
        let task = URLSession.shared.downloadTask(with: remoteURL) { [weak self] temporaryURL, response, error in
            guard let self else { return }
            if let error {
                DispatchQueue.main.async {
                    self.downloading = nil
                    self.lastError = error.localizedDescription
                }
                return
            }
            guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode),
                  let temporaryURL else {
                DispatchQueue.main.async {
                    self.downloading = nil
                    self.lastError = "模型下载失败：服务器返回异常。"
                }
                return
            }
            do {
                if self.fileManager.fileExists(atPath: destination.path) {
                    try self.fileManager.removeItem(at: destination)
                }
                try self.fileManager.moveItem(at: temporaryURL, to: destination)
                DispatchQueue.main.async {
                    self.downloading = nil
                    self.downloaded.insert(kind)
                    self.refresh()
                }
            } catch {
                DispatchQueue.main.async {
                    self.downloading = nil
                    self.lastError = error.localizedDescription
                }
            }
        }
        task.resume()
    }

    func remove(_ kind: MMDPoseModelKind) {
        guard !kind.isBundled else { return }
        let url = modelsDirectory.appendingPathComponent(kind.localFilename)
        try? fileManager.removeItem(at: url)
        refresh()
    }
}

struct MMDExternalMotionScheme: Identifiable {
    let id = UUID()
    let title: String
    let detail: String
    let url: URL
}

let mmdExternalMotionSchemes: [MMDExternalMotionScheme] = [
    MMDExternalMotionScheme(
        title: "MediaPipe Pose Landmarker",
        detail: "本 App 已直接接入。Lite/Full/Heavy 可在下方按需下载，不增加安装包体积。",
        url: URL(string: "https://ai.google.dev/edge/mediapipe/solutions/vision/pose_landmarker")!),
    MMDExternalMotionScheme(
        title: "RTMPose / MMPose",
        detail: "更高精度的 2D/3D 人体关键点方案，需在桌面端导出 VMD 后再导入；仓库含模型与推理代码。",
        url: URL(string: "https://github.com/open-mmlab/mmpose/tree/main/projects/rtmpose")!),
    MMDExternalMotionScheme(
        title: "MotionBERT",
        detail: "单目视频 3D 人体姿态与动作恢复，适合桌面端离线处理，导出 VMD 后导入 App。",
        url: URL(string: "https://github.com/MotrixLab/MotionBERT")!),
    MMDExternalMotionScheme(
        title: "GVHMR",
        detail: "单目视频重建 SMPL 人体与全局运动，适合复杂舞蹈的离线高质量重建。",
        url: URL(string: "https://github.com/zju3dv/GVHMR")!),
]
