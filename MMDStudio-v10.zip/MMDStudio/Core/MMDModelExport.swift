import Foundation
import AVFoundation
import CoreGraphics
import UIKit
import ImageIO
import UniformTypeIdentifiers
import simd

struct MMDModelExportSummary {
    let directory: URL
    let objURL: URL
    let mtlURL: URL
    let copiedAssets: Int
    let copiedSourceModel: Bool
}

enum MMDModelExporter {

    private static let fileManager = FileManager.default

    /// Exports the current frame as a triangulated OBJ+MTL with per-vertex
    /// skinning/morph applied, and copies the original PMX/PMD unchanged plus
    /// all texture files in their original formats. OBJ is a universal
    /// interchange target; it is not a PMX round-trip and does not carry MMD
    /// bones, IK, rigid bodies or morph sliders.
    static func exportCurrentPose(document: MMDModelDocument) throws -> MMDModelExportSummary {
        let documents = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSTemporaryDirectory())
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyyMMdd-HHmmss"
        let safeName = sanitize(document.model.displayName)
        let directory = documents
            .appendingPathComponent("MMDStudio/Exports/Models", isDirectory: true)
            .appendingPathComponent("\(safeName)-Pose-\(formatter.string(from: Date()))", isDirectory: true)
        try fileManager.createDirectory(at: directory, withIntermediateDirectories: true)

        let model = document.model
        let skeleton = MMDSkeleton(model: model)
        let animations = document.effectiveBoneAnimations(frame: document.currentFrame)
        let pose = skeleton.solve(animations: animations, model: model, ikEnabled: document.ikEnabled)
        let morphPositions = MMDMorphController.positions(model: model,
                                                          weights: document.effectiveMorphWeights())

        var positions = morphPositions
        var normals = model.vertices.map { $0.normal }
        for index in positions.indices {
            let vertex = model.vertices[index]
            let p = morphPositions[index]
            var skinned = SIMD3<Float>.zero
            var skinnedNormal = SIMD3<Float>.zero
            for slot in 0..<4 {
                let weight = vertex.boneWeights[slot]
                guard weight > 0.00001 else { continue }
                let bone = Int(vertex.boneIndices[slot])
                guard bone >= 0 && bone < pose.palettes.count else { continue }
                let matrix = pose.palettes[bone]
                let transformed = matrix * SIMD4<Float>(p.x, p.y, p.z, 1)
                skinned += SIMD3<Float>(transformed.x, transformed.y, transformed.z) * weight
                let normal = matrix * SIMD4<Float>(vertex.normal.x, vertex.normal.y, vertex.normal.z, 0)
                skinnedNormal += SIMD3<Float>(normal.x, normal.y, normal.z) * weight
            }
            if simd_length(skinned) < 1e-8 { skinned = p }
            positions[index] = skinned
            if simd_length(skinnedNormal) > 1e-6 { normals[index] = simd_normalize(skinnedNormal) }
        }

        let textureItems = MMDTextureExporter.items(model: model,
                                                     baseDirectory: document.baseDirectory,
                                                     fallbackRoot: document.fallbackRoot)
        var copiedAssets = 0
        for item in textureItems {
            guard let source = item.sourceURL, fileManager.fileExists(atPath: source.path) else { continue }
            let target = directory.appendingPathComponent(item.fileName)
            do {
                if fileManager.fileExists(atPath: target.path) { try fileManager.removeItem(at: target) }
                try fileManager.copyItem(at: source, to: target)
                copiedAssets += 1
            } catch {
                MMDLog.shared.warning("OBJ asset copy failed: \(item.path): \(error.localizedDescription)",
                                      category: "Export")
            }
        }

        let objURL = directory.appendingPathComponent("\(safeName)-pose.obj")
        let mtlURL = directory.appendingPathComponent("\(safeName)-pose.mtl")
        var mtl = "# MMD Studio OBJ material library\n"
        for (index, material) in model.materials.enumerated() {
            mtl += "\nnewmtl material_\(index)\n"
            mtl += String(format: "Kd %.6f %.6f %.6f\n", material.diffuse.x, material.diffuse.y, material.diffuse.z)
            mtl += String(format: "Ks %.6f %.6f %.6f\n", material.specular.x, material.specular.y, material.specular.z)
            mtl += String(format: "Ns %.3f\nd %.3f\n", max(1, material.specularPower), material.diffuse.w)
            if material.textureIndex >= 0,
               let item = textureItems.first(where: { $0.id == material.textureIndex }) {
                mtl += "map_Kd \(item.fileName)\n"
            }
        }
        try mtl.write(to: mtlURL, atomically: true, encoding: .utf8)

        var obj = "# MMD Studio current pose export\n"
        obj += "# model: \(model.displayName)\n"
        obj += "# frame: \(String(format: "%.2f", document.currentFrame))\n"
        obj += "mtllib \(mtlURL.lastPathComponent)\n"
        for position in positions {
            obj += String(format: "v %.6f %.6f %.6f\n", position.x, position.y, position.z)
        }
        for vertex in model.vertices {
            obj += String(format: "vt %.6f %.6f\n", vertex.uv.x, 1 - vertex.uv.y)
        }
        for normal in normals {
            obj += String(format: "vn %.6f %.6f %.6f\n", normal.x, normal.y, normal.z)
        }
        var cursor = 0
        for (materialIndex, material) in model.materials.enumerated() {
            let count = material.indexCount
            guard count >= 3, cursor + count <= model.indices.count else {
                cursor = min(model.indices.count, cursor + max(0, count))
                continue
            }
            obj += "usemtl material_\(materialIndex)\ng\n"
            var offset = cursor
            while offset + 2 < cursor + count {
                let a = Int(model.indices[offset]) + 1
                let b = Int(model.indices[offset + 1]) + 1
                let c = Int(model.indices[offset + 2]) + 1
                obj += "f \(a)/\(a)/\(a) \(b)/\(b)/\(b) \(c)/\(c)/\(c)\n"
                offset += 3
            }
            cursor += count
        }
        try obj.write(to: objURL, atomically: true, encoding: .utf8)

        var copiedSource = false
        if let source = document.sourceURL, fileManager.fileExists(atPath: source.path) {
            let target = directory.appendingPathComponent(source.lastPathComponent)
            do {
                try fileManager.copyItem(at: source, to: target)
                copiedSource = true
            } catch {
                MMDLog.shared.warning("Original model copy failed: \(error.localizedDescription)", category: "Export")
            }
        }
        try exportVPD(document: document, directory: directory, safeName: safeName)
        MMDLog.shared.info("Model export: \(directory.path), assets=\(copiedAssets), source=\(copiedSource)",
                           category: "Export")
        return MMDModelExportSummary(directory: directory, objURL: objURL, mtlURL: mtlURL,
                                     copiedAssets: copiedAssets, copiedSourceModel: copiedSource)
    }

    /// Writes the current local bone pose as VPD. VPD is the standard MMD
    /// static-pose format; names are Shift-JIS with a UTF-8 fallback.
    private static func exportVPD(document: MMDModelDocument, directory: URL, safeName: String) throws {
        let animations = document.effectiveBoneAnimations(frame: document.currentFrame)
        var lines = ["Vocaloid Pose Data file", "; exported by MMD Studio",
                     "\(document.model.displayName);", "\(document.model.bones.count);"]
        let shiftJIS = MMDPoseParser.shiftJIS
        for (index, bone) in document.model.bones.enumerated() {
            let animation = animations[index] ?? MMDBoneAnimation()
            let q = animation.rotation
            let position = SIMD3<Float>(animation.position.x, animation.position.y, -animation.position.z)
            let values = [position.x, position.y, position.z, -q.imag.x, -q.imag.y, q.imag.z, q.real]
            let valueText = values.map { String(format: "%.6f", $0) }.joined(separator: ",")
            lines.append("\(bone.name);\(valueText)")
        }
        lines.append("0;")
        let text = lines.joined(separator: "\r\n")
        let data = text.data(using: shiftJIS) ?? text.data(using: .utf8)!
        try data.write(to: directory.appendingPathComponent("\(safeName)-pose.vpd"), options: .atomic)
    }

    private static func sanitize(_ value: String) -> String {
        let clean = value.replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: ":", with: "_")
            .replacingOccurrences(of: "\\", with: "_")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        return clean.isEmpty ? "Model" : clean
    }
}

/// Deterministic offscreen video export. Unlike the live screen recorder this
/// drives the document frame-by-frame at a fixed rate, so the output duration
/// matches the VMD and every frame is an offscreen Metal render. Optional VMD
/// audio is muxed into the final MP4.
final class MMDVideoExporter: ObservableObject {

    @Published var isExporting = false
    @Published var progress: Double = 0
    @Published var statusText = ""
    @Published var errorText: String?
    @Published private(set) var outputURL: URL?

    private var cancelled = false
    private var queue = DispatchQueue(label: "mmd.video.export", qos: .userInitiated)

    func cancel() {
        cancelled = true
        statusText = "正在取消…"
    }

    func export(document: MMDModelDocument, renderer: MMDRenderer,
                width: Int = 1080, height: Int = 1920, fps: Int = 30) {
        guard !isExporting else { return }
        guard document.hasMotion else {
            errorText = "请先导入 VMD 动作再导出视频"
            return
        }
        let frameCount = max(1, Int(ceil(Double(document.duration) / Double(document.frameRate) * Double(fps))) + 1)
        isExporting = true
        cancelled = false
        progress = 0
        errorText = nil
        statusText = "准备离屏渲染 \(frameCount) 帧…"
        let audioURL = document.motionAudioURL
        let safeName = sanitize(document.displayName)
        let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSTemporaryDirectory())
        let videoDirectory = documents.appendingPathComponent("MMDStudio/Exports/Videos", isDirectory: true)
        try? FileManager.default.createDirectory(at: videoDirectory, withIntermediateDirectories: true)
        let stamp = ISO8601DateFormatter().string(from: Date())
            .replacingOccurrences(of: ":", with: "-")
        let tempURL = videoDirectory.appendingPathComponent("\(safeName)-\(stamp)-temp.mp4")
        let finalURL = videoDirectory.appendingPathComponent("\(safeName)-\(stamp).mp4")

        queue.async { [weak self] in
            guard let self else { return }
            let originalFrame = document.currentFrame
            do {
                try FileManager.default.removeItemIfExists(tempURL)
                let writer = try AVAssetWriter(outputURL: tempURL, fileType: .mp4)
                let settings: [String: Any] = [
                    AVVideoCodecKey: AVVideoCodecType.h264,
                    AVVideoWidthKey: width,
                    AVVideoHeightKey: height,
                    AVVideoCompressionPropertiesKey: [
                        AVVideoAverageBitRateKey: 6_000_000,
                        AVVideoProfileLevelKey: AVVideoProfileLevelH264HighAutoLevel
                    ]
                ]
                let input = AVAssetWriterInput(mediaType: .video, outputSettings: settings)
                input.expectsMediaDataInRealTime = false
                let attributes: [String: Any] = [
                    kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                    kCVPixelBufferWidthKey as String: width,
                    kCVPixelBufferHeightKey as String: height
                ]
                let adaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: input,
                                                                    sourcePixelBufferAttributes: attributes)
                guard writer.canAdd(input) else { throw MMDLoadError.invalidData("无法创建 H.264 视频轨") }
                writer.add(input)
                guard writer.startWriting() else {
                    throw MMDLoadError.invalidData(writer.error?.localizedDescription ?? "视频写入器启动失败")
                }
                writer.startSession(atSourceTime: .zero)

                var lastImage: UIImage?
                for frame in 0..<frameCount {
                    if self.cancelled { break }
                    let semaphore = DispatchSemaphore(value: 0)
                    renderer.captureFrame(frame: Float(frame) / Float(max(1, fps)) * document.frameRate,
                                          width: width, height: height) { image in
                        lastImage = image
                        semaphore.signal()
                    }
                    semaphore.wait()
                    guard let image = lastImage,
                          let buffer = Self.pixelBuffer(from: image, width: width, height: height,
                                                        pool: adaptor.pixelBufferPool) else {
                        throw MMDLoadError.invalidData("第 \(frame) 帧渲染失败")
                    }
                    while !input.isReadyForMoreMediaData {
                        if self.cancelled { break }
                        Thread.sleep(forTimeInterval: 0.005)
                    }
                    guard adaptor.append(buffer, withPresentationTime: CMTime(value: CMTimeValue(frame),
                                                                               timescale: CMTimeScale(fps))) else {
                        throw MMDLoadError.invalidData("第 \(frame) 帧写入失败：\(writer.error?.localizedDescription ?? "unknown")")
                    }
                    let fraction = Double(frame + 1) / Double(frameCount)
                    DispatchQueue.main.async {
                        self.progress = fraction
                        self.statusText = "渲染 \(frame + 1)/\(frameCount) 帧"
                    }
                }
                input.markAsFinished()
                if self.cancelled {
                    writer.cancelWriting()
                    try? FileManager.default.removeItemIfExists(tempURL)
                    DispatchQueue.main.async {
                        renderer.restoreFrame(originalFrame)
                        self.isExporting = false
                        self.statusText = "已取消"
                    }
                    return
                }
                let finishSemaphore = DispatchSemaphore(value: 0)
                writer.finishWriting { finishSemaphore.signal() }
                finishSemaphore.wait()
                guard writer.status == .completed else {
                    throw MMDLoadError.invalidData(writer.error?.localizedDescription ?? "视频封装失败")
                }
                if let audioURL, FileManager.default.fileExists(atPath: audioURL.path) {
                    try Self.mux(video: tempURL, audio: audioURL, output: finalURL)
                    try? FileManager.default.removeItemIfExists(tempURL)
                } else {
                    try? FileManager.default.removeItemIfExists(finalURL)
                    try FileManager.default.moveItem(at: tempURL, to: finalURL)
                }
                DispatchQueue.main.async {
                    renderer.restoreFrame(originalFrame)
                    self.outputURL = finalURL
                    self.isExporting = false
                    self.progress = 1
                    self.statusText = "导出完成：\(finalURL.lastPathComponent)"
                    MMDLog.shared.info("Video export: \(finalURL.path)", category: "Export")
                }
            } catch {
                DispatchQueue.main.async {
                    renderer.restoreFrame(document.currentFrame)
                    self.errorText = error.localizedDescription
                    self.isExporting = false
                    self.statusText = "导出失败"
                    MMDLog.shared.error("Video export failed: \(error.localizedDescription)", category: "Export")
                }
            }
        }
    }

    private static func pixelBuffer(from image: UIImage, width: Int, height: Int,
                                    pool: CVPixelBufferPool?) -> CVPixelBuffer? {
        guard let cgImage = image.cgImage else { return nil }
        var buffer: CVPixelBuffer?
        if let pool {
            CVPixelBufferPoolCreatePixelBuffer(nil, pool, &buffer)
        }
        if buffer == nil {
            CVPixelBufferCreate(nil, width, height, kCVPixelFormatType_32BGRA,
                                [kCVPixelBufferCGImageCompatibilityKey: true,
                                 kCVPixelBufferCGBitmapContextCompatibilityKey: true] as CFDictionary,
                                &buffer)
        }
        guard let pixelBuffer = buffer else { return nil }
        CVPixelBufferLockBaseAddress(pixelBuffer, [])
        defer { CVPixelBufferUnlockBaseAddress(pixelBuffer, []) }
        guard let base = CVPixelBufferGetBaseAddress(pixelBuffer),
              let context = CGContext(data: base, width: width, height: height,
                                      bitsPerComponent: 8, bytesPerRow: CVPixelBufferGetBytesPerRow(pixelBuffer),
                                      space: CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.premultipliedFirst.rawValue |
                                                  CGBitmapInfo.byteOrder32Little.rawValue) else { return nil }
        context.translateBy(x: 0, y: CGFloat(height))
        context.scaleBy(x: 1, y: -1)
        context.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))
        return pixelBuffer
    }

    private static func mux(video: URL, audio: URL, output: URL) throws {
        let composition = AVMutableComposition()
        let videoAsset = AVURLAsset(url: video)
        let audioAsset = AVURLAsset(url: audio)
        guard let videoTrack = videoAsset.tracks(withMediaType: .video).first,
              let compositionVideo = composition.addMutableTrack(withMediaType: .video,
                                                                 preferredTrackID: kCMPersistentTrackID_Invalid) else {
            throw MMDLoadError.invalidData("无法读取临时视频轨")
        }
        try compositionVideo.insertTimeRange(CMTimeRange(start: .zero, duration: videoAsset.duration),
                                             of: videoTrack, at: .zero)
        if let audioTrack = audioAsset.tracks(withMediaType: .audio).first,
           let compositionAudio = composition.addMutableTrack(withMediaType: .audio,
                                                              preferredTrackID: kCMPersistentTrackID_Invalid) {
            let duration = CMTimeMinimum(audioAsset.duration, videoAsset.duration)
            try? compositionAudio.insertTimeRange(CMTimeRange(start: .zero, duration: duration),
                                                  of: audioTrack, at: .zero)
        }
        guard let session = AVAssetExportSession(asset: composition,
                                                 presetName: AVAssetExportPresetHighestQuality) else {
            throw MMDLoadError.invalidData("无法创建音视频合成会话")
        }
        try? FileManager.default.removeItemIfExists(output)
        session.outputURL = output
        session.outputFileType = .mp4
        let semaphore = DispatchSemaphore(value: 0)
        session.exportAsynchronously { semaphore.signal() }
        semaphore.wait()
        guard session.status == .completed else {
            throw MMDLoadError.invalidData(session.error?.localizedDescription ?? "音视频合成失败")
        }
    }

    private static func sanitize(_ value: String) -> String {
        let clean = value.replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: ":", with: "_")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        return clean.isEmpty ? "MMDVideo" : clean
    }
}

private extension FileManager {
    func removeItemIfExists(_ url: URL) throws {
        if fileExists(atPath: url.path) { try removeItem(at: url) }
    }
}
