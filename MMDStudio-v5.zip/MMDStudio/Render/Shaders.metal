#include <metal_stdlib>
using namespace metal;

struct Light {
    float4 positionOrDirection;
    float4 color;
    float4 params;          // x: type 0 sun / 1 point / 2 ambient, y: intensity, z: range, w: enabled
};

struct SceneUniforms {
    float4x4 viewProjection;
    float4x4 view;
    float4x4 model;
    float4x4 normalMatrix;
    float4 lightDirection;
    float4 lightColor;
    float4 ambientColor;
    float4 cameraPosition;
    float4 params;          // x: groundY, y: gridSpacing, z: edgeScale, w: unused
    float4 lightParams;     // x: ambient, y: fill, z: rim, w: exposure
    float4 lightCount;      // x: active lights, y: ambient strength, z: exposure
    Light lights[4];
};

struct MaterialUniforms {
    float4 diffuse;
    float4 specular;        // rgb: color, w: power
    float4 ambient;
    float4 edgeColor;
    float4 textureTint;
    float4 sphereTint;
    float4 toonTint;
    float edgeSize;
    float alphaTest;
    int sphereMode;
    uint flags;
    int renderMode;
};

constant uint kFlagHasTexture = 1;
constant uint kFlagHasSphere = 2;
constant uint kFlagHasToon = 4;
constant uint kFlagDoubleSided = 8;
constant uint kFlagOpaque = 16;

struct MeshVertexOut {
    float4 position [[position]];
    float3 worldPosition;
    float3 normal;
    float3 viewNormal;
    float2 uv;
    float edgeScale;
};

// MARK: - Mesh

vertex MeshVertexOut mmd_mesh_vertex(uint vid [[vertex_id]],
                                     device const float3 *positions [[buffer(0)]],
                                     device const float3 *normals [[buffer(1)]],
                                     device const float2 *uvs [[buffer(2)]],
                                     device const uint4 *boneIndices [[buffer(3)]],
                                     device const float4 *weights [[buffer(4)]],
                                     device const float *edgeScales [[buffer(5)]],
                                     constant SceneUniforms &scene [[buffer(6)]],
                                     device const float4x4 *palette [[buffer(7)]]) {
    uint4 bi = boneIndices[vid];
    float4 w = weights[vid];
    float3 position = positions[vid];
    float3 normal = normals[vid];

    float4 skinned = w.x * (palette[bi.x] * float4(position, 1.0))
                   + w.y * (palette[bi.y] * float4(position, 1.0))
                   + w.z * (palette[bi.z] * float4(position, 1.0))
                   + w.w * (palette[bi.w] * float4(position, 1.0));
    float3 skinnedNormal = w.x * (palette[bi.x] * float4(normal, 0.0)).xyz
                         + w.y * (palette[bi.y] * float4(normal, 0.0)).xyz
                         + w.z * (palette[bi.z] * float4(normal, 0.0)).xyz
                         + w.w * (palette[bi.w] * float4(normal, 0.0)).xyz;

    float4 world = scene.model * float4(skinned.xyz, 1.0);
    float3 worldNormal = normalize((scene.normalMatrix * float4(skinnedNormal, 0.0)).xyz);

    MeshVertexOut out;
    out.position = scene.viewProjection * world;
    out.worldPosition = world.xyz;
    out.normal = worldNormal;
    out.viewNormal = normalize((scene.view * float4(worldNormal, 0.0)).xyz);
    out.uv = uvs[vid];
    out.edgeScale = edgeScales[vid];
    return out;
}

fragment float4 mmd_mesh_fragment(MeshVertexOut in [[stage_in]],
                                  bool frontFacing [[front_facing]],
                                  constant SceneUniforms &scene [[buffer(0)]],
                                  constant MaterialUniforms &mat [[buffer(1)]],
                                  texture2d<float> baseMap [[texture(0)]],
                                  texture2d<float> sphereMap [[texture(1)]],
                                  texture2d<float> toonMap [[texture(2)]]) {
    constexpr sampler repeatSampler(address::repeat, filter::linear, mip_filter::linear);
    constexpr sampler clampSampler(address::clamp_to_edge, filter::linear, mip_filter::linear);

    float4 base = mat.diffuse;
    if ((mat.flags & kFlagHasTexture) != 0) {
        float4 texel = baseMap.sample(repeatSampler, in.uv);
        base *= texel;
    }
    base.rgb *= mat.textureTint.rgb;

    float3 N = normalize(in.normal);
    if ((mat.flags & kFlagDoubleSided) != 0 && !frontFacing) {
        N = -N;
    }
    float3 V = normalize(scene.cameraPosition.xyz - in.worldPosition);

    // Sphere maps are a material-level reflection term and must be applied
    // before choosing the shading model; inspection modes still override it.
    if ((mat.flags & kFlagHasSphere) != 0) {
        float2 sphereUV = in.viewNormal.xy;
        sphereUV = sphereUV * 0.5 + 0.5;
        sphereUV.y = 1.0 - sphereUV.y;
        float4 sphere = sphereMap.sample(clampSampler, sphereUV);
        sphere.rgb *= mat.sphereTint.rgb;
        if (mat.sphereMode == 1) {
            base.rgb *= sphere.rgb;
        } else if (mat.sphereMode == 2 || mat.sphereMode == 3) {
            base.rgb += sphere.rgb;
        }
    }

    float ambientStrength = clamp(scene.lightCount.y, 0.05, 1.0);
    float exposure = clamp(scene.lightCount.z, 0.5, 2.0);
    float3 ambientLight = scene.ambientColor.rgb * ambientStrength;
    float3 directLight = float3(0.0);
    float mainNdl = 0.0;

    // Evaluate up to four user lights. Sun lights use direction-to-light in
    // positionOrDirection; point lights use a world-space position.
    int lightCount = min(4, max(0, int(scene.lightCount.x)));
    for (int i = 0; i < 4; ++i) {
        if (i >= lightCount) { break; }
        Light light = scene.lights[i];
        if (light.params.w < 0.5) { continue; }
        int type = int(light.params.x);
        if (type == 2) {
            ambientLight += light.color.rgb * light.params.y;
            continue;
        }
        float3 toLight;
        float attenuation = 1.0;
        if (type == 0) {
            float3 d = light.positionOrDirection.xyz;
            if (length(d) < 0.0001) { continue; }
            toLight = normalize(d);
        } else {
            float3 offset = light.positionOrDirection.xyz - in.worldPosition;
            float dist = length(offset);
            if (dist < 0.0001) { continue; }
            toLight = offset / dist;
            float range = max(light.params.z, 0.01);
            float ratio = clamp(1.0 - dist / range, 0.0, 1.0);
            attenuation = ratio * ratio;
        }
        float ndl = max(dot(N, toLight), 0.0);
        if (i == 0) { mainNdl = ndl; }
        directLight += light.color.rgb * light.params.y * ndl * attenuation;
    }

    // Fallback for scenes that have no explicit light array.
    if (lightCount == 0) {
        float3 L = normalize(scene.lightDirection.xyz);
        mainNdl = max(dot(N, L), 0.0);
        directLight = scene.lightColor.rgb * mainNdl;
        ambientLight = scene.ambientColor.rgb * ambientStrength;
    }

    float litRaw = clamp(mainNdl * 0.5 + 0.5, 0.0, 1.0);
    float toonBand = mix(0.55, 1.0, smoothstep(0.18, 0.52, mainNdl));
    if ((mat.flags & kFlagHasToon) != 0) {
        toonBand = clamp(toonMap.sample(clampSampler, float2(litRaw, 0.5)).r * mat.toonTint.r, 0.18, 1.0);
    }

    float3 color = base.rgb;
    if (mat.renderMode == 2) {
        // Unlit inspection: preserve the texture exactly.
        color = base.rgb;
    } else if (mat.renderMode == 3) {
        color = N * 0.5 + 0.5;
    } else if (mat.renderMode == 4) {
        float2 grid = floor(in.uv * 12.0);
        float checker = fmod(grid.x + grid.y, 2.0);
        color = base.rgb * (0.35 + checker * 0.45) + float3(0.08, 0.18, 0.24);
    } else if (mat.renderMode == 5) {
        color = float3(0.20, 0.80, 1.0);
    } else if (mat.renderMode == 1) {
        // Realistic: all direct lights + a subtle fill/rim term and specular.
        float3 L = normalize(scene.lightDirection.xyz);
        float3 fillDirection = normalize(float3(-L.x, 0.30, -L.z));
        float fill = max(dot(N, fillDirection), 0.0) * clamp(scene.lightParams.y, 0.0, 1.0);
        float rim = pow(1.0 - max(dot(N, V), 0.0), 2.0) * clamp(scene.lightParams.z, 0.0, 1.0);
        color = base.rgb * (ambientLight * 0.72 + directLight * 0.85
                            + scene.lightColor.rgb * fill * 0.18
                            + scene.lightColor.rgb * rim * 0.30);
        color += mat.specular.rgb * pow(max(dot(N, normalize(L + V)), 0.0),
                                        max(mat.specular.w, 1.0)) * 0.35;
    } else {
        // MMD-standard toon: ambient + a quantized key light. No PBR specular
        // and no broad fill/rim wash, otherwise the result looks realistic.
        color = base.rgb * (ambientLight * 0.48 + directLight * toonBand);
        color += base.rgb * mat.ambient.rgb * 0.06;
    }
    color *= exposure;

    float alpha = base.a;
    if (mat.renderMode >= 2) { alpha = 1.0; }
    if (alpha < mat.alphaTest) { discard_fragment(); }
    return float4(color, alpha);
}

// MARK: - Edge (inverted hull, front faces culled)

struct EdgeVertexOut {
    float4 position [[position]];
};

vertex EdgeVertexOut mmd_edge_vertex(uint vid [[vertex_id]],
                                     device const float3 *positions [[buffer(0)]],
                                     device const float3 *normals [[buffer(1)]],
                                     device const uint4 *boneIndices [[buffer(3)]],
                                     device const float4 *weights [[buffer(4)]],
                                     device const float *edgeScales [[buffer(5)]],
                                     constant SceneUniforms &scene [[buffer(6)]],
                                     constant MaterialUniforms &mat [[buffer(7)]],
                                     device const float4x4 *palette [[buffer(8)]]) {
    uint4 bi = boneIndices[vid];
    float4 w = weights[vid];
    float4 skinned = w.x * (palette[bi.x] * float4(positions[vid], 1.0))
                   + w.y * (palette[bi.y] * float4(positions[vid], 1.0))
                   + w.z * (palette[bi.z] * float4(positions[vid], 1.0))
                   + w.w * (palette[bi.w] * float4(positions[vid], 1.0));
    float3 skinnedNormal = normalize(w.x * (palette[bi.x] * float4(normals[vid], 0.0)).xyz
                         + w.y * (palette[bi.y] * float4(normals[vid], 0.0)).xyz
                         + w.z * (palette[bi.z] * float4(normals[vid], 0.0)).xyz
                         + w.w * (palette[bi.w] * float4(normals[vid], 0.0)).xyz);

    float width = mat.edgeSize * max(edgeScales[vid], 0.0) * 0.025 * scene.params.z;
    float3 pushed = skinned.xyz + skinnedNormal * width;
    EdgeVertexOut out;
    out.position = scene.viewProjection * (scene.model * float4(pushed, 1.0));
    return out;
}

fragment float4 mmd_edge_fragment(constant MaterialUniforms &mat [[buffer(0)]]) {
    return float4(mat.edgeColor.rgb, 1.0);
}

// MARK: - Ground shadow

struct ShadowOut {
    float4 position [[position]];
};

vertex ShadowOut mmd_shadow_vertex(uint vid [[vertex_id]],
                                       device const float3 *positions [[buffer(0)]],
                                       device const uint4 *boneIndices [[buffer(3)]],
                                       device const float4 *weights [[buffer(4)]],
                                       constant SceneUniforms &scene [[buffer(6)]],
                                       device const float4x4 *palette [[buffer(7)]]) {
    uint4 bi = boneIndices[vid];
    float4 w = weights[vid];
    float4 skinned = w.x * (palette[bi.x] * float4(positions[vid], 1.0))
                   + w.y * (palette[bi.y] * float4(positions[vid], 1.0))
                   + w.z * (palette[bi.z] * float4(positions[vid], 1.0))
                   + w.w * (palette[bi.w] * float4(positions[vid], 1.0));
    float4 world = scene.model * float4(skinned.xyz, 1.0);
    world.y = scene.params.x;
    ShadowOut out;
    out.position = scene.viewProjection * world;
    return out;
}

fragment float4 mmd_shadow_fragment() {
    return float4(0.0, 0.0, 0.0, 0.55);
}

// MARK: - Grid

struct OverlayVertex {
    float3 position;
    float4 color;
};

struct OverlayOut {
    float4 position [[position]];
    float4 color;
    float3 worldPosition;
};

vertex OverlayOut mmd_grid_vertex(uint vid [[vertex_id]],
                                  device const OverlayVertex *vertices [[buffer(0)]],
                                  constant SceneUniforms &scene [[buffer(1)]]) {
    OverlayVertex v = vertices[vid];
    OverlayOut out;
    out.position = scene.viewProjection * float4(v.position, 1.0);
    out.color = v.color;
    out.worldPosition = v.position;
    return out;
}

fragment float4 mmd_grid_fragment(OverlayOut in [[stage_in]],
                                  constant SceneUniforms &scene [[buffer(0)]]) {
    float spacing = max(scene.params.y, 0.05);
    float2 coord = in.worldPosition.xz / spacing;
    float2 derivative = fwidth(coord);
    float2 grid = abs(fract(coord - 0.5) - 0.5) / max(derivative, float2(0.0001));
    float line = min(grid.x, grid.y);
    float alpha = (1.0 - min(line, 1.0)) * 0.45;

    float2 majorCoord = in.worldPosition.xz / (spacing * 10.0);
    float2 majorDerivative = fwidth(majorCoord);
    float2 majorGrid = abs(fract(majorCoord - 0.5) - 0.5) / max(majorDerivative, float2(0.0001));
    float majorLine = min(majorGrid.x, majorGrid.y);
    float majorAlpha = (1.0 - min(majorLine, 1.0)) * 0.55;

    float3 color = float3(0.42, 0.45, 0.5);
    color = mix(color, float3(0.6, 0.65, 0.7), float3(majorAlpha / 0.55));

    float distanceToCamera = distance(in.worldPosition, scene.cameraPosition.xyz);
    float fade = clamp(1.0 - distanceToCamera / (spacing * 90.0), 0.0, 1.0);
    alpha = max(alpha, majorAlpha) * fade;
    return float4(color, alpha);
}

// MARK: - Bone overlay

vertex OverlayOut mmd_overlay_vertex(uint vid [[vertex_id]],
                                     device const OverlayVertex *vertices [[buffer(0)]],
                                     constant SceneUniforms &scene [[buffer(1)]]) {
    OverlayVertex v = vertices[vid];
    OverlayOut out;
    out.position = scene.viewProjection * float4(v.position, 1.0);
    out.color = v.color;
    out.worldPosition = v.position;
    return out;
}

fragment float4 mmd_overlay_fragment(OverlayOut in [[stage_in]]) {
    return in.color;
}
